#if !defined(CONST_H)
#define CONST_H

#include <math.h>
#include <float.h>
const double pi=3.1415926535897932384626433832795;

#endif
