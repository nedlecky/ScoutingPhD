//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MFCPendulum.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MFCPENTYPE                  129
#define IDD_SIMULATE                    130
#define IDD_GRAPH                       131
#define IDD_SCOUTING_DLG                132
#define IDC_STATUS                      1000
#define IDC_SIMULATE                    1001
#define IDC_EDIT_MASS                   1002
#define IDC_EDIT_DAMPING                1003
#define IDC_SPIN_MASS                   1004
#define IDC_EDIT_LENGTH                 1005
#define IDC_EDIT_GRAVITY                1006
#define IDC_SPIN_DAMPING                1007
#define IDC_SPIN_LENGTH                 1008
#define IDC_SPIN_GRAVITY                1009
#define IDC_EDIT_MAXINPUT               1010
#define IDC_SPIN_MAXINPUT               1011
#define IDC_EDIT_ITHETA                 1012
#define IDC_SPIN_ITHETA                 1013
#define IDC_EDIT_IOMEGA                 1014
#define IDC_SPIN_IOMEGA                 1015
#define IDC_EDIT_FTHETA                 1016
#define IDC_SPIN_FTHETA                 1017
#define IDC_EDIT_FOMEGA                 1018
#define IDC_SPIN_FOMEGA                 1019
#define IDC_EDIT_THETATOL               1020
#define IDC_SPIN_THETATOL               1021
#define IDC_EDIT_OMEGATOL               1022
#define IDC_SPIN_OMEGATOL               1023
#define IDC_EDIT_IPS                    1024
#define IDC_SPIN_IPS                    1025
#define IDC_STATUS2                     1026
#define IDC_EDIT_INPUTTYPE              1027
#define IDC_EDIT_NSCOUTS                1028
#define IDC_SPIN_NSCOUTS                1029
#define IDC_EDIT_MAXSTEPS               1030
#define IDC_SPIN_MAXSTEPS               1031
#define IDC_EDIT_TIMESTEP               1032
#define IDC_SPIN_TIMESTEP               1033
#define IDC_EDIT_MININPUT               1034
#define IDC_SPIN_MININPUT               1035
#define IDC_EDIT_INPUTSLEW              1036
#define IDC_SPIN_INPUTSLEW              1037
#define IDC_SPIN_INPUTTYPE              1038
#define ID_SIMULATE_GO                  32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
