// LabelTable.cpp : implementation file
//

#include "stdafx.h"
#include "WinTim32.h"
#include "LabelTable.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLabelTable dialog

extern CWinTim32App theApp;
extern int activeThreadCount;
extern int activeViewCount;

CLabelTable::CLabelTable(CWnd* pParent /*=NULL*/)
	: CDialog(CLabelTable::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLabelTable)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CLabelTable::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLabelTable)
	DDX_Control(pDX, IDOK, m_OKButton);
	DDX_Control(pDX, IDC_UPDATE, m_UpdateButton);
	DDX_Control(pDX, IDC_LABELLIST, m_LabelListCtrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLabelTable, CDialog)
	//{{AFX_MSG_MAP(CLabelTable)
	ON_BN_CLICKED(IDC_UPDATE, OnUpdate)
	ON_WM_SIZE()
	ON_WM_GETMINMAXINFO()
	ON_WM_CLOSE()
	ON_WM_MOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

int CALLBACK NumCompare(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort)
{
	return lParam1 - lParam2;
}

/////////////////////////////////////////////////////////////////////////////
// CLabelTable message handlers

void CLabelTable::OnUpdate() 
{
	int i;
	char buf[10];
	SetRedraw(FALSE);
	m_LabelListCtrl.DeleteAllItems();
	if (m_Table == NULL)
	{
		SetRedraw(TRUE);
		return;
	}
	for (i = 0; i < m_Table->GetSize(); i++)
	{
		if (!IsWindow(m_LabelListCtrl))
			return; // Something stupid happened with the update thread
		if (m_Table == NULL)
			return;
		m_LabelListCtrl.InsertItem(i,ltoa(m_Table->GetAt(i).line,buf,10));
		m_LabelListCtrl.SetItemText(i,1,m_Table->GetAt(i).name);
		m_LabelListCtrl.SetItemText(i,2,m_Table->GetAt(i).address == -1 ? 
			"undetermined" : ltoa(m_Table->GetAt(i).address,buf,10));
		m_LabelListCtrl.SetItemData(i,m_Table->GetAt(i).line);
	}
	m_LabelListCtrl.SortItems(NumCompare,0);
	SetRedraw(TRUE);
	Invalidate();
}

void CLabelTable::CreateInitialList()
{
	SetRedraw(FALSE);
	while (m_LabelListCtrl.DeleteColumn(0));
	m_LabelListCtrl.InsertColumn(0,"Line",LVCFMT_LEFT,50,-1);
	m_LabelListCtrl.InsertColumn(1,"Label",LVCFMT_LEFT,150,-1);
	m_LabelListCtrl.InsertColumn(2,"Address",LVCFMT_LEFT,100,-1);
	OnUpdate();
	SetRedraw(TRUE);
	Invalidate();
}

void CLabelTable::OnSize(UINT nType, int cx, int cy) 
{
	CRect buttonPos, rect;
	CRect clientRect, windowRect;
	CDialog::OnSize(nType, cx, cy);
	if (IsWindow(m_LabelListCtrl.m_hWnd))
	{
		m_LabelListCtrl.GetWindowRect(&buttonPos);
		ScreenToClient(&buttonPos);
		buttonPos.bottom += (cy - m_oldCY);
		buttonPos.right += (cx - m_oldCX);
		m_LabelListCtrl.MoveWindow(buttonPos,TRUE);

		m_OKButton.GetWindowRect(&buttonPos);
		ScreenToClient(&buttonPos);
		buttonPos.OffsetRect(cx - m_oldCX, cy - m_oldCY);
		m_OKButton.MoveWindow(buttonPos,TRUE);

		m_UpdateButton.GetWindowRect(&buttonPos);
		ScreenToClient(&buttonPos);
		buttonPos.OffsetRect(0, cy - m_oldCY);
		m_UpdateButton.MoveWindow(buttonPos,TRUE);

		// Save the window size to the registry if that option is selected
		
		if (theApp.m_SaveWindowPositions)
		{
			GetWindowRect(&rect);
			theApp.m_WindowStates.size.label.x = rect.right - rect.left;
			theApp.m_WindowStates.size.label.y = rect.bottom - rect.top;
		}
	}
	// Update these values even if this is the first time
	m_oldCX = cx;
	m_oldCY = cy;

}

void CLabelTable::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
{
	CDialog::OnGetMinMaxInfo(lpMMI);
	lpMMI->ptMinTrackSize = CPoint(175,135);
}

void CLabelTable::SetTable(LabelArray *pTable)
{
	m_Table = pTable;
}

void CLabelTable::ExternalUpdate()
{
	if (m_Dead == FALSE)
		OnUpdate();
}


void CLabelTable::OnClose() 
{
	m_Dead = TRUE;
	CDialog::OnClose();
}

LabelArray * CLabelTable::GetTable()
{
	return m_Table;
}

void CLabelTable::OnOK() 
{
	m_Dead = TRUE;
	CDialog::OnOK();
}

void CLabelTable::OnCancel() 
{
	m_Dead = TRUE;
	CDialog::OnCancel();
}

void CLabelTable::OnMove(int x, int y) 
{
	CRect rect;
	CDialog::OnMove(x, y);
	if (IsWindow(m_LabelListCtrl.m_hWnd))
	{
		if (theApp.m_SaveWindowPositions)
		{
			GetWindowRect(&rect);
			theApp.m_WindowStates.pos.label.x = rect.left;
			theApp.m_WindowStates.pos.label.y = rect.top;
		}
	}
}


void CLabelTable::AddOneLabel(long i)
{
	char buf[10];
	m_LabelListCtrl.InsertItem(i,ltoa(m_Table->GetAt(i).line,buf,10));
	m_LabelListCtrl.SetItemText(i,1,m_Table->GetAt(i).name);
	m_LabelListCtrl.SetItemText(i,2,m_Table->GetAt(i).address == -1 ? 
		"undetermined" : ltoa(m_Table->GetAt(i).address,buf,10));
	m_LabelListCtrl.SetItemData(i,m_Table->GetAt(i).line);
	m_LabelListCtrl.SortItems(NumCompare,0);

}

BOOL CLabelTable::OnInitDialog() 
{
	CDialog::OnInitDialog();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
