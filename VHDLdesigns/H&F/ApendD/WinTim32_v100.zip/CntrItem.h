// CntrItem.h : interface of the CWinTim32CntrItem class
//

#if !defined(AFX_CNTRITEM_H__44ED1E28_5CA7_11D3_B4AB_004005A3D75D__INCLUDED_)
#define AFX_CNTRITEM_H__44ED1E28_5CA7_11D3_B4AB_004005A3D75D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CWinTim32Doc;
class CWinTim32View;

class CWinTim32CntrItem : public CRichEditCntrItem
{
	DECLARE_SERIAL(CWinTim32CntrItem)

// Constructors
public:
	CWinTim32CntrItem(REOBJECT* preo = NULL, CWinTim32Doc* pContainer = NULL);
		// Note: pContainer is allowed to be NULL to enable IMPLEMENT_SERIALIZE.
		//  IMPLEMENT_SERIALIZE requires the class have a constructor with
		//  zero arguments.  Normally, OLE items are constructed with a
		//  non-NULL document pointer.

// Attributes
public:
	CWinTim32Doc* GetDocument()
		{ return (CWinTim32Doc*)CRichEditCntrItem::GetDocument(); }
	CWinTim32View* GetActiveView()
		{ return (CWinTim32View*)CRichEditCntrItem::GetActiveView(); }

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWinTim32CntrItem)
	public:
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	~CWinTim32CntrItem();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CNTRITEM_H__44ED1E28_5CA7_11D3_B4AB_004005A3D75D__INCLUDED_)
