// WinTim32Doc.cpp : implementation of the CWinTim32Doc class
//

#include "stdafx.h"
#include "WinTim32.h"

#include "WinTim32Doc.h"
#include "CntrItem.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWinTim32Doc

IMPLEMENT_DYNCREATE(CWinTim32Doc, CRichEditDoc)

BEGIN_MESSAGE_MAP(CWinTim32Doc, CRichEditDoc)
	//{{AFX_MSG_MAP(CWinTim32Doc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Enable default OLE container implementation
	ON_UPDATE_COMMAND_UI(ID_OLE_EDIT_LINKS, CRichEditDoc::OnUpdateEditLinksMenu)
	ON_COMMAND(ID_OLE_EDIT_LINKS, CRichEditDoc::OnEditLinks)
	ON_UPDATE_COMMAND_UI_RANGE(ID_OLE_VERB_FIRST, ID_OLE_VERB_LAST, CRichEditDoc::OnUpdateObjectVerbMenu)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWinTim32Doc construction/destruction

CWinTim32Doc::CWinTim32Doc()
{
	// Use OLE compound files
//	EnableCompoundFile();

}

CWinTim32Doc::~CWinTim32Doc()
{
}

BOOL CWinTim32Doc::OnNewDocument()
{
	if (!CRichEditDoc::OnNewDocument())
		return FALSE;

	return TRUE;
}

CRichEditCntrItem* CWinTim32Doc::CreateClientItem(REOBJECT* preo) const
{
	// cast away constness of this
	return new CWinTim32CntrItem(preo, (CWinTim32Doc*) this);
}



/////////////////////////////////////////////////////////////////////////////
// CWinTim32Doc serialization

void CWinTim32Doc::Serialize(CArchive& ar)
{
	BOOL oldRTF = CRichEditDoc::m_bRTF;
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}

	// Calling the base class CRichEditDoc enables serialization
	//  of the container document's COleClientItem objects.
	// TODO: set CRichEditDoc::m_bRTF = FALSE if you are serializing as text
	CRichEditDoc::m_bRTF = FALSE;
	CRichEditDoc::Serialize(ar);
	CRichEditDoc::m_bRTF = oldRTF;
}

/////////////////////////////////////////////////////////////////////////////
// CWinTim32Doc diagnostics

#ifdef _DEBUG
void CWinTim32Doc::AssertValid() const
{
	CRichEditDoc::AssertValid();
}

void CWinTim32Doc::Dump(CDumpContext& dc) const
{
	CRichEditDoc::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CWinTim32Doc commands
