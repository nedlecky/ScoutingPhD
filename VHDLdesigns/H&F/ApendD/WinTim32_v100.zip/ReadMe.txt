Known issues with WinTim32 v1.0:

 - Tabstops may not be manually set
 - The label table floating window is not complete
 - There are no temporary labels available (for use in MACROs)
 - Autoindent is not incredibly clever
 - The output dialog cannot be resized with the mouse properly
 - Undo does not work properly at all
 - The "colors" tab in the options box only works after a file is opened
 - The output listing does not list nested macros very well

Fixed in version 1.0.0.2:

 - If the save-as dialog was canceled, WinTim32 saved the file anyway
 - Some bugs in the IF/ELSE/ENDIF functionality
 - Sorted the symbol table
