// WinTim32.h : main header file for the WINTIM32 application
//

#define MYWM_GETHELP	32001

#if !defined(AFX_WINTIM32_H__44ED1E1B_5CA7_11D3_B4AB_004005A3D75D__INCLUDED_)
#define AFX_WINTIM32_H__44ED1E1B_5CA7_11D3_B4AB_004005A3D75D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

// This is the maximum length for syntax highlighting
#define MAX_RELINE 1022

// These are the standard characters for assembly processing
#define COMMENTCHAR ';'
#define LABELCHAR ':'
#define NUMERICCHAR '#'

// These are some standard definitions for addresses
#define ADDRESS unsigned long
#define UNKNOWN_ADDRESS 0xffffffff
#define ADDRESS_ONLY -1

#define WT_INDEXBYSIZE		2
#define WT_INDEXBYONE		1

enum WTFileTypes { UntypedFile, AssemblyFile, MetaFile, PlainText };

#include "resource.h"       // main symbols
#include "LabelTable.h"
#include "Syntax.h"
#include "ThreadWaitDlg.h"	// Added by ClassView

////////////////////////////////////////////////////////////////////////////
// Inline functions for easy readability in other functions
////////////////////////////////////////////////////////////////////////////

BOOL inline ispurewhitespace(char c)
{
	return ((c == ' ') || (c == '\t'));
}

BOOL inline iswhitespace(char c)
{
	return ((c == ' ') || (c == '\t') || (c == '\r') || (c == '\n'));
}

BOOL inline isnewline(char c)
{
	return ((c == '\r') || (c == '\n'));
}

BOOL inline islabelchar(char c)
{
	return (isalnum(c) || c == '.');
}

BOOL inline iskwchar(char c)
{
	return (isalnum(c) || c == '.');
}

BOOL inline isargstring(CString s)
{
	int i;
	for (i = 0; i < s.GetLength(); i++)
	{
		if (!isalnum(s.GetAt(i)))
			if (s.GetAt(i) != '_')
				return FALSE;
	}
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CWinTim32App:
// See WinTim32.cpp for the implementation of this class
//

class CWindowPositions
{
public:
	CPoint label;
	CPoint main;
};

class CWindowSizes
{
public:
	CPoint label;
	CPoint main;
};

class CWindowStates
{
public:
	CWindowPositions pos;
	CWindowSizes size;
};

class CWinTim32App : public CWinApp
{
public:
	int m_OutputFixed;
	int m_OutputPercent;
	int m_OutputType;
	int m_ErrorMax;
	DWORD m_dwWarnings;
	int m_AddressIndexMode;
	long m_Column;
	long m_Line;
	void UpdateStatusBar(CRichEditCtrl *re);
	CRichEditView * m_MasterView;
	CRichEditView * m_pViewCaught;
	CRichEditCtrl * m_pRichEditCaught;
	BOOL m_bCatchNextView;
	COLORREF m_ViewUserKeywordColor;
	BOOL m_bAutoIndent;
	BOOL m_FontChange;
	BOOL m_ColorChange;
	CThreadWaitDlg m_ThreadWaitDlg;
	BOOL m_VisibleLabelTable;
	int m_OffsetY;
	int m_OffsetX;
	void LoadWindowRegistry();
	BOOL m_SaveWindowPositions;
	CSyntax m_Syntax;  // This global syntax object is for general operations
	CWindowStates m_WindowStates;
	unsigned long m_MaxWhite;
	CStatusBar * m_StatusBar;
	void Warning(CString text);
	unsigned long m_MinWhite;
	BOOL m_DynamicTabs;
	long m_FontSize;
	CString m_FontName;
	COLORREF m_ViewKeywordColor;
	COLORREF m_ViewOpcodeColor;
	COLORREF m_ViewCommentColor;
	COLORREF m_ViewStringColor;
	COLORREF m_ViewLabelColor;
	COLORREF m_ViewNormalColor;
	COLORREF m_ViewBGColor;
	int DoOptions();
	void LoadRegistry();
	void WriteRegistry();
	BOOL m_bDragDrop;
	BOOL m_bWordSel;
	CLabelTable m_LabelTableDlg;
	CWinTim32App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWinTim32App)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CWinTim32App)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WINTIM32_H__44ED1E1B_5CA7_11D3_B4AB_004005A3D75D__INCLUDED_)
