#if !defined(AFX_OUTPUTDIALOG_H__7D36ED20_8FE1_11D3_B521_004005A3D75D__INCLUDED_)
#define AFX_OUTPUTDIALOG_H__7D36ED20_8FE1_11D3_B521_004005A3D75D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OutputDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COutputDialog dialog

class COutputDialog : public CDialog
{
// Construction
public:
	COutputDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(COutputDialog)
	enum { IDD = IDD_OUTPUT };
	CEdit	m_OutputCtrl;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COutputDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(COutputDialog)
	virtual BOOL OnInitDialog();
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OUTPUTDIALOG_H__7D36ED20_8FE1_11D3_B521_004005A3D75D__INCLUDED_)
