// ThreadWaitDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WinTim32.h"
#include "ThreadWaitDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern int activeThreadCount;
extern int activeViewCount;

/////////////////////////////////////////////////////////////////////////////
// CThreadWaitDlg dialog


CThreadWaitDlg::CThreadWaitDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CThreadWaitDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CThreadWaitDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CThreadWaitDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CThreadWaitDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CThreadWaitDlg, CDialog)
	//{{AFX_MSG_MAP(CThreadWaitDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CThreadWaitDlg message handlers

int CThreadWaitDlg::DoModal() 
{	
	return CDialog::DoModal();
}

void CThreadWaitDlg::OnCancel() 
{
	// This is dangerous; the remaining threads could access 
	// no longer existing objects and cause crashes on program
	// shutdown.  However, at the moment, this is preferable to 
	// a deadlock.
	activeThreadCount = 0;
	CDialog::OnCancel();
}

BOOL CThreadWaitDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// activeThreadCount = 10; // For testing
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
