#if !defined(AFX_LABELTABLE_H__7B872553_5E3D_11D3_B4AF_004005A3D75D__INCLUDED_)
#define AFX_LABELTABLE_H__7B872553_5E3D_11D3_B4AF_004005A3D75D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Syntax.h"

// LabelTable.h : header file
//


/////////////////////////////////////////////////////////////////////////////
// CLabelTable dialog

class CLabelTable : public CDialog
{
// Construction
public:
	void AddOneLabel(long index);
	LabelArray * GetTable();
	BOOL m_Dead;
	void ExternalUpdate();
	LabelArray * m_Table;
	void SetTable(LabelArray *pTable);
	long m_oldCY;
	long m_oldCX;
	void CreateInitialList();
	CLabelTable(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CLabelTable)
	enum { IDD = IDD_LABELTABLE };
	CButton	m_OKButton;
	CButton	m_UpdateButton;
	CListCtrl	m_LabelListCtrl;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLabelTable)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CLabelTable)
	afx_msg void OnUpdate();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);
	afx_msg void OnClose();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnMove(int x, int y);
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LABELTABLE_H__7B872553_5E3D_11D3_B4AF_004005A3D75D__INCLUDED_)
