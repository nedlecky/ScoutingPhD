// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "WinTim32.h"
#include "process.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CWinTim32App theApp;

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_VIEW_OPTIONS, OnViewOptions)
	ON_WM_MOVE()
	ON_WM_SIZE()
	ON_COMMAND(ID_VIEW_OUTPUTMESSAGES, OnViewOutputMessages)
	ON_WM_LBUTTONDBLCLK()
	ON_COMMAND(ID_HELP_FINDER, OnHelpFinder)
	//}}AFX_MSG_MAP
	// Global help commands
	ON_COMMAND(ID_HELP_FINDER, CMDIFrameWnd::OnHelpFinder)
	ON_COMMAND(ID_HELP, CMDIFrameWnd::OnHelp)
	ON_COMMAND(ID_CONTEXT_HELP, CMDIFrameWnd::OnContextHelp)
	ON_COMMAND(ID_DEFAULT_HELP, CMDIFrameWnd::OnHelpFinder)
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_LINE, CMainFrame::OnUpdateLine)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_LINE,
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{

	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	theApp.m_StatusBar = &m_wndStatusBar;

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	m_wndOutputBar.Create(this,CBRS_BOTTOM,IDD_OUTPUT);
	m_wndOutputBar.EnableDocking(CBRS_ALIGN_BOTTOM | CBRS_ALIGN_TOP);
	EnableDocking(CBRS_ALIGN_BOTTOM | CBRS_ALIGN_TOP);
	DockControlBar(&m_wndOutputBar);
	m_wndOutputBar.SetBarStyle(CBRS_ALIGN_TOP | CBRS_ALIGN_BOTTOM | CBRS_GRIPPER);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CMDIFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


void CMainFrame::OnViewOptions() 
{
	theApp.DoOptions();
}


void CMainFrame::OnMove(int x, int y) 
{
	CRect rect;
	CMDIFrameWnd::OnMove(x, y);
	// Save the window position to the registry if that option is selected
	
	if (IsWindow(m_hWnd))
	{
		if (theApp.m_SaveWindowPositions)
		{
			GetWindowRect(&rect);
			theApp.m_WindowStates.pos.main.x = rect.left;
			theApp.m_WindowStates.pos.main.y = rect.top;
		}
	}
}

void CMainFrame::OnSize(UINT nType, int cx, int cy) 
{
	CRect rect;

	m_wndOutputBar.m_cx = cx;
	m_wndOutputBar.m_cy = cy;
	
	CMDIFrameWnd::OnSize(nType, cx, cy);
	// Save the window size to the registry if that option is selected

	if (IsWindow(m_hWnd))
	{
		if (theApp.m_SaveWindowPositions)
		{
			GetWindowRect(&rect);
			theApp.m_WindowStates.size.main.x = rect.right - rect.left;
			theApp.m_WindowStates.size.main.y = rect.bottom - rect.top;
		}
	}
}

void CMainFrame::OnUpdateLine(CCmdUI *pCmdUI)
{
	CString sText;
	pCmdUI->Enable(TRUE);
	sText.Format("Ln %d, Col %d",theApp.m_Line,theApp.m_Column);
	pCmdUI->SetText(sText);
}


BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext) 
{
	return CMDIFrameWnd::OnCreateClient(lpcs, pContext);
}

void CMainFrame::OnViewOutputMessages() 
{
	if (IsWindow(m_wndOutputBar.GetSafeHwnd()))
	{
		ShowControlBar(&m_wndOutputBar,TRUE, FALSE );
		return;
	}

	m_wndOutputBar.Create(this,CBRS_BOTTOM,IDD_OUTPUT);
	m_wndOutputBar.EnableDocking(CBRS_ALIGN_BOTTOM | CBRS_ALIGN_TOP);
	EnableDocking(CBRS_ALIGN_BOTTOM | CBRS_ALIGN_TOP);
	DockControlBar(&m_wndOutputBar);
	m_wndOutputBar.SetBarStyle(CBRS_ALIGN_TOP | CBRS_ALIGN_BOTTOM | CBRS_GRIPPER);
}


void CMainFrame::ShowOutput()
{
	OnViewOutputMessages();
}

void CMainFrame::PrintError(CString sText)
{
	CEdit *pEdit;

	if (!IsWindow(m_wndOutputBar.GetSafeHwnd()))
		return;

	pEdit = ((CEdit *) (m_wndOutputBar.GetDlgItem(IDC_OUTPUTEDIT)));

	pEdit->SetSel(pEdit->GetLimitText() - 2, pEdit->GetLimitText() - 2,FALSE);
	pEdit->ReplaceSel(sText + "\r\n");
}

void CMainFrame::ClearError()
{
	CEdit *pEdit;

	if (!IsWindow(m_wndOutputBar.GetSafeHwnd()))
		return;

	pEdit = ((CEdit *) (m_wndOutputBar.GetDlgItem(IDC_OUTPUTEDIT)));

	pEdit->SetSel(0,-1,TRUE);
	pEdit->Clear();
}

void CMainFrame::SetErrorRedraw(BOOL bRedraw)
{
	CEdit *pEdit;

	if (!IsWindow(m_wndOutputBar.GetSafeHwnd()))
		return;

	pEdit = ((CEdit *) (m_wndOutputBar.GetDlgItem(IDC_OUTPUTEDIT)));

	pEdit->SetRedraw(bRedraw);
	if (bRedraw)
		pEdit->Invalidate();
	else
		pEdit->SetLimitText(1024*1024);
}

BOOL CMainFrame::OnCommand(WPARAM wParam, LPARAM lParam) 
{

    if (lParam == 0)  // Send from a menu
    {
        switch(wParam)
        {
            case MYWM_GETHELP:
				DoHelp();
                break;
            default: ;
        }
    }	
	return CMDIFrameWnd::OnCommand(wParam, lParam);
}

void CMainFrame::DoHelp()
{
	char *help0 = "winhlp32";
	char help1[MAX_PATH];

	char *helpargv[] = { help0, help1, NULL };

	GetCurrentDirectory(MAX_PATH,help1);

	strcat(help1,"\\WinTim32.hlp");

    _spawnvp(_P_NOWAIT, "winhlp32", helpargv);
}

void CMainFrame::OnHelpFinder() 
{
	AfxGetApp()->m_pMainWnd->SendMessage(WM_COMMAND,MYWM_GETHELP,0);	
}
