// PPColors.cpp : implementation file
//

#include "stdafx.h"
#include "WinTim32.h"
#include "PPColors.h"
#include "Syntax.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPPColors property page

IMPLEMENT_DYNCREATE(CPPColors, CPropertyPage)

CPPColors::CPPColors() : CPropertyPage(CPPColors::IDD)
{
	//{{AFX_DATA_INIT(CPPColors)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPPColors::~CPPColors()
{
}

void CPPColors::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPPColors)
	DDX_Control(pDX, IDC_UKC, m_UserKeywordColorCtrl);
	DDX_Control(pDX, IDC_STC, m_StringColorCtrl);
	DDX_Control(pDX, IDC_FONT, m_FontCtrl);
	DDX_Control(pDX, IDC_OPC, m_OpcodeColorCtrl);
	DDX_Control(pDX, IDC_KWC, m_KeywordColorCtrl);
	DDX_Control(pDX, IDC_SAMPLETEXT, m_SampleTextCtrl);
	DDX_Control(pDX, IDC_BGC, m_BackgroundColorCtrl);
	DDX_Control(pDX, IDC_NTC, m_NormalTextColorCtrl);
	DDX_Control(pDX, IDC_LBC, m_LabelColorCtrl);
	DDX_Control(pDX, IDC_CMC, m_CommentColorCtrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPPColors, CPropertyPage)
	//{{AFX_MSG_MAP(CPPColors)
	ON_BN_CLICKED(IDC_CHANGEBG, OnChangeBG)
	ON_BN_CLICKED(IDC_CHANGENORM, OnChangeNorm)
	ON_BN_CLICKED(IDC_CHANGELABEL, OnChangeLabel)
	ON_BN_CLICKED(IDC_CHANGECOMMENT, OnChangeComment)
	ON_BN_CLICKED(IDC_CHANGEOPCODE, OnChangeOpcode)
	ON_BN_CLICKED(IDC_CHANGEKEYWORD, OnChangeKeyword)
	ON_BN_CLICKED(IDC_CHANGEFONT, OnChangeFont)
	ON_BN_CLICKED(IDC_CHANGESTRING, OnChangeString)
	ON_BN_CLICKED(IDC_CHANGEUSER, OnChangeUser)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPPColors message handlers

extern CWinTim32App theApp;

void CPPColors::OnChangeBG() 
{
	CColorDialog cd(theApp.m_ViewBGColor);
	cd.DoModal();
	theApp.m_ViewBGColor = cd.GetColor();
	theApp.m_Syntax.SyntaxHighlightComplete(&m_SampleTextCtrl);
	m_SampleTextCtrl.Invalidate();
	SetSampleColors();
}

void CPPColors::OnChangeNorm() 
{
	CColorDialog cd(theApp.m_ViewNormalColor);
	cd.DoModal();
	theApp.m_ViewNormalColor = cd.GetColor();
	theApp.m_Syntax.SyntaxHighlightComplete(&m_SampleTextCtrl);
	m_SampleTextCtrl.Invalidate();
	SetSampleColors();
}

BOOL CPPColors::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	SetSampleText();
	SetFontText();
	SetSampleColors();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPPColors::SetSampleText()
{
	CString sSample;

	sSample.LoadString(IDS_SAMPLETEXT);
	m_SampleTextCtrl.SetWindowText(sSample);
	theApp.m_Syntax.SyntaxHighlightComplete(&m_SampleTextCtrl);
}

void CPPColors::OnChangeLabel() 
{
	CColorDialog cd(theApp.m_ViewLabelColor);
	cd.DoModal();
	theApp.m_ViewLabelColor = cd.GetColor();
	theApp.m_Syntax.SyntaxHighlightComplete(&m_SampleTextCtrl);
	m_SampleTextCtrl.Invalidate();
	SetSampleColors();
}

void CPPColors::OnChangeComment() 
{
	CColorDialog cd(theApp.m_ViewCommentColor);
	cd.DoModal();
	theApp.m_ViewCommentColor = cd.GetColor();
	theApp.m_Syntax.SyntaxHighlightComplete(&m_SampleTextCtrl);
	m_SampleTextCtrl.Invalidate();
	SetSampleColors();
}

void CPPColors::SetSampleColors()
{
	// This a cheesy way to display a color box, but it works

	m_BackgroundColorCtrl.SetBackgroundColor(FALSE,theApp.m_ViewBGColor);
	m_NormalTextColorCtrl.SetBackgroundColor(FALSE,theApp.m_ViewNormalColor);
	m_LabelColorCtrl.SetBackgroundColor(FALSE,theApp.m_ViewLabelColor);
	m_CommentColorCtrl.SetBackgroundColor(FALSE,theApp.m_ViewCommentColor);
	m_OpcodeColorCtrl.SetBackgroundColor(FALSE,theApp.m_ViewOpcodeColor);
	m_KeywordColorCtrl.SetBackgroundColor(FALSE,theApp.m_ViewKeywordColor);
	m_UserKeywordColorCtrl.SetBackgroundColor(FALSE,theApp.m_ViewUserKeywordColor);
	m_StringColorCtrl.SetBackgroundColor(FALSE,theApp.m_ViewStringColor);
}

void CPPColors::OnChangeOpcode() 
{
	CColorDialog cd(theApp.m_ViewOpcodeColor);
	cd.DoModal();
	theApp.m_ViewOpcodeColor = cd.GetColor();
	theApp.m_Syntax.SyntaxHighlightComplete(&m_SampleTextCtrl);
	m_SampleTextCtrl.Invalidate();
	SetSampleColors();
}

void CPPColors::OnChangeKeyword() 
{
	CColorDialog cd(theApp.m_ViewKeywordColor);
	cd.DoModal();
	theApp.m_ViewKeywordColor = cd.GetColor();
	theApp.m_Syntax.SyntaxHighlightComplete(&m_SampleTextCtrl);
	m_SampleTextCtrl.Invalidate();
	SetSampleColors();
}

void CPPColors::OnChangeFont() 
{
	CFontDialog fd;
	CString holdFont;

	holdFont = theApp.m_FontName;
	strncpy(fd.m_cf.lpLogFont->lfFaceName,LPCTSTR(holdFont),LF_FACESIZE);
	fd.m_cf.iPointSize = theApp.m_FontSize;
	fd.DoModal();
	theApp.m_FontName = fd.GetFaceName();
	if (theApp.m_FontName == "")
		theApp.m_FontName = holdFont;
	theApp.m_FontSize = fd.GetSize();
	SetFontText();
	theApp.m_Syntax.SyntaxHighlightComplete(&m_SampleTextCtrl);
	m_SampleTextCtrl.Invalidate();
}

void CPPColors::SetFontText()
{
	char buf[10];
	m_FontCtrl.SetWindowText(CString(theApp.m_FontName) + 
		" (" + CString(ltoa(theApp.m_FontSize/10,buf,10)) + ")");
}

void CPPColors::OnChangeString() 
{
	CColorDialog cd(theApp.m_ViewStringColor);
	cd.DoModal();
	theApp.m_ViewStringColor = cd.GetColor();
	theApp.m_Syntax.SyntaxHighlightComplete(&m_SampleTextCtrl);
	m_SampleTextCtrl.Invalidate();
	SetSampleColors();
}

void CPPColors::OnChangeUser() 
{
	CColorDialog cd(theApp.m_ViewUserKeywordColor);
	cd.DoModal();
	theApp.m_ViewUserKeywordColor = cd.GetColor();
	theApp.m_Syntax.SyntaxHighlightComplete(&m_SampleTextCtrl);
	m_SampleTextCtrl.Invalidate();
	SetSampleColors();
}
