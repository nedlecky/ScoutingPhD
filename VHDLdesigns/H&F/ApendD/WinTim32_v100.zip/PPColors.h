#if !defined(AFX_PPCOLORS_H__FF572025_5D63_11D3_B4AD_004005A3D75D__INCLUDED_)
#define AFX_PPCOLORS_H__FF572025_5D63_11D3_B4AD_004005A3D75D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PPColors.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPPColors dialog

class CPPColors : public CPropertyPage
{
	DECLARE_DYNCREATE(CPPColors)

// Construction
public:
	void SetFontText();
	void SetSampleColors();
	void SetSampleText();
	CPPColors();
	~CPPColors();

// Dialog Data
	//{{AFX_DATA(CPPColors)
	enum { IDD = IDD_PPCOLOR };
	CRichEditCtrl	m_UserKeywordColorCtrl;
	CRichEditCtrl	m_StringColorCtrl;
	CRichEditCtrl	m_FontCtrl;
	CRichEditCtrl	m_OpcodeColorCtrl;
	CRichEditCtrl	m_KeywordColorCtrl;
	CRichEditCtrl	m_SampleTextCtrl;
	CRichEditCtrl	m_BackgroundColorCtrl;
	CRichEditCtrl	m_NormalTextColorCtrl;
	CRichEditCtrl	m_LabelColorCtrl;
	CRichEditCtrl	m_CommentColorCtrl;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPPColors)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPPColors)
	afx_msg void OnChangeBG();
	afx_msg void OnChangeNorm();
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeLabel();
	afx_msg void OnChangeComment();
	afx_msg void OnChangeOpcode();
	afx_msg void OnChangeKeyword();
	afx_msg void OnChangeFont();
	afx_msg void OnChangeString();
	afx_msg void OnChangeUser();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PPCOLORS_H__FF572025_5D63_11D3_B4AD_004005A3D75D__INCLUDED_)
