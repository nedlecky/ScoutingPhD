// PPWarnings.cpp : implementation file
//

#include "stdafx.h"
#include "WinTim32.h"
#include "PPWarnings.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPPWarnings dialog


CPPWarnings::CPPWarnings()
	: CPropertyPage(CPPWarnings::IDD)
{
	//{{AFX_DATA_INIT(CPPWarnings)
	m_EndBeforeEOF = FALSE;
	m_DEFInAsm = FALSE;
	m_OpcodeLengthIncons = FALSE;
	m_OpcodeWordIncons = FALSE;
	m_FORMIncons = FALSE;
	m_InvalidListOp = FALSE;
	m_InsufficientArgs = FALSE;
	//}}AFX_DATA_INIT
}


void CPPWarnings::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPPWarnings)
	DDX_Check(pDX, IDC_CHECK1, m_EndBeforeEOF);
	DDX_Check(pDX, IDC_CHECK2, m_DEFInAsm);
	DDX_Check(pDX, IDC_CHECK3, m_OpcodeLengthIncons);
	DDX_Check(pDX, IDC_CHECK4, m_OpcodeWordIncons);
	DDX_Check(pDX, IDC_CHECK6, m_FORMIncons);
	DDX_Check(pDX, IDC_CHECK7, m_InvalidListOp);
	DDX_Check(pDX, IDC_CHECK5, m_InsufficientArgs);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPPWarnings, CDialog)
	//{{AFX_MSG_MAP(CPPWarnings)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPPWarnings message handlers
