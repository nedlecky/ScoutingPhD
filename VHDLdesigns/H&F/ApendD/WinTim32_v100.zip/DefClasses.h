// This file includes the definition classes for the meta assembler

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "WinTim32.h"
#include "afxtempl.h"

// A CDefinitionField is an element of a definition, holding one field
class CDefinitionField
{
public:
	short iBits;		// The number of bits in the field
	BOOL bConstant;		// Whether the field is a constant value
	BOOL bDCare;        // Whether this field is a don't-care value
	ADDRESS lValue;      // The constant value, if any

public:
	// Constructors
	CDefinitionField();
	CDefinitionField(short bits, BOOL isconstant, BOOL isdcare, ADDRESS value);
	CDefinitionField(CDefinitionField &copy);
	operator=(const CDefinitionField &copy);
};

typedef CArray<CDefinitionField, CDefinitionField> FieldsArray;

// The CDefinition class is a definition of an assembler opcode
// in variable format.

class CDefinition
{
public:
	CString sOpcode;	// The name of the opcode
	short iLength;      // The total number of bits in the definition
	short iFields;      // The number of fields in the definition
	BOOL bValid;        // Whether or not this definition is complete
	FieldsArray aFields;// The listing of fields

 public:
	// Constructors
	CDefinition();
	CDefinition(CString opcode, short length, short fields, BOOL valid);
	CDefinition(CDefinition &copy);
	operator=(CDefinition &copy);
};

typedef CArray<CDefinition, CDefinition> DefArray;

// The CSyntaxData class holds some of the information needed by the syntax
// highlighting object (the definitons array and file type)

class CSyntaxData
{
public:
	WTFileTypes FileType;
	DefArray *pDefArray;
};

