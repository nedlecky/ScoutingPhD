#if !defined(AFX_THREADWAITDLG_H__4DB5D2D4_619A_11D3_B4B7_004005A3D75D__INCLUDED_)
#define AFX_THREADWAITDLG_H__4DB5D2D4_619A_11D3_B4B7_004005A3D75D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ThreadWaitDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CThreadWaitDlg dialog

class CThreadWaitDlg : public CDialog
{
// Construction
public:
	CThreadWaitDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CThreadWaitDlg)
	enum { IDD = IDD_ACTIVETHREAD };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CThreadWaitDlg)
	public:
	virtual int DoModal();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CThreadWaitDlg)
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_THREADWAITDLG_H__4DB5D2D4_619A_11D3_B4B7_004005A3D75D__INCLUDED_)
