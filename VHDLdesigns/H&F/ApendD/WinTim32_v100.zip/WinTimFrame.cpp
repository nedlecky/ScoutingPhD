// WinTimFrame.cpp : implementation file
//

#include "stdafx.h"
#include "WinTim32.h"
#include "WinTimFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWinTimFrame

IMPLEMENT_DYNCREATE(CWinTimFrame, CFrameWnd)

CWinTimFrame::CWinTimFrame()
{
}

CWinTimFrame::~CWinTimFrame()
{
}


BEGIN_MESSAGE_MAP(CWinTimFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CWinTimFrame)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWinTimFrame message handlers
