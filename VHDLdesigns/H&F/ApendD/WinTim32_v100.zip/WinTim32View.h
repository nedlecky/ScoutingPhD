// WinTim32View.h : interface of the CWinTim32View class
//
/////////////////////////////////////////////////////////////////////////////

#define MAX_RECURSION_DEPTH	64

#if !defined(AFX_WINTIM32VIEW_H__44ED1E25_5CA7_11D3_B4AB_004005A3D75D__INCLUDED_)
#define AFX_WINTIM32VIEW_H__44ED1E25_5CA7_11D3_B4AB_004005A3D75D__INCLUDED_

#include "LabelTable.h"	// Added by ClassView
#include "DefClasses.h"
#include "MainFrm.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

enum Op { None, Add, Subtract, Multiply, Divide, Logical_And,
		  Logical_Or, Logical_Xor, If_Equal, If_Not_Equal,
		  If_Greater_Than, If_Greater_Than_Or_Equal,
		  If_Less_Than, If_Less_Than_Or_Equal,
		  Logical_Shift_Right, Logical_Shift_Left,
		};

class CWinTim32CntrItem;

extern CWinTim32App theApp;

enum MView { MVIEW_ERROR, MVIEW_MASTER, MVIEW_SLAVE };

// The COrigin class helps us relocate code simply
class COrigin
{
public:
	ADDRESS adrCurrent;  // The address at which to alter the addressing
	ADDRESS adrNew;      // The new address to use
	long	lLine;       // The source line at which the change occurred

public:  // Constructors
	COrigin();
	COrigin(ADDRESS current, ADDRESS newadr, long line);
};

typedef CArray<COrigin, COrigin> OriginArray;

// The CProcessPointers class is used by the ProcessDocument thread function
// to optain pointers to important data structures otherwise inaccessible to it
class CProcessPointers
{
public:
	CRichEditCtrl *pRichEditCtrl;
	BOOL *pInterruptProcessing;
	BOOL *pTimeToDie;
	BOOL *pDocumentUpdated;
	BOOL *pLabelTableShown;
	CDocument *pDoc;
	HWND hWnd;
};

// The CToken is the fundamental object in the token array, containing
// one keyword, pseudo-op, or user-defined value
class CToken
{
public:
	union
	{
		unsigned short tint;  // should be 2 bytes
		char tchar[2];
	} token;

	// Constructors
	CToken();
	CToken(UINT iToken);
	CToken(char c1, char c2);
};

typedef CArray<CToken, CToken> TokenArray;

enum MacroType { Normal, Substitution };

// The CMacro class embodies an assembler macro with its own token array
class CMacro
{
public:
	CString macro;
	TokenArray contents;
	long lStartLine;
	MacroType type;

	// Constructors
	CMacro();
	CMacro(CString sMacro, long lStart, MacroType iType);
	CMacro(CString sMacro, TokenArray *ta, long lStart, MacroType iType);
	CMacro(CMacro &copy);
	operator=(CMacro &copy);
	~CMacro();
};

typedef CArray<CMacro, CMacro> MacroArray;

// The CError class holds one error message in symbolic form
enum ErrorLevel { Notice, Warning, Error, FatalError };

class CError
{
public:
	long lErrorCode;
	long lErrorLine;
	long lErrorToken;
	ErrorLevel eSeverity;
	CString sExtraText;
	long lLocalLine;
	long lMacroNum;

	// Constructors
	CError();
	CError(long iError, long lLine, long lToken, long lLocal, long lMacro,  enum ErrorLevel ErrorType = Error, CString sExtra= "");
};

typedef CArray<CError, CError> ErrorArray;

// The CListOptions class holds the arguments of the LIST directive
class CListOptions
{
public:
	DWORD dwFlags;

	// Constructors
	CListOptions();
	CListOptions(DWORD flags);
};

// The CDefinitions class embodies some of the values that are consistent
// across a program, such as the title and word size
class CDefinitions
{
public:
	CString sTitle;  // Keyword TITLE
	CString sTitle2; // Keyword TITLE2
	int iWordSize;   // Keyword WORD
	int iPageWidth;  // Keyword WIDTH
	int iPageLines;  // Keyword LINES
	int iDCareBit;   // value of DCARE
	CListOptions listOptions;  // Keyword LIST
	CString sObjectCodeFormat;  // Keyword FORM
	CString sHeader;

public:
	// Constructors
	CDefinitions();
	Initialize(BOOL bComplete = TRUE);

};

// The CSymbol class holds a symbol, the line on which it resides, and
// the address (or value) it represents, as well as the token index at
// which the symbol is declared (for reparsing).
class CSymbol
{
public:
	CString sLabel;      // The symbol itself
	long lLine;          // The line on which the symbol's definition resides
	ADDRESS lAddress;    // 32-bit value maximum to be substituted for the symbol
	long lToken;         // The precise location of the symbol's declaration
	short iSymbolLength; // The bit-length of the symbol
	BOOL bAddressValid;  // Whether or not the address has been evaluated

public:
	// Constructors
	CSymbol();
	CSymbol(CString Label, long Line, ADDRESS Address, long Token, short Length, BOOL Valid = FALSE);
	CSymbol(CSymbol &copy);
	operator=(const CSymbol &copy);
};


class CSymbolMap: public CMap<CString, LPCTSTR, CSymbol, CSymbol&>
{
public:
	virtual UINT AFXAPI HashKey(CString key);
};

typedef CSymbolMap SymbolArray;

typedef CMap<CString, LPCTSTR, short, short> TokenMap;

// The CTokenStackElement is the fundamental unit in the token stack, used
// for macro expansion
class CTokenStackElement
{
public:
	TokenArray *pTokenArray;
	long index;
	long lMacro;
	long lLocalLine;

	// Constructors
	CTokenStackElement();
	CTokenStackElement(TokenArray *ta, long idx, long macro, long local);
};

typedef CArray<CTokenStackElement, CTokenStackElement> TokenStack;

// The CSourceRef class holds the source code information that
// can be used to print the .MIF file using only the binary
// data

class CSourceRef
{
public:
	short iByteLength;	// The length of the object code for this line
	long iSourceLine;	// The source line for this chunk of object code
	short iMacro;		// The macro in which this code is located
	long lLocalLine;	// The macro local line on which this code is located

public:
	CSourceRef();
	CSourceRef(short length, long line, short macro, long local);
};

typedef CArray<CSourceRef, CSourceRef> CSourceRefArray;

// The CSecondPassData class contains the line and address of
// each assembly line that contained an unreconcilable label

class CSecondPassData
{
public:
	long iSourceLine;
	ADDRESS dataAddress;
	ADDRESS dataSingleAddress;

public:
	CSecondPassData();
	CSecondPassData(long line, ADDRESS address, ADDRESS single);
};

typedef CArray<CSecondPassData, CSecondPassData> CSecondPassArray;

/*
// The CVariableSubstitution class is a direct substitution of one string
// for another, anywhere in the metafile
class CVariableSubstitution
{
public:
	CString sText;
	CString sSub;

	// Constructors
	CVariableSubstitution();
	CVariableSubstitution(CString text, CString sub);
};

typedef CArray<CVariableSubstitution, CVariableSubstitution> SubArray;
*/

///////////////////////////////////////////////////////////////////////
// Microsoft CRichEditView base class

class CWinTim32View : public CRichEditView
{
protected: // create from serialization only
	CWinTim32View();
	DECLARE_DYNCREATE(CWinTim32View)

// Attributes
public:
	CWinTim32Doc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWinTim32View)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void Serialize(CArchive& ar);
	virtual void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	virtual void OnDraw(CDC* pDC);
	virtual void OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView);
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
public:
	CString GetSavingName();
	BOOL m_bInIF;
	BOOL m_bIfConditional;
	BOOL m_bShouldAssemble;
	CString m_FatalExtraText;
	EDITSTREAM m_EditStream;
	BOOL NewLineCheck(CToken tok, long &line, BOOL increment = TRUE);
	OriginArray m_OrgArray;
	TokenMap m_TokenMap;
	CSymbol m_Symbol;
	void CopySymbolArray(SymbolArray *sa1, SymbolArray *sa2);
	CString GetOpName(Op Operator);
	BOOL HasPrecedence(Op NextOp, long index, TokenArray *ta, long &nLine);
	int m_iOpsOrderLevel;
	long m_lCurrentMacro;
	long GetMacroNum();
	long m_lLocalLine;
	int m_EvalDepth;
	long PeekTokenArray(long &lMacroIndex, int iDepth, long *local = NULL);
	CString FormatBits(CByteArray *ba, long &iByteIndex, long iByteMax);
	BOOL ProcessGenericToken(CToken tok, TokenArray *(&ta), long &index, long &nLine, BOOL &TerminateProcessing);
	MView IsMasterView();
	CRichEditCtrl * ViewOf(CString sCaption);
	CString GetTokenName(CToken token);
	CString sError;
	CMainFrame *GetMainFrame();
	void CheckIgnoreLF(CToken &tok, TokenArray *ta, long &nLine, long &index);
	CPoint m_LastPoint;
	BOOL m_MMScroll;
	float m_RatioY;
	float m_RatioX;
	int m_iMoveX;
	int m_iMoveY;
	CPoint m_OriginalPoint;
	int m_OrigScrollHoriz;
	int m_OrigScrollVert;
	SCROLLINFO m_HScrollInfo;
	SCROLLINFO m_VScrollInfo;
	HCURSOR m_hOldCursor;
	MView MasterView();
	CWinTim32View * m_MasterView;
	CString GetErrorText(long code);
	void DumpByteArray(CByteArray *ba, CSourceRefArray *sra, long iStart, long iFinish, CRichEditCtrl *re, BOOL bMIF = FALSE);
	CString GetEditLine(long nLine, CRichEditCtrl *re);
	void DisplayBitstring(CByteArray *aBits, long nLine);
	CSecondPassArray m_SecondPassLines;
	ADDRESS m_Origin;
	ADDRESS AssembleInstruction(long index, SymbolArray *sa, TokenArray *ta, CByteArray *ba, ADDRESS aNext, ADDRESS aNextSingle, long *newindex, long &nLine, int Pass);
	CSourceRefArray m_SourceRef;
	CByteArray m_BinaryData;
	void RemoveInvalidEntries(SymbolArray *sa);
	void CreateObjectFile();
	CSyntaxData m_SyntaxData;
	void SetSyntaxData();
	void CheckFileType();
	WTFileTypes m_FileType;
	void DumpDefinitionTable(CRichEditCtrl *re);
	char m_buf[512];  // random temporary string buffer
	TokenArray m_CurrentMacroTokenArray;
	TokenStack m_TokenStack;
//	SubArray m_SubArray;
	void PullTokenArray(TokenArray **ta, long *index, long *macro, long *local);
	int PushTokenArray(TokenArray *ta, long index, long lMacro, long local);
	void DisplayErrors();
	void DumpSymbolTable(SymbolArray *sa, CRichEditCtrl *re);
	long SkipRestOfLine(long &nLine, long index, TokenArray *ta, BOOL AddErrors = TRUE);
	BOOL TokenIsBaseNum(long nLine, long index, long &lArg, TokenArray *ta, long *numLength, BOOL AddErrors = TRUE);
//	BOOL SymbolInTable(CString sTok, SymbolArray *sa, long &lSymbolIndex);
	BOOL CanEvaluate(long index, TokenArray *(&ta), ADDRESS *address, SymbolArray *sa,
		 long &nLine, long *newindex, short *iLength, DWORD *iFlags, BOOL bLabelErrors,
		 long CurrentValue = 0, BOOL bCurrentValueValid = FALSE, ADDRESS EquateAddress = 0 );
	long AddDefinition(long index, CString sRecentSymbol, TokenArray *ta, long &nLine);
	long EquateSymbol(long index,CString sRecentSymbol,SymbolArray *sa, TokenArray *ta, long nLine, ADDRESS aNext = 0);
	long SkipString(long nLine, long index, TokenArray *ta, BOOL AddErrors = TRUE);
	BOOL TokenIsStr(long nLine, long index, CString &sTok, TokenArray *ta, BOOL AddErrors = TRUE);
	BOOL TokenIsNum(long nLine, long index, long &lArg, TokenArray *ta, BOOL AddErrors = TRUE);
	void AddError(long iErrorValue, long lSourceLine, long lTokenIndex, CString sExtra = "");
	void UpdateFormat();
	char m_cBuffer[MAX_RELINE];
	CDefinitions m_Definitions;
	SymbolArray m_SymbolTable;
	ErrorArray m_ErrorArray;
	void TokenArrayDump(TokenArray *ta);
	CString TokenString(TokenArray *tArray,long i);
	void CheckToken(TokenArray *ta, CString sTest,long *index, BOOL bAssemblyFile, BOOL &bDefType, BOOL &bNumeric);
	long m_ErrorLine;
	long m_ErrorCode;
	BOOL m_FatalError;
	void DoFatalError();
	void CreateDefinitionFile();
	void TokenizeMetaFile(TokenArray *ta, BOOL bAssemblyFile = FALSE, CRichEditCtrl *pREC = NULL, BOOL bAddEndLine = TRUE);
	MacroArray m_MacroTable;
	TokenArray m_TokenArray;
	void GenerateMacroTable();
	void CheckFirstLine();
	long m_LastTopLine;
	BOOL m_LabelTableShown;
	BOOL m_DocumentUpdated;
	BOOL m_TimeToDie;
	BOOL m_InterruptProcessing;
	CWinThread * m_SyntaxThread;
	CProcessPointers m_passPtrs;
	void HideLabelTable();
	void ShowLabelTable();
	void SyntaxHighlight(long nPrevious = 0, long nNext = 0);
	void SetEditingOptions();
	virtual ~CWinTim32View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CWinTim32View)
	afx_msg void OnDestroy();
	afx_msg void OnViewOptions();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSysChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnEditCut();
	afx_msg void OnEditPaste();
	afx_msg void OnViewRefresh();
	afx_msg void OnViewLabelTable();
	afx_msg void OnAssemblyMetaassembly();
	afx_msg void OnAssemblyAssemble();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnViewAsassemblyfile();
	afx_msg void OnViewAsmetafile();
	afx_msg void OnOutputBinaryData();
	afx_msg void OnViewAsText();
	afx_msg void OnOutputLocalSymbolTable();
	afx_msg void OnOutputCompleteSymbolTable();
	afx_msg void OnOutputAsMIF();
	afx_msg void OnOutputDefinitionTable();
	afx_msg void OnMButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnEditDelete();
	afx_msg void OnUpdateEditDelete(CCmdUI* pCmdUI);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnViewOutputMessages();
	afx_msg void OnEditGotoLine();
	afx_msg void OnFileSaveAs();
	afx_msg void OnFileSave();
	afx_msg void OnHelp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in WinTim32View.cpp
inline CWinTim32Doc* CWinTim32View::GetDocument()
   { return (CWinTim32Doc*)m_pDocument; }
#endif

UINT ProcessDocument( LPVOID pParam );

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WINTIM32VIEW_H__44ED1E25_5CA7_11D3_B4AB_004005A3D75D__INCLUDED_)

