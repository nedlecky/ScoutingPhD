// WinTim32View.cpp : implementation of the CWinTim32View class
//

#include "stdafx.h"
#include "WinTim32.h"

#include "WinTim32Doc.h"
#include "CntrItem.h"
#include "WinTim32View.h"
#include "Syntax.h"
#include "LabelTable.h"
#include "tokens.h"
#include "WinTimErrors.h"
#include "MainFrm.h"
#include "GotoDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define MAX_STACK 50

extern int activeThreadCount;
extern int activeViewCount;
extern char *WinTimKeywords[];
extern char *WinTimPseudoOps[];
extern char *WinTimNumerics[];
extern short WinTimKeywordsIndex[];
extern short WinTimPseudoOpsIndex[];
extern short WinTimNumericsIndex[];

// Definitions array for the meta assembler (only one per instance)
DefArray g_DefArray;

//extern CRITICAL_SECTION global_CS;

/////////////////////////////////////////////////////////////////////////////
// COrigin

COrigin::COrigin()
{
}

COrigin::COrigin(ADDRESS current, ADDRESS newadr, long line)
{
	adrCurrent = current;
	adrNew = newadr;
	lLine = line;
}

/////////////////////////////////////////////////////////////////////////////
// SymbolArray

AFX_INLINE UINT AFXAPI SymbolArray::HashKey(CString key)
{
	if (strlen(key) == 0) return 0;
	return ((UINT) (key.GetAt(0) + key.GetAt(strlen(key)-1))) >> 4;
}

/////////////////////////////////////////////////////////////////////////////
// CSecondPassData

CSecondPassData::CSecondPassData()
{
}

CSecondPassData::CSecondPassData(long line, ADDRESS address, ADDRESS single)
{
	iSourceLine = line;
	dataAddress = address;
	dataSingleAddress = single;
}

/////////////////////////////////////////////////////////////////////////////
// CSourceRef

CSourceRef::CSourceRef()
{
}

CSourceRef::CSourceRef(short length, long line, short macro, long local)
{
	iByteLength = length;
	iSourceLine = line;
	iMacro = macro;
	lLocalLine = local;
}

/////////////////////////////////////////////////////////////////////////////
// CDefinitionField

CDefinitionField::CDefinitionField()
{
}

CDefinitionField::CDefinitionField(short bits, BOOL isconstant, BOOL isdcare, ADDRESS value)
{
	iBits = bits;
	bConstant = isconstant;
	lValue = value;
	bDCare = isdcare;
}

// Copy constructor
CDefinitionField::CDefinitionField(CDefinitionField &copy)
{
	iBits = copy.iBits;
	bConstant = copy.bConstant;
	bDCare = copy.bDCare;
	lValue = copy.lValue;
}

// Overloaded =
CDefinitionField::operator=(const CDefinitionField &copy)
{
	iBits = copy.iBits;
	bConstant = copy.bConstant;
	lValue = copy.lValue;
	bDCare = copy.bDCare;
}

/////////////////////////////////////////////////////////////////////////////
// CDefinition

CDefinition::CDefinition()
{
}

CDefinition::CDefinition(CString opcode, short length, short fields, BOOL valid)
{
	sOpcode = opcode;
	iLength = length;
	iFields = fields;
	bValid = valid;
}

// Copy constructor
CDefinition::CDefinition(CDefinition &copy)
{
	sOpcode = copy.sOpcode;
	iLength = copy.iLength;
	iFields = copy.iFields;
	bValid = copy.bValid;

	aFields.Copy(copy.aFields);
}

// Overloaded =

CDefinition::operator=(CDefinition &copy)
{
	sOpcode = copy.sOpcode;
	iLength = copy.iLength;
	iFields = copy.iFields;
	bValid = copy.bValid;

	aFields.Copy(copy.aFields);
}

/*
/////////////////////////////////////////////////////////////////////////////
// CVariableSubstitution

CVariableSubstitution::CVariableSubstitution()
{
}

CVariableSubstitution::CVariableSubstitution(CString text, CString sub)
{
	sText = text;
	sSub = sub;
}
*/
/////////////////////////////////////////////////////////////////////////////
// CTokenStackElement

CTokenStackElement::CTokenStackElement()
{
}

CTokenStackElement::CTokenStackElement(TokenArray *ta, long idx, long macro, long local)
{
	pTokenArray = ta;
	index = idx;
	lMacro = macro;
	lLocalLine = local;
}

/////////////////////////////////////////////////////////////////////////////
// CSymbol

CSymbol::CSymbol()
{
}

CSymbol::CSymbol(CString Label, long Line, ADDRESS Address, long Token, short Length, BOOL Valid)
{
	sLabel = Label;
	lLine = Line;
	lAddress = Address;
	lToken = Token;
	iSymbolLength = Length;
	bAddressValid = Valid;
}

// Copy constructor
CSymbol::CSymbol(CSymbol &copy)
{
	sLabel = copy.sLabel;
	lLine = copy.lLine;
	lAddress = copy.lAddress;
	lToken = copy.lToken;
	iSymbolLength = copy.iSymbolLength;
	bAddressValid = copy.bAddressValid;
}

// Overloaded =

CSymbol::operator=(const CSymbol &copy)
{
	sLabel = copy.sLabel;
	lLine = copy.lLine;
	lAddress = copy.lAddress;
	lToken = copy.lToken;
	iSymbolLength = copy.iSymbolLength;
	bAddressValid = copy.bAddressValid;
}

/////////////////////////////////////////////////////////////////////////////
// CListOptions

CListOptions::CListOptions()
{
	dwFlags = WTLO_LISTSOURCE;
}

CListOptions::CListOptions(DWORD flags)
{
	dwFlags = flags;
}

/////////////////////////////////////////////////////////////////////////////
// CError

CError::CError()
{
}

CError::CError(long iError, long lLine, long lToken, long lLocal, long lMacro, enum ErrorLevel ErrorType, CString sExtra)
{
	lErrorCode = iError;
	lErrorLine = lLine;
	lErrorToken = lToken;
	eSeverity = ErrorType;
	lLocalLine = lLocal;
	lMacroNum = lMacro;
	sExtraText = sExtra;
}

/////////////////////////////////////////////////////////////////////////////
// CToken

CToken::CToken()
{
}

CToken::CToken(UINT iToken)
{
	token.tint = iToken;
}

CToken::CToken(char c1, char c2)
{
	token.tchar[0] = c1;
	token.tchar[1] = c2;
}

/////////////////////////////////////////////////////////////////////////////
// CDefinitions

CDefinitions::CDefinitions()
{
	sTitle = "Untitled file";
	sTitle2 = "";
	iWordSize = 32;
	iPageWidth = 72;
	iPageLines = 50;
	sObjectCodeFormat = "";
	iDCareBit = 0;
	sHeader = "";
	listOptions.dwFlags = WTLO_DEFAULT;
}

CDefinitions::Initialize(BOOL bComplete)
{
	iPageWidth = 72;
	iPageLines = 50;
	sObjectCodeFormat = "";
	iDCareBit = 0;
	sHeader = "";
	listOptions.dwFlags = WTLO_DEFAULT;
	if (bComplete)
	{
		// Only init these if we have no meta-file values
		sTitle = "Untitled file";
		sTitle2 = "";
		iWordSize = 32;
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMacro

CMacro::CMacro()
{
}

CMacro::CMacro(CString sMacro, long lStart, MacroType iType)
{
	macro = sMacro;
	lStartLine = lStart;
	type = iType;
}

CMacro::CMacro(CString sMacro, TokenArray *ta, long lStart, MacroType iType)
{
	macro = sMacro;
	contents.Copy(*ta);
	lStartLine = lStart;
	type = iType;
}

// Copy constructor
CMacro::CMacro(CMacro &copy)
{
	macro = copy.macro;
	contents.Copy(copy.contents);
	lStartLine = copy.lStartLine;
	type = copy.type;
}

// Overloaded =

CMacro::operator=(CMacro &copy)
{
	macro = copy.macro;
	contents.Copy(copy.contents);
	lStartLine = copy.lStartLine;
	type = copy.type;
}

CMacro::~CMacro()
{
	contents.RemoveAll();
}

/////////////////////////////////////////////////////////////////////////////
// CWinTim32View

IMPLEMENT_DYNCREATE(CWinTim32View, CRichEditView)

BEGIN_MESSAGE_MAP(CWinTim32View, CRichEditView)
	//{{AFX_MSG_MAP(CWinTim32View)
	ON_WM_DESTROY()
	ON_COMMAND(ID_VIEW_OPTIONS, OnViewOptions)
	ON_WM_CREATE()
	ON_WM_LBUTTONDOWN()
	ON_WM_CHAR()
	ON_WM_SYSCHAR()
	ON_WM_KEYDOWN()
	ON_WM_KEYUP()
	ON_WM_ERASEBKGND()
	ON_COMMAND(ID_EDIT_CUT, OnEditCut)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_COMMAND(ID_VIEW_REFRESH, OnViewRefresh)
	ON_COMMAND(ID_VIEW_LABELTABLE, OnViewLabelTable)
	ON_COMMAND(ID_ASSEMBLY_METAASSEMBLY, OnAssemblyMetaassembly)
	ON_COMMAND(ID_ASSEMBLY_ASSEMBLE, OnAssemblyAssemble)
	ON_WM_SIZE()
	ON_COMMAND(ID_VIEW_ASASSEMBLYFILE, OnViewAsassemblyfile)
	ON_COMMAND(ID_VIEW_ASMETAFILE, OnViewAsmetafile)
	ON_COMMAND(ID_OUTPUT_BINARYDATA, OnOutputBinaryData)
	ON_COMMAND(ID_VIEW_ASTEXT, OnViewAsText)
	ON_COMMAND(ID_OUTPUT_LOCALSYMBOLTABLE, OnOutputLocalSymbolTable)
	ON_COMMAND(ID_OUTPUT_COMPLETESYMBOLTABLE, OnOutputCompleteSymbolTable)
	ON_COMMAND(ID_OUTPUT_ASSEMBLEDBINARYDATAMIFFORMAT, OnOutputAsMIF)
	ON_COMMAND(ID_OUTPUT_DEFINITIONTABLE, OnOutputDefinitionTable)
	ON_WM_MBUTTONDOWN()
	ON_WM_MBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
	ON_COMMAND(ID_EDIT_DELETE, OnEditDelete)
	ON_UPDATE_COMMAND_UI(ID_EDIT_DELETE, OnUpdateEditDelete)
	ON_WM_LBUTTONUP()
	ON_COMMAND(ID_VIEW_OUTPUTMESSAGES, OnViewOutputMessages)
	ON_COMMAND(ID_EDIT_GOTOLINE, OnEditGotoLine)
	ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_WM_PAINT()
	ON_WM_ENTERIDLE()
	ON_COMMAND(ID_HELP, OnHelp)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CRichEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CRichEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CRichEditView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWinTim32View construction/destruction

CWinTim32View::CWinTim32View()
{
}

CWinTim32View::~CWinTim32View()
{
}

BOOL CWinTim32View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	return CRichEditView::PreCreateWindow(cs);
}

////////////////////////////////////////////////////////////////////////////
// These global functions are for the AFX Threads
// They should probably be moved into an object
////////////////////////////////////////////////////////////////////////////

void inline EnterCriticalEditSection(long lTimeout = 10)
{
//	EnterCriticalSection(&global_CS);
	/*
	int lTime = 0;
	while (TryEnterCriticalSection(&global_CS) == 0)
	{
		Sleep(10); // Give up timeslice
		lTime++;
		if (lTime > lTimeout)
			break; // Don't hang the program if something stupid happens
	}
	*/
}

void inline LeaveCriticalEditSection()
{
//	LeaveCriticalSection(&global_CS);
}

int x = 0;

DWORD CALLBACK RECallback(
  DWORD dwCookie, // application-defined value
  LPBYTE pbBuff,  // pointer to a buffer
  LONG cb,        // number of bytes to read or write
  LONG *pcb       // pointer to number of bytes transferred
)
{
	CStdioFile *pFile;

	pFile = (CStdioFile *) dwCookie;

	*pcb = pFile->Read(pbBuff,cb);

	return 0;
}

// Global PARAFORMAT variable for data transfer between threads
PARAFORMAT global_paraFormat;

BOOL DoDynamicTabs(HWND hWnd, CRichEditCtrl *re, LabelArray *lTable)
{
// This function will search the list of labels and determine if
// a new tab stop is necessary based on the newest label position.
// Returns FALSE if no change was made to the tabstops
	CFont font;				// Font to determine the widths of strings
	int index;
	long maxWidth = 0;
	long width;
	long currentTab;		// Current tab settings
	long selStart,selEnd;	// Selection settings

	re->GetSel(selStart,selEnd);
	font.CreatePointFont(theApp.m_FontSize,theApp.m_FontName,NULL);
	re->GetDC()->SelectObject(font);
	re->GetParaFormat(global_paraFormat);

	// Make sure there is at least one tabstop
	if (global_paraFormat.cTabCount == 0)
	{
		currentTab = 0;
		global_paraFormat.cTabCount = 1;
	}
	else
		currentTab = global_paraFormat.rgxTabs[0];

	// Tabs are obtained in 1/1440th of an inch
	currentTab = (currentTab * re->GetDC()->GetDeviceCaps(LOGPIXELSX)) / 1440;

	// Check the widths of all of the labels in the label table
	for (index = 0; index < lTable->GetSize(); index++)
	{
		width = re->GetDC()->GetTextExtent(lTable->GetAt(index).name + ":").cx;
		if (width > maxWidth)
			maxWidth = width;
	}

	// Check these widths against the minimum and maximum tabstops set in the options
	if (maxWidth + theApp.m_MinWhite > (unsigned) currentTab)
	{
		global_paraFormat.rgxTabs[0] = ((maxWidth + theApp.m_MinWhite) * 1440) / 
			                     re->GetDC()->GetDeviceCaps(LOGPIXELSX);
		PostMessage(hWnd,WM_COMMAND,MYWM_UPDATEFORMAT,0);
		return TRUE;
	} else if (maxWidth + theApp.m_MaxWhite < (unsigned) currentTab)
	{
		global_paraFormat.rgxTabs[0] = ((maxWidth + theApp.m_MinWhite) * 1440) / 
			                     re->GetDC()->GetDeviceCaps(LOGPIXELSX);
		PostMessage(hWnd,WM_COMMAND,MYWM_UPDATEFORMAT,0);
		return TRUE;
	} else
	{
		return FALSE;
	}
}

UINT ProcessDocument( LPVOID pParam )
// This function is ridiculous; it needs to be broken into more
// manageable elements
{
	CRichEditCtrl *pRichEditCtrl;
	CDocument *pDoc;
	BOOL * pInterruptProcessing;
	LabelArray *currentTable;
	LabelArray *alternateTable;
	LabelArray *temp;
	LabelArray labelTable1;
	LabelArray labelTable2;
	BOOL bModify;

	char line[MAX_RELINE+2];
	int i = 0;
	int j;
	BOOL labelFound = FALSE;
	BOOL tableChanged = FALSE;
	BOOL *pTimeToDie;
	BOOL *pDocumentUpdated;
	BOOL *pLabelTableShown;
	HWND hWnd;

	// This lets the rest of the world know that one more document
	// processing thread needs to terminate before the program
	// should shut down
	activeThreadCount++;

	// Set up the pointers to external objects
	pRichEditCtrl = ((CProcessPointers *) pParam)->pRichEditCtrl;
	pInterruptProcessing = ((CProcessPointers *) pParam)->pInterruptProcessing;
	pTimeToDie = ((CProcessPointers *) pParam)->pTimeToDie;
	pDocumentUpdated = ((CProcessPointers *) pParam)->pDocumentUpdated;
	pLabelTableShown = ((CProcessPointers *) pParam)->pLabelTableShown;
	pDoc = ((CProcessPointers *) pParam)->pDoc;
	hWnd = ((CProcessPointers *) pParam)->hWnd;

	// These local pointers are used so that we can switch which
	// table is being used without having to copy the entirety
	// of the data elements
	currentTable = &labelTable1;
	alternateTable = &labelTable2;

	while (1) // Thread loops until the CWinTim32View dies
	{
		if (*pLabelTableShown)
		{
			// LabelTableShown signifies that the label table was just set to our document
			if (currentTable != theApp.m_LabelTableDlg.GetTable())
			{
				// If the Label Table dialog isn't showing our view, fix that
				theApp.m_LabelTableDlg.SetTable(currentTable);
				theApp.m_LabelTableDlg.CreateInitialList();
				theApp.m_LabelTableDlg.SetWindowText(CString("Label Table for ") + pDoc->GetTitle());
			}
			theApp.m_LabelTableDlg.m_Dead = FALSE;
			*pLabelTableShown = FALSE;  // Don't do this multiple times
		}
		Sleep(200);  // Don't get processor-happy
		i = 0;

		if (*pTimeToDie)
		{
			// We're shutting down; let everyone know we're finished now
			activeThreadCount--;  // Syntax and LabelTable wait for this to be zero
			return 0;
		}

		// If the document hasn't been updated, don't bother re-checking it
		if (*pDocumentUpdated == FALSE)
			continue;

		*pDocumentUpdated = FALSE; // We got it covered

		// Re-create the label table with our alternate LabelArray
		alternateTable->RemoveAll();
		while (i < pRichEditCtrl->GetLineCount())
		{
			memset(line,'\0',MAX_RELINE+2);
			pRichEditCtrl->GetLine(i,line,MAX_RELINE);
			// Search for a label
			j = 0;
			while (line[j] != '\0')
			{
				if (!islabelchar(line[j]))
				{
					if ((j > 0) && (line[j] == LABELCHAR))
					{
						line[j] = '\0';
						alternateTable->Add(CLabel(CString(line),-1,i));
					} else break; // Not a label
				}
				j++;
			}
			i++;
			// If an external action demands an immediate re-parsing, this will
			// reset the line number to 0
			if (*pInterruptProcessing)
				i = 0;
		}
		// Compare the label table with the current one
		tableChanged = FALSE;
		if (alternateTable->GetSize() != currentTable->GetSize())
		{
			tableChanged = TRUE;  // If the sizes are different, it definitely changed
		}
		else
		{
			// Compare each individual element of each table
			for (i = 0; i < currentTable->GetSize(); i++)
			{
				if (currentTable->GetAt(i).line != alternateTable->GetAt(i).line)
				{
					tableChanged = TRUE; // If the line number changed, it's different
					break;
				}
				if (currentTable->GetAt(i).name != alternateTable->GetAt(i).name)
				{
					tableChanged = TRUE; // If the label name changed, it's different
					break;
				}
			}
		}
		// Call for an update if the label table has changed
		if (tableChanged)
		{
			// Switch the two tables
			temp = alternateTable;
			alternateTable = currentTable;
			currentTable = temp;
			theApp.m_LabelTableDlg.SetTable(currentTable);

			if (theApp.m_LabelTableDlg.m_Dead == FALSE)
			{
				if (currentTable == theApp.m_LabelTableDlg.GetTable())
				{
					theApp.m_LabelTableDlg.ExternalUpdate();
				}
			}

			if (theApp.m_DynamicTabs)
			{
				bModify = pRichEditCtrl->GetModify();
				DoDynamicTabs(hWnd, pRichEditCtrl,currentTable);
			}
//				if (DoDynamicTabs(hWnd, pRichEditCtrl,currentTable))
//					pRichEditCtrl->Invalidate(); // If the tabs changed, update the display
		}
	}
	return 0;
}

void CWinTim32View::OnInitialUpdate()
{
	if (theApp.m_bCatchNextView == TRUE)
	{
		// Someone wants our rich edit control, so put it in the global pool
		theApp.m_bCatchNextView = FALSE;
		theApp.m_pRichEditCaught = &(GetRichEditCtrl());
		theApp.m_pViewCaught = this;
		m_MasterView = (CWinTim32View *) theApp.m_MasterView;
	} else
	{
		m_MasterView = NULL;
	}

	activeViewCount++;
	m_InterruptProcessing = FALSE;
	m_TimeToDie = FALSE;
	m_DocumentUpdated = FALSE;
	m_LabelTableShown = FALSE;
	m_LastTopLine = -1;
	m_MMScroll = FALSE;
	m_EvalDepth = 0;
	m_iOpsOrderLevel;
	m_bShouldAssemble = TRUE;
	m_bIfConditional = FALSE;
	m_bInIF = FALSE;

	m_passPtrs.pRichEditCtrl = &(GetRichEditCtrl());
	m_passPtrs.pInterruptProcessing = &m_InterruptProcessing;
	m_passPtrs.pTimeToDie = &m_TimeToDie;
	m_passPtrs.pDocumentUpdated = &m_DocumentUpdated;
	m_passPtrs.pDoc = (CDocument *) GetDocument();
	m_passPtrs.pLabelTableShown = &m_LabelTableShown;
	m_passPtrs.hWnd = GetSafeHwnd();

	m_SyntaxThread = AfxBeginThread(ProcessDocument,&m_passPtrs);

	CRichEditView::OnInitialUpdate();

	m_FileType = AssemblyFile;
	// Set the printing margins (720 twips = 1/2 inch).
	SetMargins(CRect(720, 720, 720, 720));
	m_DocumentUpdated = TRUE;
	m_nWordWrap = WrapNone;
	WrapChanged();
	SetSyntaxData();
	GetDocument()->m_Syntax.InitializeHashTable();
	GetDocument()->m_Syntax.SyntaxHighlightComplete(&(GetRichEditCtrl()),&m_SyntaxData);
	GetRichEditCtrl().SetModify(FALSE);
	theApp.UpdateStatusBar(&(GetRichEditCtrl()));
}

/////////////////////////////////////////////////////////////////////////////
// CWinTim32View printing

BOOL CWinTim32View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}


void CWinTim32View::OnDestroy()
{
	// Deactivate the item on destruction; this is important
	// when a splitter view is being used.
	m_TimeToDie = TRUE;      // Die thread!
	// Wait for the document processing thread to die
	while (activeThreadCount >= activeViewCount)
	{
		Sleep(0);  // Give up your time slice
		// A timeout needs to go in here
	}
	activeViewCount--;
	CRichEditView::OnDestroy();
	COleClientItem* pActiveItem = GetDocument()->GetInPlaceActiveItem(this);
	if (pActiveItem != NULL && pActiveItem->GetActiveView() == this)
	{
		pActiveItem->Deactivate();
		ASSERT(GetDocument()->GetInPlaceActiveItem(this) == NULL);
	}
	if (theApp.m_LabelTableDlg.m_Dead == FALSE)
	{
		theApp.m_LabelTableDlg.SetTable(NULL);
		theApp.m_LabelTableDlg.ExternalUpdate();
	}
}


/////////////////////////////////////////////////////////////////////////////
// CWinTim32View diagnostics

#ifdef _DEBUG
void CWinTim32View::AssertValid() const
{
	CRichEditView::AssertValid();
}

void CWinTim32View::Dump(CDumpContext& dc) const
{
	CRichEditView::Dump(dc);
}

CWinTim32Doc* CWinTim32View::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CWinTim32Doc)));
	return (CWinTim32Doc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CWinTim32View message handlers

void CWinTim32View::Serialize(CArchive& ar) 
{
	CRichEditView::Serialize(ar);
/*
	if (ar.IsStoring())
	{	// storing code
	}
	else
	{	// loading code
	}
*/
}

void CWinTim32View::OnViewOptions() 
{
	CHARFORMAT tempFormat;
	CRichEditCtrl *re;
	long selStart, selEnd;

	if (theApp.DoOptions() != IDCANCEL)
	{
		// Update the editing options for the current view
		SetEditingOptions();
		// If the colors and/or font changed, re-highlight the document
		if (theApp.m_ColorChange)
		{
			// A color change requires a re-processing
			OnViewRefresh();
		} else if (theApp.m_FontChange)
		{
			// A font change only requires a poke at the richedit control
			re = &(GetRichEditCtrl());
			HideCaret();
			re->SetRedraw(FALSE);
			re->GetSel(selStart,selEnd);

			tempFormat.dwMask = CFM_FACE | CFM_SIZE | CFM_BOLD;
			tempFormat.dwEffects = 0;
			tempFormat.yHeight = theApp.m_FontSize * 2;
			strncpy(tempFormat.szFaceName,theApp.m_FontName,sizeof(tempFormat.szFaceName));

			re->SetDefaultCharFormat(tempFormat);
			re->SetSel(0,-1);
			re->SetWordCharFormat(tempFormat);
			re->SetSel(selStart,selEnd);

			re->SetRedraw(TRUE);
			ShowCaret();
			Invalidate();
		}
	}
}

int CWinTim32View::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CRichEditView::OnCreate(lpCreateStruct) == -1)
		return -1;
	SetEditingOptions();
	return 0;
}

void CWinTim32View::SetEditingOptions()
{
	if (theApp.m_bWordSel)
		GetRichEditCtrl().SetOptions(ECOOP_OR, ECO_AUTOWORDSELECTION);
	else
		GetRichEditCtrl().SetOptions(ECOOP_AND, ~(DWORD)ECO_AUTOWORDSELECTION);
}

void CWinTim32View::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// Since a CRichEditCtrl doesn't seem to have any option whatsoever to
	// disable OLE, we turn off drag-and-drop editing by deselecting everything
	long selStart;
	if (theApp.m_bDragDrop == FALSE)
	{
		selStart = GetRichEditCtrl().LineIndex(GetRichEditCtrl().GetFirstVisibleLine());
		GetRichEditCtrl().SetSel(selStart,selStart);
	}
	CRichEditView::OnLButtonDown(nFlags, point);

	theApp.UpdateStatusBar(&(GetRichEditCtrl()));
}

void CWinTim32View::SyntaxHighlight(long nPrevious, long nNext)
{
	unsigned long nLines, index, i;
	long selStart, selEnd;
	CRichEditCtrl *re;

	nLines = GetRichEditCtrl().GetLineCount();
	re = &GetRichEditCtrl();

//	EnterCriticalEditSection();
//	re->SetRedraw(FALSE);
	re->GetSel(selStart,selEnd);

	index = re->LineFromChar(selStart);

	SetSyntaxData();
	for (i = index - nPrevious; i <= index + nNext; i++)
	{
		GetDocument()->m_Syntax.SyntaxHighlightOneLine(i, re, TRUE, &m_SyntaxData);
	}

	re->SetSel(selStart,selEnd);
//	re->SetRedraw(TRUE);
//	LeaveCriticalEditSection();
//	re->Invalidate();
}

void CWinTim32View::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	CRichEditView::OnUpdate(pSender, lHint, pHint);
	theApp.UpdateStatusBar(&(GetRichEditCtrl()));
//	GetDocument()->m_Syntax.SyntaxHighlightComplete(&(GetRichEditCtrl()));
}

void CWinTim32View::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	CRichEditCtrl *re;
	long selStart,selEnd,i,j;
	CString sIndent;

//	EnterCriticalEditSection();
	CRichEditView::OnChar(nChar, nRepCnt, nFlags);
//	LeaveCriticalEditSection();

	switch(nChar)
	{
		case VK_RETURN:
			if (theApp.m_bAutoIndent)
			{
//				EnterCriticalEditSection();
				re = &(GetRichEditCtrl());
				re->GetSel(selStart,selEnd);
				i = re->LineIndex(re->LineFromChar(selStart-1));
				j = 1;

				re->HideSelection(TRUE,FALSE);
				re->SetSel(i,i+j);
				sIndent = re->GetSelText();
				while (ispurewhitespace(LPCTSTR(sIndent)[j-1]))
				{
					j++;
					re->SetSel(i,i+j);
					sIndent = re->GetSelText();
				}
				sIndent = sIndent.Left(j-1);
				re->SetSel(selStart,selStart);
				re->ReplaceSel(sIndent);
				re->HideSelection(FALSE,FALSE);
//				LeaveCriticalEditSection();
			}

			if (nRepCnt > 1)
				break;
			/*
			if (re->LineIndex(re->LineFromChar(selStart)) == selStart)
				break; // Enter at the beginning of a line won't change anything
			*/
			SyntaxHighlight(1);
			m_DocumentUpdated = TRUE;
			break;
		default:
			SyntaxHighlight();
			m_DocumentUpdated = TRUE;
	}
}

void CWinTim32View::OnDraw(CDC* pDC) 
{
	CRichEditView::OnDraw(pDC);	
}

void CWinTim32View::OnSysChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	CRichEditView::OnSysChar(nChar, nRepCnt, nFlags);
}

void CWinTim32View::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	CRichEditView::OnKeyDown(nChar, nRepCnt, nFlags);
	theApp.UpdateStatusBar(&(GetRichEditCtrl()));

	switch (nChar)
	{
/*
		case VK_LSHIFT:
		case VK_RSHIFT:
		case VK_LCONTROL:
		case VK_RCONTROL:
		case VK_SHIFT:
		case VK_CONTROL:
			return;      // The above keys will never alter the syntax
*/
		case VK_DELETE:
			SyntaxHighlight();
			m_DocumentUpdated = TRUE;
			break;
		default: ;
	}
//	CheckFirstLine();
}

void CWinTim32View::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	CRichEditView::OnKeyUp(nChar, nRepCnt, nFlags);
	theApp.UpdateStatusBar(&(GetRichEditCtrl()));

//	SyntaxHighlight();
}

void CWinTim32View::OnPrepareDC(CDC* pDC, CPrintInfo* pInfo) 
{
	CRichEditView::OnPrepareDC(pDC, pInfo);
}

BOOL CWinTim32View::OnEraseBkgnd(CDC* pDC) 
{
	return CRichEditView::OnEraseBkgnd(pDC);
}

void CWinTim32View::OnEditCut() 
{
//	EnterCriticalEditSection();
	GetRichEditCtrl().Cut();
//	LeaveCriticalEditSection();
	m_DocumentUpdated = TRUE;
	SyntaxHighlight();
}

void CWinTim32View::OnEditPaste() 
{
	long nLineCount, nNewLineCount, nOldLine;
	long index;
	long selStart, selEnd;
	CRichEditCtrl *re;

	re = &GetRichEditCtrl();

//	EnterCriticalEditSection();
	re->GetSel(selStart,selEnd);
	nLineCount = re->GetLineCount();
	nOldLine = re->LineFromChar(selStart);
	re->Paste();		
	re->GetSel(selStart,selEnd);
	nNewLineCount = re->GetLineCount();

	m_DocumentUpdated = TRUE;

	re->HideCaret();
	re->SetRedraw(FALSE);

	SetSyntaxData();
	for (index = nOldLine; index <= (nNewLineCount - nLineCount + nOldLine); index++)
		GetDocument()->m_Syntax.SyntaxHighlightOneLine(index, re, FALSE, &m_SyntaxData);

	re->SetSel(selStart,selEnd);
	re->SetRedraw(TRUE);
	re->ShowCaret();
	re->Invalidate();
}

void CWinTim32View::OnViewRefresh() 
{
	SetSyntaxData();
	GetDocument()->m_Syntax.SyntaxHighlightComplete(&(GetRichEditCtrl()),&m_SyntaxData);
	Invalidate();
}

void CWinTim32View::OnViewLabelTable() 
{
	if (theApp.m_pMainWnd->GetMenu()->GetMenuState(ID_VIEW_LABELTABLE,MF_CHECKED | MF_BYCOMMAND))
	{
		// If the Label Table item was checked, uncheck it and hide the table
		theApp.m_pMainWnd->GetMenu()->CheckMenuItem(ID_VIEW_LABELTABLE,MF_UNCHECKED | MF_BYCOMMAND);
		theApp.m_VisibleLabelTable = FALSE;
		HideLabelTable();
	} else
	{
		// Otherwise check the item and show the table
		theApp.m_pMainWnd->GetMenu()->CheckMenuItem(ID_VIEW_LABELTABLE,MF_CHECKED | MF_BYCOMMAND);
		theApp.m_VisibleLabelTable = TRUE;
		ShowLabelTable();
	}
}

void CWinTim32View::OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView) 
{
	CRichEditView::OnActivateView(bActivate, pActivateView, pDeactiveView);
	CheckFileType();
	if (IsWindow(theApp.m_LabelTableDlg))
	{
		// Only show the label table if the user wants it there
		if ((theApp.m_LabelTableDlg.m_Dead == FALSE) && (theApp.m_VisibleLabelTable == TRUE))
		{
			ShowLabelTable();
			// Verify that the menu item checkbox is correct
			theApp.m_pMainWnd->GetMenu()->CheckMenuItem(ID_VIEW_LABELTABLE,MF_CHECKED | MF_BYCOMMAND);
		} else
		{
			HideLabelTable();
			// Verify that the menu item checkbox is correct
			theApp.m_pMainWnd->GetMenu()->CheckMenuItem(ID_VIEW_LABELTABLE,MF_UNCHECKED | MF_BYCOMMAND);
		}
	}
}

void CWinTim32View::ShowLabelTable()
{
	// This function shows the label table (for the current document)
	theApp.m_LabelTableDlg.ShowWindow(SW_SHOW);

	// Tell our document processing thread we're ready for business
	m_LabelTableShown = TRUE;
}

void CWinTim32View::HideLabelTable()
{
	// This function hides the label table
	theApp.m_LabelTableDlg.ShowWindow(SW_HIDE);
	theApp.m_LabelTableDlg.SetTable(NULL);
	theApp.m_LabelTableDlg.m_Dead = TRUE;
}

CString CWinTim32View::TokenString(TokenArray *tArray, long i)
// Returns the string stored in multiple sub-tokens
{
	CString tString;
	CToken tok;

	tok = tArray->GetAt(i);
	if (tok.token.tint != WINTIM_STRING)
		return CString("");
	i++;
	tok = tArray->GetAt(i);
	while (tok.token.tint != WINTIM_ENDSTRING)
	{
		if (i > tArray->GetUpperBound())
			return CString("");
		tString += tok.token.tchar[0];
		if (tok.token.tchar[1] != '\0')
			tString += tok.token.tchar[1];
		i++;
		tok = tArray->GetAt(i);
	}
	return tString;
}

void CWinTim32View::GenerateMacroTable()
// Step through the m_TokenArray, looking for the keyword WTPO_MACRO
// and adding the tokens between that and WTPO_ENDM to m_MacroTable

{
	long index,i,subIndex,nLine,maxTokenArray,macroIndex;
	CString sMacro,sArg;
	TokenArray *pMacroTokens;
	CArray <CString, CString> macroArgArray;
	CToken tok;
	BOOL bInString;
	BOOL bAddStringNormally;
	BOOL bSubMacro;   // TRUE if the macro is a SUB command (no ENDM, ends at EOL)

	// A macro must have the following form:
	// [macro label]:   MACRO [arg1, arg2, ...]
	//                  [macro text]
	//                  ENDM

	m_MacroTable.RemoveAll();

	nLine = 0;
	m_lLocalLine = 0;
	maxTokenArray = m_TokenArray.GetUpperBound();
	for (index = 0; index < 4; index++)
	{
		if (index > maxTokenArray)
			break;
		NewLineCheck(m_TokenArray.GetAt(index), nLine);
	}
	// This loop starts at 4, because the minimum macro would be
	// <beginstring><string><endstring><label><MACRO>
	for (index = 4; index < m_TokenArray.GetSize(); index++)
	{
		tok = m_TokenArray.GetAt(index);
		if (NewLineCheck(tok, nLine))
			continue;
		if ((tok.token.tint == WTPO_MACRO) || (tok.token.tint == WTPO_SUB))
		{
			bSubMacro = (tok.token.tint == WTPO_SUB);
			if (m_TokenArray.GetAt(index-1).token.tint == WTCH_LABEL)
			{
				// Make sure there is a string corresponding to the label
				i = index - 2;
				if (m_TokenArray.GetAt(i).token.tint == WINTIM_ENDSTRING)
				{
					while (m_TokenArray.GetAt(i).token.tint != WINTIM_STRING)
					{
						if (NewLineCheck(m_TokenArray.GetAt(i), nLine))
						{
							m_FatalError = TRUE;
							m_ErrorCode = WTERR_NOSTRINGHEADER;
							m_ErrorLine = nLine;
							return;
						}
						i--;
						if (i < 0)
						{
							m_FatalError = TRUE;
							m_ErrorCode = WTERR_NOSTRINGHEADER;
							m_ErrorLine = nLine;
							return;
						}
					}
					// Now we know where the string for the macro label begins (i)
					sMacro = TokenString(&m_TokenArray,i);
					// Next, check for arguments to the macro.  Arguments are any
					// WINTIM_STRING that matches the requirements for isargstring(),
					// separated by WTCH_COMMA.
					macroArgArray.RemoveAll();
					if (!bSubMacro)  // SUB macros have no arguments
					{
						index++;
						tok = m_TokenArray.GetAt(index);
						while (NewLineCheck(tok,nLine) == FALSE)
						{
							if (tok.token.tint == WINTIM_STRING)
							{
								sArg = TokenString(&m_TokenArray,index);
								macroArgArray.Add(sArg);
								while (tok.token.tint != WINTIM_ENDSTRING)
								{
									index++;
									tok = m_TokenArray.GetAt(index);
								}
								index++; // Skip the ENDSTRING token itself also
								tok = m_TokenArray.GetAt(index);
								if (NewLineCheck(tok,nLine,FALSE))
									break;  // No more arguments
								if (tok.token.tint != WTCH_COMMA)
								{
									// This is an error; should be nothing
									// but arguments separated by commas
									m_FatalError = TRUE;
									m_ErrorLine = nLine;
									m_ErrorCode = WTERR_NOCOMMAAFTERARG;
									return;
								}
							} else
							{
								// This is an error; should be nothing
								// but arguments separated by commas
								m_FatalError = TRUE;
								m_ErrorLine = nLine;
								m_ErrorCode = WTERR_ARGANDCOMMAONLY;
								return;
							}
							index++;
							tok = m_TokenArray.GetAt(index);
						}
					}
					// Now the macroArgArray should be full of arguments (if any)
					// Start adding tokens to the token array for this macro, until
					// we find the ENDM directive
					macroIndex = m_MacroTable.Add(CMacro(sMacro,nLine, (bSubMacro == TRUE ? Substitution : Normal)));
					pMacroTokens = &(m_MacroTable.GetAt(macroIndex).contents);
					pMacroTokens->RemoveAll();
					subIndex = 0;
					index++; // Skip the newline
					if (!bSubMacro)
					{
						if (index > maxTokenArray)
						{
							m_FatalError = TRUE;
							m_ErrorCode = WTERR_MACROWITHOUTENDM;
							m_ErrorLine = nLine;
							return;
						}
					}
					tok = m_TokenArray.GetAt(index);
					bInString = FALSE;
					while (tok.token.tint != WTPO_ENDM)
					{
						if ((bSubMacro) && (NewLineCheck(tok,nLine,FALSE)))
						{
							// SUB macros end with the end of line, not ENDM, but
							// if there is a WINTIM_IGNORELF after the ENDLINE,
							// we continue processing
							if (index >= m_TokenArray.GetUpperBound())
								break; // That must be it
							if (m_TokenArray.GetAt(index+1).token.tint == WINTIM_IGNORELF)
							{
								nLine++; // Ignore the line practically, but increment the count
								m_lLocalLine++;
								index = index + 2;
								tok = m_TokenArray.GetAt(index);
								continue;  // Multiple IGNORELF's should work with this
							} else
								break; // If we don't ignore the ENDLINE, that's it
						}
						if (NewLineCheck(tok,nLine,FALSE) && (bInString == FALSE))
						{
							// Since WINTIM_ENDLINE might accidentally be inside a string,
							// check for that before adding another line count
							m_lLocalLine++;
							nLine++;
						}
						bAddStringNormally = TRUE; // Default to simply adding the token to the array
						if ((tok.token.tint == WINTIM_STRING) && (bInString == FALSE))
						{
							sMacro = TokenString(&m_TokenArray,index);
							// If a string token matches an argument, replace it
							// with WINTIM_MACROARG + arg number
							if (macroArgArray.GetSize() > 0)
							{
								for (i = 0; i < macroArgArray.GetSize(); i++)
								{
									if (sMacro.CompareNoCase(macroArgArray.GetAt(i)) == 0)
									{
										// A match!
										pMacroTokens->SetAtGrow(subIndex,WINTIM_MACROARG1+i);
										index = SkipString(nLine, index, &m_TokenArray, FALSE);
										// index++; // skip the WINTIM_ENDSTRING
										bAddStringNormally = FALSE;
										break; // No duplicate arguments
									}
								}
							}
							// Check if the substring is a macro previously defined
							for (i = 0; i < m_MacroTable.GetSize(); i++)
							{
								if (sMacro.CompareNoCase(m_MacroTable.GetAt(i).macro) == 0)
								{
									// We have a macro call inside this macro
									pMacroTokens->SetAtGrow(subIndex,WINTIM_MACRO);
									subIndex++;
									pMacroTokens->SetAtGrow(subIndex,CToken((unsigned short) i));
									index = SkipString(nLine, index, &m_TokenArray, FALSE);
									bAddStringNormally = FALSE;
									break; // Can't match more than one
								}
							}
						}
						if (bAddStringNormally == TRUE)
						{
							if (tok.token.tint == WINTIM_STRING)
							{
								// If we started an arbitrary string, make sure we finish it properly
								bInString = TRUE;
							}
							// If the token isn't WINTIM_STRING, or the string didn't
							// match anything relevant, add the token normally
							pMacroTokens->SetAtGrow(subIndex,tok);
							if (tok.token.tint == WINTIM_ENDSTRING)
							{
								// If we finished a string, we can return to checking
								// for WINTIM_ENDLINE and whatnot
								bInString = FALSE;
							}
						}
						subIndex++;
						index++;
						if (index > maxTokenArray)
						{
							m_FatalError = TRUE;
							m_ErrorCode = WTERR_MACROWITHOUTENDM;
							m_ErrorLine = nLine;
							return;
						}
						tok = m_TokenArray.GetAt(index);
					}
					// Note that this command copies the data in pMacroTokens
					// rather than assigning a pointer, thanks to the
					// copy constructor for CMacro
					m_MacroTable.SetAt(macroIndex,CMacro(
						m_MacroTable.GetAt(macroIndex).macro,
						pMacroTokens,
						m_MacroTable.GetAt(macroIndex).lStartLine,
						m_MacroTable.GetAt(macroIndex).type));
					pMacroTokens->RemoveAll();  // Memory leaks if we don't clean up this array
				}
			}
		} else if (m_TokenArray.GetAt(index).token.tint == WINTIM_STRING)
		{
			// If it isn't a macro, but is a string, check it against the
			// current macro table.
			sMacro = TokenString(&m_TokenArray,index);
			for (i = 0; i < m_MacroTable.GetSize(); i++)
			{
				if (m_MacroTable.GetAt(i).macro.CompareNoCase(sMacro) != 0)
					continue;
				// The string matched a macro at index i
				// Replace the WINTIM_STRING token with a WINTIM_MACRO
				m_TokenArray.SetAt(index,CToken(WINTIM_MACRO));
				// The token after a WINTIM_MACRO must always be the
				// index of the macro with which it will be replaced
				index++;
				tok = m_TokenArray.GetAt(index);
				m_TokenArray.SetAt(index,CToken((unsigned short) i));
				// Set the remaining tokens in the string to WTKW_NULL
				index++;
				tok = m_TokenArray.GetAt(index);
				while (tok.token.tint != WINTIM_ENDSTRING)
				{
					m_TokenArray.SetAt(index,CToken(WTKW_NULL));
					index++;
					tok = m_TokenArray.GetAt(index);
				}
				m_TokenArray.SetAt(index,CToken(WTKW_NULL));
				break; // A macro can't match more than once
			}
		}
	}
}

int g_iWordSize = 32;

void CWinTim32View::OnAssemblyMetaassembly() 
// This is called to create a definition file using the current
// open source file
{
/*
#ifdef _DEBUG
TRY
{
	CFile::Remove("C:\\debug.txt");
}
CATCH( CFileException, e )
{
        afxDump << "Note:  C:\\debug.txt does not exist\n";
}
END_CATCH
#endif
*/
	GetMainFrame()->ClearError();
	sprintf(m_buf,"--- Running meta-assembly processor on %s ---",GetDocument()->GetTitle());
	GetMainFrame()->PrintError(m_buf);

	m_FatalError = FALSE;
	m_FatalExtraText = "";
	TokenizeMetaFile(&m_TokenArray);     // Create m_TokenArray
	if (m_FatalError)
	{
		DoFatalError();
		return;
	}
	GenerateMacroTable();   // Store the macros in m_MacroTable
	if (m_FatalError)
	{
		DoFatalError();
		return;
	}
	CreateDefinitionFile();	// Parse the tokens, creating a .DEF file
	if (m_FatalError)
	{
		DoFatalError();
		return;
	}
	theApp.Warning("Meta-assembly complete.  Use the Output menu for listings.");
	sprintf(m_buf,"--- %s:  Meta-assembly complete.  Use the Output menu for listings. ---",GetDocument()->GetTitle());
	GetMainFrame()->PrintError(m_buf);
	g_iWordSize = m_Definitions.iWordSize;
}

void CWinTim32View::OnAssemblyAssemble() 
// This is called to use the current definition file in
// assembling the open source file
{
	m_Definitions.iWordSize = g_iWordSize;
	GetMainFrame()->ClearError();
	sprintf(m_buf,"--- Running assembly processor on %s ---",GetDocument()->GetTitle());
	GetMainFrame()->PrintError(m_buf);
	m_FatalExtraText = "";
	m_FatalError = FALSE;
	TokenizeMetaFile(&m_TokenArray, TRUE); // Create m_TokenArray
	if (m_FatalError)
	{
		DoFatalError();
		return;
	}
	GenerateMacroTable();   // Store the macros in m_MacroTable
	if (m_FatalError)
	{
		DoFatalError();
		return;
	}
//	afxDump << "m_TokenArray has " << m_TokenArray.GetSize() << " elements\n";
//	afxDump << "Macro 0 has " << m_MacroTable.GetAt(0).contents.GetSize() << " elements\n";
//	afxDump << "Macro 1 has " << m_MacroTable.GetAt(1).contents.GetSize() << " elements\n";
//	TokenArrayDump(&m_TokenArray);
//	TokenArrayDump(&(m_MacroTable.GetAt(0).contents));
//	TokenArrayDump(&(m_MacroTable.GetAt(1).contents));
	CreateObjectFile();	    // Parse the tokens, creating a .OBJ file
	if (m_FatalError)
	{
		DoFatalError();
		return;
	}
	theApp.Warning("Assembly complete.  Use the Output menu for listings.");
	sprintf(m_buf,"--- %s:  Assembly complete.  Use the Output menu for listings. ---",GetDocument()->GetTitle());
	GetMainFrame()->PrintError(m_buf);
}

void CWinTim32View::OnSize(UINT nType, int cx, int cy) 
{
	CRichEditView::OnSize(nType, cx, cy);
//	if (IsWindow(m_hWnd))
//	{
//		if (m_pDocument != NULL)
//			GetDocument()->m_Syntax.SyntaxHighlightComplete(&(GetRichEditCtrl()));
//	}
}


void CWinTim32View::CheckFirstLine()
{
	if (m_LastTopLine != GetRichEditCtrl().GetFirstVisibleLine())
	{
		m_LastTopLine = GetRichEditCtrl().GetFirstVisibleLine();
		SetSyntaxData();
		GetDocument()->m_Syntax.SyntaxHighlightComplete(&(GetRichEditCtrl()),&m_SyntaxData);
	}
}


void CWinTim32View::TokenizeMetaFile(TokenArray *ta, BOOL bAssemblyFile, CRichEditCtrl *pREC, BOOL bAddEndLine)
// Call this to fill m_TokenArray with tokens based on the
// contents of the rich edit control
{
	enum ParseMode { ModeNormal, ModeSingleQuote, ModeDoubleQuote };

	long i, index, lastLine, nLineLen, lToken; // Line and character indices
	long lArg;
	CRichEditCtrl *re;			   // The container for the text
	char cBuffer[MAX_RELINE];      // Space for one line at a time
	CToken tempToken;              // Storage for the new token
	BOOL bStopParsingLine = FALSE; // Set TRUE to interrupt processing
	ParseMode eMode = ModeNormal;  // Parsing mode
	int iTokenChar;                // Left/right character in a single token
	char cNonToken = '\0';         // Non-token character read from input
	char cTemp[2];                 // Storage for a 2-character token
	BOOL bString;                  // TRUE if the current token is a string token
	CString sCheck;                // The current token, always as a string
	BOOL bCheckString; // TRUE if the string should be checked against the keywords
	BOOL bTitle = FALSE;
	BOOL bDefType;					// TRUE if the current keyword uses X and V definition types (DEF, SUB)
	int iRelOpState;
	BOOL bNumeric;
	long nLine;
	TokenArray taSubArray;
	CRichEditCtrl reSubRichEdit;
	CString sFileName;
	CStdioFile stdioFile;

	if (pREC == NULL)
		re = &GetRichEditCtrl();
	else
		re = pREC;

	ta->RemoveAll();  // Erase the previous token array, if any
	lastLine = re->GetLineCount();
	ta->SetSize(lastLine * 3,TOKEN_GROW);  // Just a guess
	lToken = 0; // Start with line zero
	bNumeric = FALSE;
	nLine = 0;

	// Initialize the token hash table

	m_TokenMap.RemoveAll();
	m_TokenMap.InitHashTable(397);  // random prime numer

	i = 0;
	while (WinTimKeywords[i][0] != '\0')
	{
		m_TokenMap.SetAt(WinTimKeywords[i],WinTimKeywordsIndex[i]);
		i++;
	}

	if (bAssemblyFile)
	{
		for (i = 0; i < g_DefArray.GetSize(); i++)
		{
			m_TokenMap.SetAt(g_DefArray.GetAt(i).sOpcode,(short) (WINTIM_USEROP+i));
		}
	}

	i = 0;
	while (WinTimPseudoOps[i][0] != '\0')
	{
		m_TokenMap.SetAt(WinTimPseudoOps[i],WinTimPseudoOpsIndex[i]);
		i++;
	}

	// Begin processing the text

	for (index = 0; index < lastLine; index++)
	{
		re->GetLine(index,cBuffer,MAX_RELINE); // Copy line to CBuffer

		// Hack to set current line length (GetLineLength() has a bug)
		nLineLen = re->LineIndex(index+1) - re->LineIndex(index);
		if (nLineLen < 0)
			nLineLen = re->GetTextLength() - re->LineIndex(index);
		cBuffer[nLineLen] = '\0';

		// First initialize junk
		bStopParsingLine = FALSE;
		iTokenChar = 0;
		bString = FALSE;
		m_ErrorCode = WTERR_NOERROR;
		sCheck = "";
		bCheckString = FALSE;
		iRelOpState = 0;

		i = 0;
		while (iswhitespace(cBuffer[i]))
		{
			i++;
			if (i >= nLineLen)
				break;
		}
		if (cBuffer[i] != '/')
			bDefType = FALSE;  // Don't reset this if the line is a continuation of the previous one

		// Parse the line in CBuffer
		for (i = 0; i < nLineLen; i++)
		{
			// We'll use whitespace as our "default" token
			tempToken.token.tint = WINTIM_WHITESPACE;
			if (bTitle && cBuffer[i] != '\r' && cBuffer[i] != '\n')
			{
				cNonToken = cBuffer[i];
				sCheck += cBuffer[i];
				bCheckString = TRUE;
			}
			else
			{
				cNonToken = '\0';
				switch (eMode)
				{
					// ModeNormal is outside of any quotation marks
					case ModeNormal:
						switch(cBuffer[i])
						{
							case COMMENTCHAR:
								if (bString)
								{
									// If we were in a string, finish that first
									tempToken.token.tint = WINTIM_WHITESPACE;
									i--;
								} else
								{
									bStopParsingLine = TRUE;
									i = 0;
								}
								break;
							case LABELCHAR:
								tempToken.token.tint = WTCH_LABEL;
								break;
							case '\'':
								eMode = ModeSingleQuote;
								tempToken.token.tint = WTCH_QUOTE;
								break;
							case '\"':
								eMode = ModeDoubleQuote;
								tempToken.token.tint = WTCH_DQUOTE;
								break;
							case ',':
								tempToken.token.tint = WTCH_COMMA;
								break;
							case NUMERICCHAR:
								cNonToken = cBuffer[i];
								sCheck += cBuffer[i];
								bCheckString = TRUE;
								// Make the next pass think there was whitespace after
								cBuffer[i] = ' ';
								i--;
								break;
							case '+':
								tempToken.token.tint = WTCH_PLUS;
								break;
							case '-':
								tempToken.token.tint = WTCH_MINUS;
								break;
							case '*':
								tempToken.token.tint = WTCH_ASTERISK;
								break;
							case '/':
								tempToken.token.tint = WTCH_SLASH;
								break;
							case '[':
								tempToken.token.tint = WTCH_LBRACKET;
								break;
							case ']':
								tempToken.token.tint = WTCH_RBRACKET;
								break;
							case '(':
								tempToken.token.tint = WTCH_LPAREN;
								break;
							case ')':
								tempToken.token.tint = WTCH_RPAREN;
								break;
							case '<':
								tempToken.token.tint = WTCH_LESS;
								break;
							case '>':
								tempToken.token.tint = WTCH_GREATER;
								break;
							case '%':
								tempToken.token.tint = WTCH_PERCENT;
								break;
							case '$':
								tempToken.token.tint = WTCH_DOLLAR;
								break;
							case '\\':
								// Add the next character verbatim
								cNonToken = cBuffer[i+1];
								i++;
							case ' ':
							case '\t':
							case '\n':
							case '\r':
								tempToken.token.tint = WINTIM_WHITESPACE;
								iRelOpState = 0;
								break;
							case 'V':
							case 'v':
								if (i == 0)
								{
									cNonToken = cBuffer[i];
									sCheck += cBuffer[i];
									bCheckString = TRUE;
									break;
								}
								if ((bDefType) && (!isalpha(cBuffer[i-1])))
								{
									tempToken.token.tint = WTNM_VAR;
									break;
								}
								cNonToken = cBuffer[i];
								sCheck += cBuffer[i];
								bCheckString = TRUE;
								break;
							case 'X':
							case 'x':
								if (i == 0)
								{
									cNonToken = cBuffer[i];
									sCheck += cBuffer[i];
									bCheckString = TRUE;
									break;
								}
								if ((bDefType) && (!isalpha(cBuffer[i-1])))
								{
									tempToken.token.tint = WTNM_DCARE;
									break;
								}
								cNonToken = cBuffer[i];
								sCheck += cBuffer[i];
								bCheckString = TRUE;
								break;
							case '_':
								// _ is the relational operator
								// Check for operands such as B#1111_SHR_3
								// by breaking the _SHR_ off from from the
								// rest of the line

								if (iRelOpState == 0)
								{
									// Treat the current character as whitespace
									tempToken.token.tint = WINTIM_WHITESPACE;
									iRelOpState = 1;
									i--; // Process the underscore again
								} else if (iRelOpState == 1)
								{
									// We start on a relational operator
									// Add the unknown character to a temp string
									cNonToken = cBuffer[i];
									sCheck += cBuffer[i];
									bCheckString = TRUE;
									iRelOpState = 2;
								} else // iRelOpState == 2, hopefully
								{
									// We are finishing a relational operator
									cNonToken = cBuffer[i];
									sCheck += cBuffer[i];
									bCheckString = TRUE;
									iRelOpState = 0;
									// Make the next pass think there was whitespace after this
									cBuffer[i] = ' ';
									i--;
								}
								break;
							default: 
								// Add the unknown character to a temp string
								cNonToken = cBuffer[i];
								sCheck += cBuffer[i];
								bCheckString = TRUE;
						}
					break;
					// ModeSingleQuote is inside a '...' pair
					case ModeSingleQuote:
						switch(cBuffer[i])
						{
							case '\'':
								eMode = ModeNormal;
								tempToken.token.tint = WTCH_QUOTE;
								break;
							case '\n':
							case '\r':
								m_ErrorCode = WTERR_NEWLINEINSTRING;
								break;
							case '\\':
								// Add the next character verbatim
								cNonToken = cBuffer[i+1];
								i++;
							default:
								cNonToken = cBuffer[i];
						}
						break;
					// ModeSingleQuote is inside a "..." pair
					case ModeDoubleQuote:
						switch(cBuffer[i])
						{
							case '\"':
								eMode = ModeNormal;
								tempToken.token.tint = WTCH_DQUOTE;
								break;
							case '\n':
							case '\r':
								m_ErrorCode = WTERR_NEWLINEINSTRING;
								break;
							case '\\':
								// Add the next character verbatim
								cNonToken = cBuffer[i+1];
								i++;
							default:
								cNonToken = cBuffer[i];
						}
						break;
					default: ;
				}
			}
			if (bStopParsingLine)
			{
				// This discards the rest of the line, usually
				// because a comment character (;) was parsed
				break;
			}
			// If there was an error, now's the time to leave
			if (m_ErrorCode != WTERR_NOERROR)
			{
				m_FatalError = TRUE;
				m_ErrorLine = index;
				return;
			}
			// Process this if we are writing a string of characters
			// rather than a token
			if (cNonToken != '\0')
			{
				if (bString == FALSE)
				{
					// If bString is FALSE, that means this is the beginning
					// of a string, so add the WINTIM_STRING token to the
					// array.
					ta->SetAtGrow(lToken,CToken(WINTIM_STRING));
					lToken++;
					bString = TRUE;
				}
				cTemp[iTokenChar] = cNonToken;
				iTokenChar++;
				if (iTokenChar > 1)
				{
					// If we've gotten two characters, jam them together
					// into one CToken and keep looking
					tempToken.token.tchar[0] = cTemp[0];
					tempToken.token.tchar[1] = cTemp[1];
					ta->SetAtGrow(lToken,tempToken);
					lToken++;
					iTokenChar = 0;
				}
			}
			// Process this if you found a standard token, or if
			// we've come to the end of the line (and may need to 
			// check a finished string)
			if ((cNonToken == '\0') || (i == nLineLen - 1))
			{
				if (iTokenChar > 0) // Did we have a pending character?
				{
					// Pad the first character with an 0x00 character
					ta->SetAtGrow(lToken,CToken(cTemp[0],'\0'));
					iTokenChar = 0;
					lToken++;
				}
				if (bString) // Were we working on a string?
				{
					// Add the end-string token to the array
					ta->SetAtGrow(lToken,CToken(WINTIM_ENDSTRING));
					lToken++;
					if (bCheckString) // See if the string was a token
					{
						if (!bNumeric)
						{
							CheckToken(ta, sCheck,&lToken,bAssemblyFile,bDefType,bNumeric); // fixes the array if true
						} else
						{
							bNumeric = FALSE;
						}
						bCheckString = FALSE;
						sCheck = "";
						if (ta->GetAt(lToken-1).token.tint == WTKW_TITLE)
						{
							// The title line needs to be a single string
							bTitle = TRUE;
						} else if (ta->GetAt(lToken-1).token.tint == WTKW_END)
						{
							if (bAddEndLine == FALSE)
							{
								// We're in an INCLUDE statement, so ignore this END directive
								while (lToken < ta->GetSize())
								{
									ta->RemoveAt(lToken);  // Erase the END keyword string
								}
								lToken--;
								ta->RemoveAt(lToken); // Erase the END keyword token
								// Do, however, terminate this INCLUDE file
								index = lastLine;
								i = nLineLen;
								continue;
							}
						} else if (ta->GetAt(lToken-1).token.tint == WTKW_INCLUDE)
						{
							// The INCLUDE directive needs to be handled right here
							// Assume the rest of the line up to a COMMENTCHAR, excluding
							// whitespace, is the filename to be added
							while (lToken < ta->GetSize())
							{
								ta->RemoveAt(lToken);  // Erase the INCLUDE keyword string
							}
							lToken--;
							ta->RemoveAt(lToken); // Erase the INCLUDE keyword token
							// Verify that the filename specified does exist
							sFileName = &(cBuffer[i]);
							sFileName.TrimLeft();
							lArg = sFileName.Find(COMMENTCHAR);
							if (lArg != -1)
							{
								sFileName = sFileName.Left(lArg);
							}
							sFileName.TrimRight();
							if (stdioFile.Open(sFileName,CFile::modeRead | CFile::typeText) == 0)
							{
								// Failure to open this file is a fatal error
								m_ErrorCode = WTERR_INCLUDEFAILED;
								m_FatalError = TRUE;
								m_ErrorLine = nLine;
								m_FatalExtraText.Format(" - Filename \"%s\"",sFileName);
								return;								
							} else
							{
								reSubRichEdit.Create(WS_CHILD | ES_MULTILINE | ES_AUTOHSCROLL,CRect(0,0,10,10),this,1);
								reSubRichEdit.SetSel(0,-1);
								reSubRichEdit.Clear();
								m_EditStream.dwCookie = (DWORD) &stdioFile;
								m_EditStream.dwError = 0;
								m_EditStream.pfnCallback = RECallback;
								reSubRichEdit.StreamIn(SF_TEXT,m_EditStream);
								TokenizeMetaFile(&taSubArray,bAssemblyFile, &reSubRichEdit, FALSE);
								ta->Append(taSubArray);
								lToken += taSubArray.GetSize();
								reSubRichEdit.SetSel(0,-1);
								reSubRichEdit.Clear();
								i = nLineLen;  // Skip the rest of this line
								continue;
							}
						}
					}
					bString = FALSE; // No longer working on a string
				}
				if (cNonToken == '\0') // We had an actual token to add
				{
					switch(tempToken.token.tint)
					{
						case WINTIM_WHITESPACE:
						case WTCH_QUOTE:
						case WTCH_DQUOTE:
							break;
						default:
							// Add any token except whitespace  and quotes to the array
							ta->SetAtGrow(lToken,tempToken);
							lToken++;
					}
				}
			}
		}
		// Failing to terminate a string on a line is an error
		if ((eMode == ModeSingleQuote) || (eMode == ModeDoubleQuote))
		{
			m_ErrorCode = WTERR_NEWLINEINSTRING;
			m_FatalError = TRUE;
			m_ErrorLine = index;
			return;
		}
		// Add an endline token so we can count line numbers later
		if (bAddEndLine)
			ta->SetAtGrow(lToken,CToken(WINTIM_ENDLINE));
		else
			ta->SetAtGrow(lToken,CToken(WINTIM_DCENDLINE));

		nLine++;
		if (!(nLine & 0xf))
		{
			sError.Format("Tokenizing:  Line %d",nLine);
			theApp.Warning(sError);
		}
		bTitle = FALSE;
		lToken++;
	}

	// Get rid of any extra rubbish that happened because of string transformations
	ta->RemoveAt(lToken,ta->GetSize() - lToken);

	// Add an extra newline, in case there wasn't one at the end of the file
	// (This makes line processing easier later)
		if (bAddEndLine)
			ta->SetAtGrow(ta->GetSize(),CToken(WINTIM_ENDLINE));
		else
			ta->SetAtGrow(ta->GetSize(),CToken(WINTIM_DCENDLINE));

#ifdef _DEBUG
	// Debug token table printout
	//TokenArrayDump(&m_TokenArray);
#endif	
	theApp.Warning("Ready.");
}

// Global symbol table for the definition file's symbols
// (which can be used in assembler files)
SymbolArray g_SymbolTable;

void CWinTim32View::CreateDefinitionFile()
// This is the main meta-assembly function.  It takes the tokenized
// and preprocessed m_TokenArray and turns it into a definition
// file suitable for the assembler.
{
	long index,lRecentString;
	CString sRecentString,sRecentSymbol;
	CToken tok;
	CString sTok;
	long lArg;
	TokenArray *ta;
	ADDRESS NextAddress, address;
	BOOL TerminateProcessing;
	BOOL bPossibleLabel;
	short iLength;
	DWORD iFlags;
	MacroType iMacroType;

	long nLine = 0;
	m_lLocalLine = 0;

	m_ErrorArray.RemoveAll();
	g_SymbolTable.RemoveAll();
	m_SymbolTable.RemoveAll();

	g_SymbolTable.InitHashTable(GetRichEditCtrl().GetLineCount());
	m_SymbolTable.InitHashTable(GetRichEditCtrl().GetLineCount());

	m_CurrentMacroTokenArray.RemoveAll();
	g_DefArray.RemoveAll();
	m_Definitions.Initialize();
	ta = &m_TokenArray;
	NextAddress = 0;
	sRecentSymbol = "";
	lRecentString = -1;
	TerminateProcessing = FALSE;
	m_lCurrentMacro = -1;
	sRecentString = "";

	m_TokenStack.RemoveAll();

	index = 0;
	while (ta != NULL)
	{
		if (TerminateProcessing)
			break;
		bPossibleLabel = TRUE;
		while (index < ta->GetSize())
		{
			if (TerminateProcessing)
				break;
//		afxDump << "Main loop.  Index = " << index << "\n";
			tok = ta->GetAt(index);
//			afxDump << "Processing token (" << GetTokenName(tok) << ")\n";
			if (m_bShouldAssemble == FALSE)
			{
				if (tok.token.tint == WTKW_ENDIF)
				{
					m_bShouldAssemble = TRUE;
					m_bIfConditional = FALSE;
					m_bInIF = FALSE;
				} else if (tok.token.tint == WTKW_ELSE)
				{
					m_bShouldAssemble = TRUE;
					m_bIfConditional = FALSE;
				}
				index++;
				if (index >= ta->GetSize())
				{
					AddError(WTERR_IFWITHOUTENDIF,nLine,index);
				}
				continue;
			}
			if (m_bIfConditional)
			{
				iFlags = 0;
				if (CanEvaluate(index, ta, &address, &g_SymbolTable, nLine, &index, &iLength, &iFlags, TRUE))
				{
					if (address != 0)
					{
						m_bShouldAssemble = TRUE;
//						afxDump << "IF evaluated to " << address << "; not halting assembly\n";
					} else
					{
						m_bShouldAssemble = FALSE;
//						afxDump << "IF evaluated to " << address << "; halting assembly\n";
					}
					m_bInIF = TRUE;
				}
				else
				{
					AddError(WTERR_INVALIDIF,nLine,index);
				}
				index--;
				m_bIfConditional = FALSE;
			} else if (ProcessGenericToken(tok,ta,index,nLine,TerminateProcessing) == TRUE)
			{
				// None of the generic tokens can lead to a label
				bPossibleLabel = FALSE;
			} else switch(tok.token.tint)
			{
				// If the token wasn't generic, we need to check some specifics
				// - EQU, DEF, macro calls, and labels
				// - Strings, whitespace, and end-of-line tokens
				case WTKW_NULL:
					break;
				// WinTim32's pseudo-ops
				case WTPO_SET:
					// This should equate the rest of the line with the most recent symbol
					// Duplicate labels are okay; we simply replace the contents with SET
					if (sRecentSymbol == "")
					{
						AddError(WTERR_NOSYMBOL,nLine,index," - SET needs a label");
					} else
					{
						index = EquateSymbol(index+1,sRecentSymbol,&g_SymbolTable,ta,nLine);
						// Note that index may be past the end of the file if there is no newline
						index--;  // We want to process the next token, not skip it
					}
					break;
				case WTPO_EQU:
					// This should equate the rest of the line with the most recent symbol
					// Duplicate labels are NOT okay; they are an error
					if (sRecentSymbol == "")
					{
						AddError(WTERR_NOSYMBOL,nLine,index," - EQU needs a label");
					} else if (g_SymbolTable.Lookup(sRecentSymbol,m_Symbol))
					{
						if (m_Symbol.bAddressValid)
						{
							// Duplicate symbol
							sError.Format(": \"%s\" is also defined on line %d",sRecentSymbol,m_Symbol.lLine + 1);
							AddError(WTERR_DUPLICATELABEL,nLine, index, sError);
							break;
						}
					}
					index = EquateSymbol(index+1,sRecentSymbol,&g_SymbolTable,ta,nLine);
					// Note that index may be past the end of the file if there is no newline
					index--;  // We want to process the next token, not skip it
					break;
				case WTPO_DEF:
					// The DEF operator defines an opcode for the assembler.  These opcodes are
					// stored in m_DefinitionsArray
					if (sRecentSymbol == "")
					{
						AddError(WTERR_NOSYMBOL,nLine,index," - DEF needs a label");
					} else
					{
						index = AddDefinition(index+1,sRecentSymbol,ta,nLine);
						index--;  // We want to process the next token, not skip it
					}
					break;
				case WTCH_LABEL:
					if (lRecentString == -1)
					{
						AddError(WTERR_NOLABEL,nLine,index);
					} else
					{
						if (bPossibleLabel)
						{
							// Make this label our "most recent symbol" for equating
							sTok = TokenString(ta, lRecentString);
							sTok.MakeUpper();
							if (g_SymbolTable.Lookup(sTok,m_Symbol) == FALSE)
							{
								g_SymbolTable.SetAt(sTok,CSymbol(sTok,nLine,UNKNOWN_ADDRESS,ADDRESS_ONLY,FALSE));
							}
							sRecentSymbol = sTok;
						}
					}
					// If recent not at char zero, this isn't a proper label
					break;
				case WTPO_ORG:
					// The rest of the line should be an expression representing the next
					// address a line of code should have.
					break;
				// Anything that isn't a token
				case WINTIM_STRING:
					lRecentString = index;
					sRecentString = TokenString(ta, index);
					index = SkipString(nLine, index, ta);
					break;
				// Miscellaneous pseudo-tokens
				case WINTIM_ENDSTRING:
					bPossibleLabel = FALSE;
					break;
				case WINTIM_WHITESPACE:
					break;
				case WINTIM_ENDPROGRAM:
					break;
				case WINTIM_MACRO:
					index++; // Skip the WINTIM_MACRO keyword
					tok = ta->GetAt(index);  // The index of the macro in m_MacroTable
					// Put the current token array and index of the next token after
					// the macro call onto the stack
					lArg = tok.token.tint;  // Hold on to the macro index
					index++; // Skip the macro number
					tok = ta->GetAt(index);
					// Skip all of the NULL keywords that the macro replaced
					while (tok.token.tint == WTKW_NULL)
					{
						index++;
						tok = ta->GetAt(index);
					}
					// Store this index on the stack
					if (PushTokenArray(ta,index,m_lCurrentMacro,m_lLocalLine) == -1)
					{
						m_FatalError = TRUE;
						m_ErrorCode = WTERR_STACKOVERFLOW;
						m_ErrorLine = nLine;
						return;
					}
					// Switch to the macro's token array
					m_lLocalLine = 0;
					m_lCurrentMacro = lArg;
					m_CurrentMacroTokenArray.Copy(m_MacroTable.GetAt(lArg).contents);
					ta = &m_CurrentMacroTokenArray;
					index = -1; // Start at the beginning of the macro
					break;
				case WINTIM_ENDLINE:
					if (ta == &m_TokenArray)
					{
						// Only increment the line count if we aren't inside a macro
						nLine++;
						if (!(nLine & 0xf))
						{
							sError.Format("Meta-Assembly:  Line %d",nLine);
							theApp.Warning(sError);
						}
					}
					m_lLocalLine++; // Increment the local line count regardless
					lRecentString = -1;
					bPossibleLabel = TRUE;
					break;
				case WINTIM_DCENDLINE:
					// Do everything a newline does except increment the line count
					m_lLocalLine++; // Increment the local line count regardless
					lRecentString = -1;
					bPossibleLabel = TRUE;
					break;
				default:  // Something unrecognized
					bPossibleLabel = FALSE;
					sError.Format("- %s",GetTokenName(tok));
					AddError(WTERR_UNRECOGNIZEDTOKEN,nLine,index,sError);
			}
			index++;
		}
		if (TerminateProcessing)
			break;
		if (m_lCurrentMacro >= 0)
			iMacroType = m_MacroTable.GetAt(m_lCurrentMacro).type;
		else
			iMacroType = Substitution;

		PullTokenArray(&ta,&index,&m_lCurrentMacro,&m_lLocalLine); // ta gets NULL if no more elements
		if (ta != &m_TokenArray)
		{
			if (ta == NULL)
				break; // This should stop the process
			// If we're inside another macro, set m_CurrentMacroTokenArray
			// to what it should be, and continue
			m_CurrentMacroTokenArray.RemoveAll();
			m_CurrentMacroTokenArray.Copy(m_MacroTable.GetAt(m_lCurrentMacro).contents);
			ta = &m_CurrentMacroTokenArray;
		}
		// Skip the macro's arguments (if any)
		if ((iMacroType == Normal) && (index < ta->GetSize()))
		{
			tok = ta->GetAt(index);
			// There can only be arguments if it is a normal macro
			while ((tok.token.tint == WTCH_COMMA) || 
				   ((tok.token.tint > WINTIM_MACRO) &&
					(tok.token.tint < WINTIM_MACRO+255)))
			{
				index++;
				if (index > ta->GetUpperBound())
					break;
				tok = ta->GetAt(index);
			}
		}
	}
	RemoveInvalidEntries(&g_SymbolTable);
	DisplayErrors();
	m_CurrentMacroTokenArray.RemoveAll();
	theApp.Warning("Ready.");
}

void CWinTim32View::DoFatalError()
{
	CString sText;

	sText.Format("Fatal error %ld on line %ld:  %s",m_ErrorCode, m_ErrorLine+1, GetErrorText(m_ErrorCode) + m_FatalExtraText);
	GetMainFrame()->PrintError(sText);
	theApp.Warning("Operation failed due to fatal error - check error output dialog");
	sText.Format("--- Operation halted due to fatal error ---");
	GetMainFrame()->PrintError(sText);
}

void CWinTim32View::CheckToken(TokenArray *ta, CString sTest, long *index, BOOL bAssemblyFile, BOOL &bDefType, BOOL &bNumeric)
// Determines whether the string sTest is in fact a WinTim keyword,
// pseudo-op, or other special string.  If it is, the m_TokenArray
// is updated by replacing the string of literal characters with
// the token identifier.  If not, nothing is done.
{
	int i;
	CToken tTemp;
	long tokenIndex;
	BOOL bPrevNumerics = FALSE;
	short iToken;

	tTemp.token.tint = WINTIM_WHITESPACE;
	tokenIndex = *index;

	i = 0;

	sTest.MakeUpper();
	if (m_TokenMap.Lookup(sTest,iToken))
	{
		// We found a keyword
		tTemp.token.tint = iToken;
	} else
	{
		// if it didn't match, check the numerical entries (H#, Q#, etc)
		if (sTest.GetLength() >=2)
		{
			i = 0;
			while (WinTimNumerics[i][0] != '\0')
			{
				if (sTest.Right(2).CompareNoCase(WinTimNumerics[i]) == 0)
				{
					bNumeric = TRUE;
					tTemp.token.tint = WinTimNumericsIndex[i];
					if (sTest.GetLength() > 2)
						bPrevNumerics = TRUE;
					break;
				}
				i++;
			}
		}
	}

	// If nothing matched, exit the function
	if (tTemp.token.tint == WINTIM_WHITESPACE)
		return;

	// Check for definition keywords
	switch(tTemp.token.tint)
	{
		case WTPO_DEF:
		case WTPO_SUB:
			bDefType = TRUE;
			break;
		default: ;
	}

	if (bPrevNumerics)
	{
		// Numerics need to be handled differently
		if (ta->GetAt(tokenIndex-2).token.tchar[0] == NUMERICCHAR)
		{
			// If the "x#" was split between two tokens, pad the previous one
			ta->SetAt(tokenIndex-3,
				               CToken(ta->GetAt(tokenIndex-3).token.tchar[0],'\0'));
		}
		ta->SetAt(tokenIndex-2,CToken(WINTIM_ENDSTRING));
		ta->SetAt(tokenIndex-1,tTemp);
		*index = tokenIndex;
		return;
	}

	// We found a keyword/pseudo-op match, so index back the number
	// of characters in sTest (divided by two and rounded up since
	// two characters are stored per index), and an extra two for
	// the end of string terminator which should be already stored
	// and the beginning of string token.

	tokenIndex -= (((sTest.GetLength() + 1) / 2) + 1);
	tokenIndex -= 1;
	ta->SetAtGrow(tokenIndex,tTemp);
	tokenIndex++;
	*index = tokenIndex;
}

void CWinTim32View::TokenArrayDump(TokenArray *ta)
{
	long index,nLine = 0;
	CToken tok;
	CString sTemp;
	BOOL bInString = FALSE;
	BOOL bNewLine = FALSE;
	BOOL bLiteral = FALSE;
	char buf[20];
	FILE *debugfile;

	debugfile = fopen("c:\\debug.txt","a+t");
	if (debugfile == NULL)
	{
#ifdef _DEBUG
		afxDump << "Failed to open debug log file\n";
#endif
		return;
	}
	fprintf(debugfile,"Token Array Dump:\n");

	for (index = 0; index < ta->GetSize(); index++)
	{
		tok = ta->GetAt(index);
		if (bInString)
		{
			sTemp = TokenString(ta,index-1);
			while (tok.token.tint != WINTIM_ENDSTRING)
			{
				index++;
				if (index > ta->GetUpperBound())
					break;
				tok = ta->GetAt(index);
			}
			fprintf(debugfile,"Line %d: String(%s)\n",nLine,sTemp);
		}
		if (bLiteral)
		{
			sTemp = ltoa(tok.token.tint,buf,10);
			bLiteral = FALSE;
		}
		else switch(tok.token.tint)
		{
			case WINTIM_STRING:
				sTemp = "WINTIM_STRING";
				bInString = TRUE;
				break;
			case WINTIM_ENDSTRING:
				sTemp = "WINTIM_ENDSTRING";
				bInString = FALSE;
				break;
			case WTKW_NULL:
				sTemp = "WTKW_NULL";
				break;
			case WTKW_TITLE:
				sTemp = "WTKW_TITLE";
				break;
			case WTKW_WIDTH:
				sTemp = "WTKW_WIDTH";
				break;
			case WTKW_WORD:
				sTemp = "WTKW_WORD";
				break;
			case WTKW_LINES:
				sTemp = "WTKW_LINES";
				break;
			case WTKW_END:
				sTemp = "WTKW_END";
				break;
			case WTKW_FORM:
				sTemp = "WTKW_FORM";
				break;
			case WTKW_LIST:
				sTemp = "WTKW_LIST";
				break;
			case WTPO_NULL:
				sTemp = "WTPO_NULL";
				break;
			case WTPO_EQU:
				sTemp = "WTPO_EQU";
				break;
			case WTPO_SUB:
				sTemp = "WTPO_SUB";
				break;
			case WTPO_DEF:
				sTemp = "WTPO_DEF";
				break;
			case WTPO_MACRO:
				sTemp = "WTPO_MACRO";
				break;
			case WTPO_ENDM:
				sTemp = "WTPO_ENDM";
				break;
			case WTPO_ORG:
				sTemp = "WTPO_ORG";
				break;
			case WTNM_NULL:
				sTemp = "WTNM_NULL";
				break;
			case WTNM_BINARY:
				sTemp = "WTNM_BINARY";
				break;
			case WTNM_OCTAL:
				sTemp = "WTNM_OCTAL";
				break;
			case WTNM_DECIM:
				sTemp = "WTNM_DECIM";
				break;
			case WTNM_HEX:
				sTemp = "WTNM_HEX";
				break;
			case WTNM_VAR:
				sTemp = "WTNM_VAR";
				break;
			case WTCH_NULL:
				sTemp = "WTCH_NULL";
				break;
			case WTCH_QUOTE:
				sTemp = "WTCH_QUOTE";
				break;
			case WTCH_DQUOTE:
				sTemp = "WTCH_DQUOTE";
				break;
			case WTCH_LABEL:
				sTemp = "WTCH_LABEL";
				break;
			case WTCH_COMMA:
				sTemp = "WTCH_COMMA";
				break;
			case WTCH_PLUS:
				sTemp = "WTCH_PLUS";
				break;
			case WTCH_MINUS:
				sTemp = "WTCH_MINUS";
				break;
			case WTCH_ASTERISK:
				sTemp = "WTCH_ASTERISK";
				break;
			case WTCH_SLASH:
				sTemp = "WTCH_SLASH";
				break;
			case WTCH_LBRACKET:
				sTemp = "WTCH_LBRACKET";
				break;
			case WTCH_RBRACKET:
				sTemp = "WTCH_RBRACKET";
				break;
			case WTCH_LPAREN:
				sTemp = "WTCH_LPAREN";
				break;
			case WTCH_RPAREN:
				sTemp = "WTCH_RPAREN";
				break;
			case WTCH_PERCENT:
				sTemp = "WTCH_PERCENT";
				break;
			case WINTIM_WHITESPACE:
				sTemp = "WINTIM_WHITESPACE";
				break;
			case WINTIM_ENDPROGRAM:
				sTemp = "WINTIM_ENDPROGRAM";
				break;
			case WINTIM_MACRO:
				sTemp = "WINTIM_MACRO";
				bLiteral = TRUE;
				break;
			case WINTIM_MACRO+1:
				sTemp = "WINTIM_MACROARG1";
				break;
			case WINTIM_MACRO+2:
				sTemp = "WINTIM_MACROARG2";
				break;
			case WINTIM_MACRO+3:
				sTemp = "WINTIM_MACROARG3";
				break;
			case WINTIM_ENDLINE:
				sTemp = "WINTIM_ENDLINE";
				bNewLine = TRUE;
				break;
			case WINTIM_DCENDLINE:
				sTemp = "WINTIM_DCENDLINE";
				break;
			default:
				sTemp = "Unknown keyword (" + CString(ltoa(tok.token.tint,buf,10)) + ")";
				break;
		}
		fprintf(debugfile,"Line %d: %s\n",nLine,sTemp);
		if (bNewLine)
		{
			bNewLine = FALSE;
			nLine++;
		}
	}
	fclose(debugfile);
}

void CWinTim32View::UpdateFormat()
// This function is called when global_paraFormat contains new
// formatting information (tabs, font, etc) which must be applied
// to the entire edit control
{
	CRichEditCtrl *re;
	long selStart,selEnd;
	BOOL bModify;

	re = &(GetRichEditCtrl());
	bModify = re->GetModify();

	re->GetSel(selStart,selEnd);
	re->HideSelection(TRUE,FALSE);
	re->SetSel(0,-1);
	re->SetParaFormat(global_paraFormat);  // Reformat the paragraph
	re->SetSel(selStart,selEnd);
	re->HideSelection(FALSE,FALSE);

	re->SetModify(bModify);
}


BOOL CWinTim32View::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	switch (LOWORD(wParam))
	{
		case MYWM_UPDATEFORMAT:
			UpdateFormat();
			return FALSE;
		default: ;
	}
	return CRichEditView::OnCommand(wParam, lParam);
}

void CWinTim32View::AddError(long iErrorValue, long lSourceLine, long lTokenIndex, CString sExtra)
{
	int i;
	if (m_ErrorArray.GetSize() <= theApp.m_ErrorMax)
	{
		// Check for ignored error messages
		switch (iErrorValue)
		{
			case WTWARN_ENDBEFOREEOF:
				if (theApp.m_dwWarnings & 0x0001)
					return;
				break;
			case WTWARN_DEFINASM:
				if (theApp.m_dwWarnings & 0x0002)
					return;
				break;
			case WTWARN_FIELDLENGTHDISCREPANCY:
				if (theApp.m_dwWarnings & 0x0004)
					return;
				break;
			case WTWARN_MICROWORDLENGTH:
				if (theApp.m_dwWarnings & 0x0008)
					return;
				break;
			case WTWARN_FORMDISCREPANCY:
				if (theApp.m_dwWarnings & 0x0010)
					return;
				break;
			case WTWARN_INVALIDLISTOPTION:
				if (theApp.m_dwWarnings & 0x0020)
					return;
				break;
			case WTWARN_NOTENOUGHARGS:
				if (theApp.m_dwWarnings & 0x0040)
					return;
				break;
			default: ;
		}
		// Add the error in order by line
		for (i = 0; i < m_ErrorArray.GetSize(); i++)
		{
			if (m_ErrorArray.GetAt(i).lErrorLine > lSourceLine)
			{
				m_ErrorArray.InsertAt(i,CError(iErrorValue, lSourceLine, lTokenIndex, m_lLocalLine, m_lCurrentMacro, Error, sExtra));
				return;
			}
		}
		m_ErrorArray.Add(CError(iErrorValue, lSourceLine, lTokenIndex, m_lLocalLine, m_lCurrentMacro, Error, sExtra));
	}
}

BOOL CWinTim32View::TokenIsNum(long nLine, long index, long &lArg, TokenArray *ta, BOOL AddErrors)
// Checks to see if the token specified is a string token consisting
// of a numeric value (in decimal) and adds errors to the error array
// if it isn't (if AddErrors is set)
{
	CString sTok;
	CToken tok;
	int i;

	tok = ta->GetAt(index);
	if (tok.token.tint != WINTIM_STRING)
	{
		if (AddErrors)
			AddError(WTERR_UNEXPECTEDTOKEN,nLine,index);
		return FALSE;
	} else
	{
		sTok = TokenString(ta,index);
		for (i = 0; i < sTok.GetLength(); i++)
		{
			if (!isdigit(sTok.GetAt(i)))
			{
				if (AddErrors)
					AddError(WTERR_INVALIDNUMBER,nLine,index);
				return FALSE;
			}
		}
		lArg = atol(sTok);
		return TRUE;
	}
}

BOOL CWinTim32View::TokenIsStr(long nLine, long index, CString &sTok, TokenArray *ta, BOOL AddErrors)
// Checks to see if the token specified is a string token and adds errors
//  to the error array if it isn't (if AddErrors is set)
{
	CToken tok;

	tok = ta->GetAt(index);
	if (tok.token.tint != WINTIM_STRING)
	{
		if (AddErrors)
			AddError(WTERR_UNEXPECTEDTOKEN,nLine,index);
		return FALSE;
	} else
	{
		sTok = TokenString(ta,index);
		return TRUE;
	}
}

long CWinTim32View::SkipString(long nLine, long index, TokenArray *ta, BOOL AddErrors)
// returns the index of the WINTIM_ENDSTRING token after a WINTIM_STRING
{
	CToken tok;

	tok = ta->GetAt(index);
	while (tok.token.tint != WINTIM_ENDSTRING)
	{
		index++;
		if (index > ta->GetUpperBound())
		{
			if (AddErrors)
				AddError(WTERR_UNTERMINATEDSTRING,nLine,index);
			return -1;
		}
		tok = ta->GetAt(index);
	}
	return index;
}

long CWinTim32View::SkipRestOfLine(long &nLine, long index, TokenArray *ta, BOOL AddErrors)
// returns the index of the next WINTIM_ENDLINE
{
	CToken tok;

	tok = ta->GetAt(index);
	while (NewLineCheck(tok,nLine,FALSE) == FALSE)
	{
		index++;
		tok = ta->GetAt(index);
		if (NewLineCheck(tok,nLine,FALSE) && (index < ta->GetUpperBound()))
		{
			if (ta->GetAt(index+1).token.tint == WINTIM_IGNORELF)
			{
				nLine++;
				tok = ta->GetAt(index+1);
			}
		}
	}
	return index;
}

long CWinTim32View::EquateSymbol(long index, CString sRecentSymbol, SymbolArray *sa, TokenArray *ta, long nLine, ADDRESS aNext)
// Equates a symbol to the expression pointed to by the token at index
// returns the index value of the last token in the expression (usually
// then token right before a WINTIM_ENDLINE, but could possibly be larger
// than the maximum bound on the token array if there is no newline
// at the end of the last line).
{
	ADDRESS address;
	CSymbol symbol;
	long newindex;
	short iLength;
	DWORD iFlags = 0;

	// See if we can currently evaluate the entire expression
	if (CanEvaluate(index,ta,&address,sa,nLine,&newindex,&iLength,&iFlags,TRUE,0,FALSE,aNext))
	{
		sa->Lookup(sRecentSymbol,symbol);
		symbol.lAddress = address;
		symbol.iSymbolLength = iLength;
		symbol.bAddressValid = TRUE;
		symbol.lToken = index;
		sa->SetAt(sRecentSymbol,symbol);
	}
//	afxDump << "New Equate:  " << sRecentSymbol << " = " << address << "\n";
	return newindex;  // Set this regardless of success or failure
}

long CWinTim32View::AddDefinition(long index, CString sRecentSymbol, TokenArray *ta, long &nLine)
// Adds a definition entry to the g_DefArray containing the opcode and
// data fields for use by the assembler
{
	long newindex;
	CToken tok;
	short iLength;
	ADDRESS address;
	DWORD iFlags = 0;
	CDefinition tempDef;
	CDefinitionField tempField;
	long m_lCurrentMacro;
	BOOL bCommaLast = FALSE;
	CSymbol symbol;

	// Check each expression up to a WTCH_COMMA

	tok = ta->GetAt(index);
	newindex = index;
	tempDef.bValid = TRUE;
	g_SymbolTable.Lookup(sRecentSymbol,symbol);
	tempDef.sOpcode = symbol.sLabel;
	tempDef.iLength = 0;
	tempDef.iFields = 0;
	while (NewLineCheck(tok,nLine,FALSE) == FALSE)
	{
		bCommaLast = FALSE;
		// See if we can evaluate the rest of the field
		iFlags = 0;
		if (CanEvaluate(index,ta,&address,&g_SymbolTable,nLine,&newindex,&iLength,&iFlags,TRUE))
		{
			// Add this numeric value and length to a temporary field
			tempField.iBits = iLength;
			tempField.bConstant = (!(iFlags & WT_VARARG));
			tempField.bDCare = (iFlags & WT_DCARE);
			tempField.lValue = address;  // This is only valid if bConstant is FALSE
			// Add to the definition header
			tempDef.iLength += iLength;   // Add to the total number of bits
			tempDef.iFields++;            // Add to the number of fields
			tempDef.aFields.Add(tempField);
		} else
		{
			// The definition is only valid if every field is valid
			tempDef.bValid = FALSE;
		}
		index = newindex;
		tok = ta->GetAt(index);
		if (tok.token.tint == WTCH_COMMA)
		{
			bCommaLast = TRUE;
			// Don't get stuck on a comma
			index++;
			if (index < ta->GetSize())
				tok = ta->GetAt(index);
			// (otherwise, the macro code below will do this for us)
		}

		// Check for end-of-macro condition
		while (index > ta->GetUpperBound())
		{
			// Jump out of the macro, if we're in one.  Otherwise exit the function
			PullTokenArray(&ta,&index,&m_lCurrentMacro,&m_lLocalLine); // ta gets NULL if no more elements
			if (ta != &m_TokenArray) // if the token array we pulled isn't the starting one
			{
				if (ta == NULL)
				{
					tok.token.tint = WINTIM_ENDLINE;  // Break out of the loop also
					break; // This should stop the process
				}
				// If we're inside another macro, set m_CurrentMacroTokenArray
				// to what it should be, and continue
				m_CurrentMacroTokenArray.RemoveAll();
				m_CurrentMacroTokenArray.Copy(m_MacroTable.GetAt(m_lCurrentMacro).contents);
				ta = &m_CurrentMacroTokenArray;
				newindex = index;
			}

		}
		if (ta == NULL)
			break;
		tok = ta->GetAt(index);
		// End of macro checking

		CheckIgnoreLF(tok,ta,nLine,index);

	}
	if (bCommaLast)
	{
		// Expressions like DEF B#10,B#10,  are not valid
		AddError(WTWARN_COMMAATENDOFDEF,nLine,index);
	}
	if (tempDef.iLength != m_Definitions.iWordSize)
	{
		sError.Format("(WORD is defined to be %d bit%s, but this instruction is %d bit%s)",
			m_Definitions.iWordSize,(m_Definitions.iWordSize == 1 ? "" : "s"),
			tempDef.iLength,(tempDef.iLength == 1 ? "" : "s"));
		AddError(WTWARN_MICROWORDLENGTH,nLine,index,sError);
	}
	g_DefArray.Add(tempDef);

	return newindex;  // Set this regardless of success or failure
}

BOOL CWinTim32View::CanEvaluate(long index, TokenArray *(&ta), ADDRESS *address, SymbolArray *sa,
								long &nLine, long *newindex, short *iLength, DWORD *iFlags, BOOL bLabelErrors,
								long CurrentValue, BOOL bCurrentValueValid, ADDRESS EquateAddress)
// Determines whether or not the tokens at index (until and end-of-line or
// a WTCH_COMMA) can be reduced (via the symbol table) to a single address 
// (number). If it can, it places this result into the "address" variable
// and returns TRUE otherwise it does nothing and returns FALSE (since more
// labels are required to be defined first).  Also places the index of the
// end of the expression into *newindex (WINTIM_ENDLINE or WTCH_COMMA).
{
	Op NextOp = None;
	Op PrevOp;

	CToken tok,testtok;
	long TempValue;
	long numLength, newNumLength;
	long lArg,iParens;
	CString sTok;
	BOOL IsNum, bBaseAndLength;
	BOOL CanPossiblyEvaluate;
	int iNumIndex;
	long localMacroArgIndex;
	long lMacroIndex;
	TokenArray localMTA;
	TokenArray *pMTA;
	ADDRESS TempAddress;
	short tempLength;

	CanPossiblyEvaluate = TRUE;
	(*iLength) = 0;
	// *iFlags = 0; 
	iNumIndex = 0;
	m_EvalDepth++;
	if (m_EvalDepth > MAX_RECURSION_DEPTH)
	{
		// This is a serious problem; we ran out of recursion stack space
		m_ErrorLine = nLine;
		m_ErrorCode = WTERR_MAXRECURSION;
		m_FatalError = TRUE;
		sError.Format(" (the maximum depth is %d)",MAX_RECURSION_DEPTH);
		AddError(WTERR_MAXRECURSION,nLine,index,sError);
		m_EvalDepth--;
		return FALSE;
	}

	tok = ta->GetAt(index);
	if (tok.token.tint == WTCH_COMMA)
	{
		// If a comma is the next character, we just use the
		// default value for the argument (if there is one)
		*iFlags |= WT_DEFAULT;
		(*address) = 0;
		(*newindex) = index;
		(*iLength) = 1;
		m_EvalDepth--;
		return TRUE;  // zero is an acceptable default to most calls
	}
	while (NewLineCheck(tok,nLine,FALSE) == FALSE)
	{
		if (tok.token.tint == WTCH_COMMA)
			break;
		if (tok.token.tint == WTCH_RPAREN)
			break;
		if (tok.token.tint == WTCH_LBRACKET)
		{
			if (bCurrentValueValid)
			{
				// The bracket should only be the first character of the expression
				if (!bLabelErrors)
				{
					AddError(WTERR_LBRACKETNOTFIRST,nLine,index);
					CanPossiblyEvaluate = FALSE;
				}
			} else
			{
				// Argument should be something like "[12]"
				*iFlags |= WT_MULTIDEFAULT;
				index++;
				if (index > ta->GetUpperBound())
				{
					CanPossiblyEvaluate = FALSE;
					break;
				} else
				{
					tok = ta->GetAt(index);
				}
			}
		}
		if (CanPossiblyEvaluate) // Just find the end of the expression otherwise
		{
			IsNum = FALSE;
			bBaseAndLength = FALSE;
			PrevOp = NextOp;
			switch(tok.token.tint)
			{
				case WTNM_VAR:
					if (*iFlags & (WT_VARARG | WT_DCARE))
					{
						AddError(WTERR_MULTIPLEVARS,nLine,index," - a 'V' designator was specified when one of either 'V' or 'X' was already encountered for this expression (only the first is used)");
						break;
					}
					*iFlags |= WT_VARARG;
					if (iNumIndex == 0)
					{
						*iLength = 1;
						numLength = 1;
						break;
					}
					if (iNumIndex > 1)
					{
						sError.Format(" - 'V' designator after %d numeric arguments",iNumIndex);
						AddError(WTERR_VARAFTERTWONUMS,nLine,index,sError);
					}
					*iLength =  (short) (numLength = CurrentValue);  // The value of the number read previously
					break;
				case WTNM_DCARE:
					// Don't-care argument dead ahead...
					if (*iFlags & (WT_VARARG | WT_DCARE))
					{
						AddError(WTERR_MULTIPLEVARS,nLine,index," - an 'X' designator was specified when one of either 'V' or 'X' was already encountered for this expression (only the first is used)");
						break;
					}
					*iFlags |= WT_DCARE;
					if (iNumIndex == 0)
					{
						*iLength = 1;
						numLength = 1;
						break;
					}
					if (iNumIndex > 1)
					{
						sError.Format(" - 'X' designator after %d numeric arguments",iNumIndex);
						AddError(WTERR_VARAFTERTWONUMS,nLine,index,sError);
					}
					*iLength =  (short) (numLength = CurrentValue); // The value of the number read previously
					break;
				case WINTIM_STRING:
					// A possible label
					if (TokenIsNum(nLine, index, TempValue, ta, FALSE))
					{
						IsNum = TRUE;
						numLength = strlen(ltoa(TempValue,m_buf,2)); // Length of binary conversion
						index = SkipString(nLine,index,ta);
					} else
					{
						// The token isn't a numeric value, so check to see if it fits
						// a string in the symbol table
						sTok = TokenString(ta, index);
						index = SkipString(nLine,index,ta);
						// See if the symbol sTok is actually in our symbol table
						sTok.MakeUpper();
						if (sa->Lookup(sTok,m_Symbol))
						{
							if (m_Symbol.bAddressValid)
							{
								// We have a winner -> found the address of the symbol
								TempValue = m_Symbol.lAddress;
								numLength = m_Symbol.iSymbolLength;
								IsNum = TRUE;
							} else
							{
								// The symbol exists, but the address isn't valid yet
								CanPossiblyEvaluate = FALSE;
							}
						} else
						{
							// No, it's not in the table, so it's either a bogus symbol
							// or a forward reference.  We simply return FALSE and let the
							// main processor decide on the second pass.
							CanPossiblyEvaluate = FALSE;
							if (bLabelErrors)
							{
								sError.Format(": %s",sTok);
								AddError(WTERR_UNDEFINEDLABEL,nLine, index,sError);
							}
						}
					}
					break;
				// Mathematical expressions
				case WTCH_DOLLAR:
					TempValue = EquateAddress;
					IsNum = TRUE;
					break;
				case WTCH_PLUS:
					NextOp = Add;
					break;
				case WTCH_MINUS:
					NextOp = Subtract; 
					break;
				case WTCH_ASTERISK:
					NextOp = Multiply;
					break;
				case WTCH_SLASH:
					NextOp = Divide;
					break;
				case WTPO_AND:
					NextOp = Logical_And;
					break;
				case WTPO_OR:
					NextOp = Logical_Or;
					break;
				case WTPO_XOR:
					NextOp = Logical_Xor;
					break;
				case WTPO_EQ:
					NextOp = If_Equal;
					break;
				case WTPO_NE:
					NextOp = If_Not_Equal;
					break;
				case WTPO_GT:
					NextOp = If_Greater_Than;
					break;
				case WTPO_GE:
					NextOp = If_Greater_Than_Or_Equal;
					break;
				case WTPO_LT:
					NextOp = If_Less_Than;
					break;
				case WTPO_LE:
					NextOp = If_Less_Than_Or_Equal;
					break;
				case WTPO_SHR:
					NextOp = Logical_Shift_Right;
					break;
				case WTPO_SHL:
					NextOp = Logical_Shift_Left;
					break;
				case WTCH_RBRACKET:
					if ((*iFlags) & WT_MULTIDEFAULT)
					{
						// If this is a default value, we're done with it,
						// but we have to make sure there isn't anything after
						// this that's invalid (it should be a comma or
						// end-of-line, or perhaps a parenthesis)
						if (index + 1 > ta->GetUpperBound())
							break; // could be inside a macro
						switch(ta->GetAt(index+1).token.tint)
						{
							case WTCH_COMMA:
							case WTCH_RPAREN:
							case WINTIM_ENDLINE:
							case WINTIM_DCENDLINE:
							case WINTIM_WHITESPACE:
								break;
							default:
								AddError(WTERR_TRASHAFTERRBRACKET,nLine,index);
								CanPossiblyEvaluate = FALSE;
						}
					} else
					{
						// We just found a "]" with no preceding "[", so
						// that's a standard error
						AddError(WTERR_EXTRARBRACKET,nLine,index);
						CanPossiblyEvaluate = FALSE;
					}
					break;
				case WTCH_LPAREN:
					// Evaluate up to the next ")" as an expression
					// First, find the matching right-parenthesis, and give 
					// an error if there isn't one.
					lArg = index;
					testtok = ta->GetAt(lArg);
					iParens = 1;
					while (iParens > 0)
					{
						lArg++;
						if (lArg > ta->GetUpperBound())
						{
							// This shouldn't happen; there should always be
							// a WINTIM_ENDLINE before the EOF, but if something
							// really bad happened, catch it here.
							index = lArg - 1;
							CanPossiblyEvaluate = FALSE;
							if (bLabelErrors)
								AddError(WTERR_PARENMISMATCH,nLine,index);
							break;
						} else
						{
							testtok = ta->GetAt(lArg);
							if (NewLineCheck(testtok,nLine,FALSE))
							{
								// '(' without ')'
								index = lArg;
								CanPossiblyEvaluate = FALSE;
								if (bLabelErrors)
									AddError(WTERR_PARENMISMATCH,nLine,index);
								break;
							} else if (testtok.token.tint == WTCH_LPAREN)
							{
								// Paren inside paren, so increment the count
								iParens++;
							} else if (testtok.token.tint == WTCH_RPAREN)
							{
								// Matching paren, decrement count
								iParens--;
							}
						}
					}
					iParens = 0;
					if (testtok.token.tint == WTCH_RPAREN)
					{
						// If we actually found a match, parse it
						if (CanEvaluate(index+1, ta, &TempAddress, sa,
								nLine, &index, &tempLength, iFlags, bLabelErrors))
						{
							// If we evaluated it, then the value should be in TempAddress
							IsNum = TRUE;
							TempValue = (signed) TempAddress;
							if (tempLength > numLength)
								numLength = (long) tempLength;
							// Don't increment index, because we did process the RPAREN
							// properly.
						} else
						{
							// Something was wrong with the parenthetical expression,
							// so cancel this function
							CanPossiblyEvaluate = FALSE;
							if (m_FatalError)
								return FALSE;
						}
					} // otherwise, something stupid happened, so just exit
					break;
				// Base-N numbers
				case WTNM_BINARY:
				case WTNM_OCTAL:
				case WTNM_DECIM:
				case WTNM_HEX:
					if (TokenIsBaseNum(nLine, index, TempValue, ta, &numLength, TRUE))
					{
						IsNum = TRUE;
						index++; // Skip the 'X#' token
						index = SkipString(nLine,index,ta); // Skip the numeric string
						bBaseAndLength = TRUE; // Possible value such as "4D#3"
					} else
					{
						// If we received X# without a valid number, that's a problem
						CanPossiblyEvaluate = FALSE;
					}
					break;
				case WINTIM_MACRO:
					// Fripping macros in expressions!
					index++; // Skip the WINTIM_MACRO keyword
					tok = ta->GetAt(index);  // The index of the macro in m_MacroTable
					// Put the current token array and index of the next token after
					// the macro call onto the stack
					lArg = tok.token.tint;  // Hold on to the macro index
					index++; // Skip the macro number
					if (index < ta->GetUpperBound())
					{
						// Only do this if the macro wasn't the last possible token
						tok = ta->GetAt(index);
						// Skip all of the NULL keywords that the macro replaced
						while (tok.token.tint == WTKW_NULL)
						{
							index++;
							tok = ta->GetAt(index);
						}
					}
					// Store this index on the stack
					if (PushTokenArray(ta,index,m_lCurrentMacro,m_lLocalLine) == -1)
					{
						m_FatalError = TRUE;
						m_ErrorCode = WTERR_STACKOVERFLOW;
						m_ErrorLine = nLine;
						m_EvalDepth--;
						return FALSE;
					}
					// Switch to the macro's token array
					m_lLocalLine = 0;
					m_lCurrentMacro = lArg;
					m_CurrentMacroTokenArray.Copy(m_MacroTable.GetAt(lArg).contents);
					ta = &m_CurrentMacroTokenArray;
					index = -1; // Start at the beginning of the macro
					break;
				case WTCH_LESS:
					// PC-Relative addressing
					*iFlags |= WT_RELATIVE;
					break;
				case WTCH_PERCENT:
					// field-length justification (padding)
					*iFlags |= WT_JUSTIFY;
					break;
				case WTCH_LABEL:
					// field-length truncation
					*iFlags |= WT_TRUNCATE;
					break;
				default: // Something else?
					// Is it a macro argument?
					if ((tok.token.tint > WINTIM_MACRO) && (tok.token.tint < WINTIM_MACRO+255))
					{
						// Yep
						localMacroArgIndex = PeekTokenArray(lMacroIndex,m_EvalDepth);
						if (lMacroIndex != -1)
						{
							localMTA.Copy(m_MacroTable.GetAt(lMacroIndex).contents);
							pMTA = &localMTA;
						} else if (localMacroArgIndex > -1)
						{
							pMTA = &m_TokenArray;
						} else
						{
							// Nothing on the stack
							sError.Format("- Evaluation Depth of %d",m_EvalDepth);
							AddError(WTERR_INTERNALMACROINCONS,nLine,index,sError);
							m_EvalDepth--;
							return FALSE;
						}
						// Skip through the arguments until we have the correct one
						for (lArg = 1; lArg < tok.token.tint - WINTIM_MACRO; lArg++)
						{
							while (pMTA->GetAt(localMacroArgIndex).token.tint != WTCH_COMMA)
							{
								localMacroArgIndex++;
								if (localMacroArgIndex > pMTA->GetUpperBound())
								{
									CanPossiblyEvaluate = FALSE;
									break;
								}
								if (NewLineCheck(pMTA->GetAt(localMacroArgIndex),nLine,FALSE))
								{
									// Oops - no more arguments!
									CanPossiblyEvaluate = FALSE;
									break;
								}
							}
							localMacroArgIndex++;  // skip the comma
							if (localMacroArgIndex > pMTA->GetUpperBound())
							{
								CanPossiblyEvaluate = FALSE;
								break;
							}
							if (NewLineCheck(pMTA->GetAt(localMacroArgIndex),nLine,FALSE))
							{
								// Oops - no more arguments!
								CanPossiblyEvaluate = FALSE;
								break;
							}
							if (!CanPossiblyEvaluate)
								break;
						}
						if (CanPossiblyEvaluate)
						{
							if (CanEvaluate(localMacroArgIndex, pMTA, address, sa, nLine,
								newindex, iLength, iFlags, bLabelErrors))
							{
								// Yahoo!
								IsNum = TRUE;
							} else
							{
								// Nuts!
								CanPossiblyEvaluate = FALSE;
								if (m_FatalError)
									return FALSE;
							}
						} else
						{
							// There weren't enough arguments to this macro
							sError.Format(": needed at least %d, received %d",tok.token.tint - WINTIM_MACRO,lArg);
							AddError(WTERR_NOTENOUGHARGS,nLine,index,sError);
						}
						TempValue = *address;
						numLength = *iLength;
					} else
					{
						// Nope, not a macro argument, so it's an invalid token
						if (!bLabelErrors)
						{
							AddError(WTERR_ILLEGALTOKENINEXPR,nLine,index,
								CString("- The following token was encountered inside an expression: ") + GetTokenName(tok));
						}
						CanPossiblyEvaluate = FALSE;
					}
			}
			if ((NextOp != None) && (!bCurrentValueValid))
			{
				// Expressions such as "* 3" are not valid expressions
				if (!bLabelErrors)
				{
					sError.Format(" (%s)",GetOpName(NextOp));
					AddError(WTERR_OPBEFOREEXPR,nLine,index,sError);
				}
				CanPossiblyEvaluate = FALSE;
				NextOp = None;  // This prevents a duplicate error further down
			}
			if (IsNum)
			{
				iNumIndex++;
				if ((bCurrentValueValid) && (NextOp == None))
				{
					// This can happen if we get an expression such as "16D#20"
					if (bBaseAndLength)
					{
						if (numLength < (int) CurrentValue)
						{
							// The CurrentValue must be the length in bits
							// of the TempValue
							numLength = CurrentValue; // The value of the number read previously
						}
						CurrentValue = TempValue;
					} else if ((iNumIndex == 2) && (*iFlags & (WT_VARARG | WT_DCARE)))
					{
						// Specific case of something like "6V6"
						CurrentValue = TempValue;
					} else
					{
						sError.Format("- The first expression evaluates to \"%d\" and second to \"%d\"",CurrentValue, TempValue);
						AddError(WTERR_NOOPERATOR,nLine,index,sError);
						CanPossiblyEvaluate = FALSE;
					}
				} else 
				{
					// Check the next token; if it's an operator of
					// greater precedence than the current one, we
					// need to evaluate the next expression first
					if (HasPrecedence(NextOp,index+1,ta,nLine))
					{
						if (CanEvaluate(index+1, ta, &TempAddress, sa,
								nLine, &index, &tempLength, iFlags, bLabelErrors, TempValue, TRUE))
						{
							// If we evaluated it, then the value should be in TempAddress
							IsNum = TRUE;
							TempValue = (signed) TempAddress;
							if (tempLength > numLength)
								numLength = (long) tempLength;
 							TempValue = TempAddress;
							// Index should be at the end of the expression
							if (NewLineCheck(ta->GetAt(index),nLine,FALSE))
							{
								index--;
							}
						} else
						{
							CanPossiblyEvaluate = FALSE;
							if (m_FatalError)
								return FALSE;
						}
					}
					switch(NextOp)
					{
						case None:
							CurrentValue = TempValue;
							break;
						case Add:
							CurrentValue += TempValue;
							break;
						case Subtract:
							CurrentValue -= TempValue;
							break;
						case Multiply:
							CurrentValue *= TempValue;
							break;
						case Divide:
							CurrentValue /= TempValue;
							break;
						case Logical_And:
							CurrentValue &= TempValue;
							break;
						case Logical_Or:
							CurrentValue |= TempValue;
							break;
						case Logical_Xor:
							CurrentValue ^= TempValue;
							break;
						case If_Equal:
							CurrentValue = (CurrentValue == TempValue);
							break;
						case If_Not_Equal:
							CurrentValue = (CurrentValue != TempValue);
							break;
						case If_Greater_Than:
							CurrentValue = (CurrentValue > TempValue);
							break;
						case If_Greater_Than_Or_Equal:
							CurrentValue = (CurrentValue >= TempValue);
							break;
						case If_Less_Than:
							CurrentValue = (CurrentValue < TempValue);
							break;
						case If_Less_Than_Or_Equal:
							CurrentValue = (CurrentValue <= TempValue);
							break;
						case Logical_Shift_Right:
							CurrentValue >>= TempValue;
							break;
						case Logical_Shift_Left:
							CurrentValue <<= TempValue;
							break;
						default: ;  // no way to reach here
					}
				}
				newNumLength = strlen(ltoa(CurrentValue,m_buf,2));
				if (newNumLength > numLength) // Length of binary conversion
					numLength = newNumLength;

				if (numLength > *iLength)
				{
					// Never decrease the number length, only increase it
					// (thus B#000 + 0 has a length of 3)
					(*iLength) = (short) numLength;
				}
				NextOp = None;
				bCurrentValueValid = TRUE;
			}
			if ((PrevOp != None) && (NextOp != None))
			{
				// You can't have things like "3 + * 4"
				// Although there are some exceptions, such as:
				// "B#101* - 5" is "invert B#101 and subtract 5"
				// "B#111- - 3" is "negate B#111 and subtract 3"
				if (PrevOp == Multiply)
				{
					// Invert the current value
					CurrentValue = ~CurrentValue;
  					// The numeric length should stay the same
					// e.g. B#1010* = B#11110101, but length = 4
					// so it will end up being B#0101 anyhow
				} else if (PrevOp == Subtract)
				{
					// Negate the current value
					CurrentValue = -CurrentValue;
					// This should also follow the length requirements
					// e.g. B#101- = B#11111011, but length = 3
					// so it will end up being B#011
				} else if (!bLabelErrors)
				{
					sError.Format("- \"%s\" and \"%s\"",GetOpName(PrevOp),GetOpName(NextOp));
					AddError(WTERR_MULTIPLEOPS,nLine,index,sError);
					CanPossiblyEvaluate = FALSE;
				}
			}

		}
		index++;
		(*newindex) = index;
		while (index > ta->GetUpperBound())
		{
			// Jump out of the macro, if we're in one.  Otherwise exit the function
			PullTokenArray(&ta,&index,&m_lCurrentMacro,&m_lLocalLine); // ta gets NULL if no more elements
			if (ta != &m_TokenArray) // if the token array we pulled isn't the starting one
			{
				if (ta == NULL)
				{
					tok.token.tint = WINTIM_ENDLINE;  // Break out of the  loop also
					break; // This should stop the process
				}
				// If we're inside another macro, set m_CurrentMacroTokenArray
				// to what it should be, and continue
				m_CurrentMacroTokenArray.RemoveAll();
				m_CurrentMacroTokenArray.Copy(m_MacroTable.GetAt(m_lCurrentMacro).contents);
				ta = &m_CurrentMacroTokenArray;
				(*newindex) = index;
			}

		}
		if (ta == NULL)
			break;
		tok = ta->GetAt(index);

		CheckIgnoreLF(tok,ta,nLine,index);

	}
	if (NextOp != None)
	{
		// an operator at the end of the line isn't a good idea
		// unless it's * or -
		if (NextOp == Multiply)
		{
			// Invert the current value
			CurrentValue = ~CurrentValue;
			// The numeric length should stay the same
			// e.g. B#1010* = B#11110101, but length = 4
			// so it will end up being B#0101 anyhow
		} else if (NextOp == Subtract)
		{
			// Negate the current value
			CurrentValue = -CurrentValue;
			// This should also follow the length requirements
			// e.g. B#101- = B#11111011, but length = 3
			// so it will end up being B#011
		} else if (!bLabelErrors)
		{
			sError.Format("- \"%s\"",GetOpName(NextOp));
			AddError(WTERR_OPATENDLINE,nLine,index,sError);
			CanPossiblyEvaluate = FALSE;
		}
	}
	if (*iFlags & (WT_VARARG | WT_DCARE))
	{
		if (iNumIndex == 0)
		{
			*address = 0;
			AddError(WTWARN_NOBITLENGTH,nLine,index);
		} else if (iNumIndex == 1)
		{
			// If something like "6V" was declared, the default address is zero
			*address = 0;
		} else
		{
			// Otherwise it's all good
			(*address) = CurrentValue;
		}
	} else
	{
		// otherwise it's whatever we found
		(*address) = CurrentValue;
	}
	(*newindex) = index;
	m_EvalDepth--;
	return CanPossiblyEvaluate;
}

/*
BOOL CWinTim32View::SymbolInTable(CString sTok, SymbolArray *sa, long &lSymbolIndex)
// Returns TRUE if the symbol sTok exists in the symbol array "sa"
// and puts the index of the symbol into lSymbolIndex.
// If the symbol sTok is not in the table, returns FALSE and puts nothing
// into the symbol index
{
	long i;

	// Simple linear search for now; expand later to a hash table or other index
	for (i = 0; i < sa->GetCount(); i++)
	{
		if (sTok.CompareNoCase(sa->GetAt(i).sLabel) == 0)
		{
			lSymbolIndex = i;
			return TRUE;
		}
	}
	return FALSE;
}
*/

BOOL CWinTim32View::TokenIsBaseNum(long nLine, long index, long &lArg, TokenArray *ta, long *numLength, BOOL AddErrors)
// Checks to see if the token specified is a string token consisting
// of a numeric value (in the TIM base notation X#nnnn) and adds
// errors to the error array if it isn't (if AddErrors is set)
{
	CToken tok;
	CString sTok;
	int i,iLen;
	enum Base { Binary, Octal, Decimal, Hexadecimal } TokBase;

	(*numLength) = 0;
	// The first token must be one of the WTNM designators
	tok = ta->GetAt(index);
	switch (tok.token.tint)
	{
		case WTNM_BINARY:
			TokBase = Binary;
			break;
		case WTNM_OCTAL:
			TokBase = Octal;
			break;
		case WTNM_DECIM:
			TokBase = Decimal;
			break;
		case WTNM_HEX:
			TokBase = Hexadecimal;
			break;
		default:
			if (AddErrors)
			{
				AddError(WTERR_EXPECTEDBASE,nLine,index);
			}
			return FALSE;
	}
	index++; // Skip the base designator
	tok = ta->GetAt(index);
	// This token must be a string of base-N characters
	if (tok.token.tint != WINTIM_STRING)
	{
		if (AddErrors)
		{
			AddError(WTERR_BASEWITHOUTNUM,nLine,index);
		}
		return FALSE;
	}
	sTok = TokenString(ta, index);
	// Now check sTok for legal characters
	switch(TokBase)
	{
		case Binary:
			for (i = 0; i < (int) strlen(sTok); i++)
			{
				if ((sTok.GetAt(i) != '0') && (sTok.GetAt(i) != '1'))
				{
					if (AddErrors)
					{
						sError.Format("(this number contains the character '%c')",sTok.GetAt(i));
						AddError(WTERR_INVALIDBINARY,nLine,index,sError);
					}
					return FALSE;
				}
			}
			break;
		case Octal:
			for (i = 0; i < (int) strlen(sTok); i++)
			{
				if ((sTok.GetAt(i) < '0') || (sTok.GetAt(i) > '7'))
				{
					if (AddErrors)
					{
						sError.Format("(this number contains the character '%c')",sTok.GetAt(i));
						AddError(WTERR_INVALIDOCTAL,nLine,index,sError);
					}
					return FALSE;
				}
			}
			break;
		case Decimal:
			for (i = 0; i < (int) strlen(sTok); i++)
			{
				if ((sTok.GetAt(i) < '0') || (sTok.GetAt(i) > '9'))
				{
					if (AddErrors)
					{
						sError.Format("(this number contains the character '%c')",sTok.GetAt(i));
						AddError(WTERR_INVALIDDECIMAL,nLine,index,sError);
					}
					return FALSE;
				}
			}
			break;
		case Hexadecimal:
			for (i = 0; i < (int) strlen(sTok); i++)
			{
				if ((sTok.GetAt(i) < '0') || (sTok.GetAt(i) > '9'))
				{
					if ( (tolower(sTok.GetAt(i)) < 'a') || (tolower(sTok.GetAt(i)) > 'f') )
					{
						if (AddErrors)
						{
							sError.Format("(this number contains the character '%c')",sTok.GetAt(i));
							AddError(WTERR_INVALIDHEX,nLine,index,sError);
						}
						return FALSE;
					}
				}
			}
			break;
		default: ; // only four cases
	}
	// Now we need to convert sTok into an integer from the appropriate base
	iLen = sTok.GetLength();
	lArg = 0;
	switch(TokBase)
	{
		case Binary:
			for (i = 0; i < iLen; i++)
			{
				lArg += (sTok.GetAt(i) - '0');
				(*numLength)++; // Each binary digit is one bit long
				if (i < iLen - 1)
					lArg <<= 1;
			}
			break;
		case Octal:
			for (i = 0; i < iLen; i++)
			{
				lArg += (sTok.GetAt(i) - '0');
				(*numLength) += 3; // Each octal digit is three bits long
				if (i < iLen - 1)
					lArg <<= 3;
			}
			break;
		case Decimal:
			lArg = atol(sTok);
			(*numLength) = strlen(ltoa(lArg,m_buf,2));  // length of decimal value in binary
			break;
		case Hexadecimal:
			for (i = 0; i < sTok.GetLength(); i++)
			{
				(*numLength) += 4; // Each hex digit is four bits long
				if (sTok.GetAt(i) <= '9')
					lArg += (sTok.GetAt(i) - '0');
				else
					lArg += (tolower(sTok.GetAt(i)) - 'a' + 10);
				if (i < iLen - 1)
					lArg <<= 4;
			}
			break;
		default: ; // only four cases
	}
	return TRUE; // result is in lArg
}

int StringCompare( const void *arg1, const void *arg2 )
{
	/* Compare all of both strings: */
	return ( (*(CString **) arg1)->CompareNoCase(** (CString **) arg2));
}

void CWinTim32View::DumpSymbolTable(SymbolArray *sa, CRichEditCtrl *re)
{
	long i;
	POSITION pos;
	CString key;
	char *format1 = "%-20s%12s%12s%12s%6s\r\n";
	char *format2 = "%-20s%12ld%12.8X%12ld%6d\r\n";
	CString *pString;
	CString **symList;

	if (!IsWindow(re->m_hWnd))
		return;

	re->SetRedraw(FALSE);

	sError.Format("The symbol table contains %d entries:\r\n\r\n",sa->GetCount());
	re->ReplaceSel(sError);

	sError.Format(format1,"Symbol","Line","Address","Length","Valid");
	re->ReplaceSel(sError);
	i = 0;

	symList = (CString **) malloc(sizeof(CString *) * sa->GetCount());

	pos = sa->GetStartPosition();
	while (pos != NULL)
	{
		sa->GetNextAssoc(pos,key,m_Symbol);
		pString = new(CString);
		pString->Format(format2,m_Symbol.sLabel,m_Symbol.lLine+1,m_Symbol.lAddress,
			                m_Symbol.iSymbolLength,m_Symbol.bAddressValid);
		symList[i] = pString;
		if (!(i & 0xf))
		{
			sError.Format("Creating symbol table listing:  Symbol #%d",i);
			theApp.Warning(sError);
		}
		i++;
	}

	// Sort the symbols
	qsort( (void *)symList, (size_t)sa->GetCount(), sizeof( CString * ), StringCompare);

	if (!IsWindow(re->m_hWnd))
		return;

	for (i = 0; i < sa->GetCount(); i++)
	{
		re->ReplaceSel(*(symList[i]));
	}

	re->SetSel(0,0);
	re->SetRedraw(TRUE);
	re->Invalidate();

	for (i = 0; i < sa->GetCount(); i++)
	{
		delete(symList[i]);
	}

	free(symList);
	theApp.Warning("Ready.");
}

void CWinTim32View::DisplayErrors()
// Displays the errors in the error array to the user
{
	long i,iNumErr,iNumWarn,iNumNotice;
	CError *pError;
	CString sErrorType;
	char buf[1024];
	long iErrors = 0;

	iNumErr = 0;
	iNumWarn = 0;
	iNumNotice = 0;

	GetMainFrame()->SetErrorRedraw(FALSE);

	for (i = 0; i < m_ErrorArray.GetSize(); i++)
	{
		pError = &(m_ErrorArray.GetAt(i));
		// Check for ignored warnings
		switch (pError->lErrorCode)
		{
			case WTWARN_ENDBEFOREEOF:
				if (theApp.m_dwWarnings & 0x0001)
					continue;
				break;
			case WTWARN_DEFINASM:
				if (theApp.m_dwWarnings & 0x0002)
					continue;
				break;
			case WTWARN_FIELDLENGTHDISCREPANCY:
				if (theApp.m_dwWarnings & 0x0004)
					continue;
				break;
			case WTWARN_MICROWORDLENGTH:
				if (theApp.m_dwWarnings & 0x0008)
					continue;
				break;
			case WTWARN_FORMDISCREPANCY:
				if (theApp.m_dwWarnings & 0x0010)
					continue;
				break;
			case WTWARN_INVALIDLISTOPTION:
				if (theApp.m_dwWarnings & 0x0020)
					continue;
				break;
			case WTWARN_NOTENOUGHARGS:
				if (theApp.m_dwWarnings & 0x0040)
					continue;
				break;
			default: ;
		}

		if (pError->lErrorCode < WTERR_NONDISRUPTIVE)
		{
			sErrorType = "Fatal Error";
			iNumErr++;
		}
		else if (pError->lErrorCode < WTWARN_NOWARN)
		{
			sErrorType = "Error";
			iNumErr++;
		}
		else if (pError->lErrorCode < WTNOTE_NONOTE)
		{
			sErrorType = "Warning";
			iNumWarn++;
		}
		else
		{
			sErrorType = "Notice";
			iNumNotice++;
		}

		sprintf(buf,"%s 0x%.4X on line %ld: %s %s",sErrorType,pError->lErrorCode,pError->lErrorLine+1,
			GetErrorText(pError->lErrorCode),pError->sExtraText);
		GetMainFrame()->PrintError(buf);
		if (pError->lMacroNum >= 0)
		{
			// Print the line of the macro on which the error occurred.
			// Add one because the main text is zero-based, and another
			// because the macro line points to the line of the start of
			// the macro, not the first line of actual code in the macro
			sprintf(buf,"(this error occurred in macro \"%s\" on line %ld)",
				m_MacroTable.GetAt(pError->lMacroNum).macro,
				m_MacroTable.GetAt(pError->lMacroNum).lStartLine +1 + pError->lLocalLine +1 );
			GetMainFrame()->PrintError(buf);
		}
		iErrors++;
		if (iErrors > theApp.m_ErrorMax)
		{
			// Too many errors to continue
			sError.Format("Maximum error limit of %d reached",theApp.m_ErrorMax);
			GetMainFrame()->PrintError(sError);
			break;
		}
	}
	sError.Format(">>> %d Error%s, %d Warning%s, %d Notice%s",
		iNumErr,iNumErr == 1 ? "" : "s",
		iNumWarn,iNumWarn == 1 ? "" : "s",
		iNumNotice,iNumNotice == 1 ? "" : "s");
	GetMainFrame()->PrintError(sError);
	GetMainFrame()->SetErrorRedraw(TRUE);
}

int CWinTim32View::PushTokenArray(TokenArray *ta, long index, long lMacro, long local)
// Adds the token array and the index to the m_TokenStack
{
	if (m_TokenStack.GetSize() > MAX_STACK)
	{
		return -1;
	}
	m_TokenStack.Add(CTokenStackElement(ta,index,lMacro,local));
	return 0;
}

void CWinTim32View::PullTokenArray(TokenArray **ta, long *index, long *macro, long *local)
// Pulls a token array and index off of the m_TokenStack.
// If there are no more entries in the token stack, returns NULL
// in *ta and 0 in index and macro.
{
	long lStack;
	CTokenStackElement *se;

	if (m_TokenStack.GetSize() == 0)
	{
		(*ta) = NULL;
		(*index) = 0;
		return;
	}
	lStack = m_TokenStack.GetUpperBound();
	se = &(m_TokenStack.GetAt(lStack));
	(*ta) = se->pTokenArray;
	(*index) = se->index;
	(*macro) = se->lMacro;
	(*local) = se->lLocalLine;
	m_TokenStack.RemoveAt(lStack);
}

long CWinTim32View::PeekTokenArray(long &lMacroIndex, int iDepth, long *local)
// Returns a pointer to the previous token array, useful
// for operations such as retrieving the arguments for
// the current macro, and the index into that array at 
// which execution was paused
{
	// If there's nothing on the stack, then that's what we say
	if ((m_TokenStack.GetSize() == 0) || (iDepth > m_TokenStack.GetSize()))
	{
		lMacroIndex = -1;
		return -1;
	}

	if (local != NULL)
	{
		*local = m_TokenStack.GetAt(m_TokenStack.GetSize() - iDepth).lLocalLine;
	}
	lMacroIndex = m_TokenStack.GetAt(m_TokenStack.GetSize() - iDepth).lMacro;
	return m_TokenStack.GetAt(m_TokenStack.GetSize() - iDepth).index;
}

void CWinTim32View::DumpDefinitionTable(CRichEditCtrl *re)
{
	long i,j;
	CDefinition *pSymbol;
	CDefinitionField *pField;
	char *format1 = "%-20s%7s%7s%6s\r\n";
	char *format2 = "%-20s%7ld%7ld%6ld\r\n";

	if (!IsWindow(re->m_hWnd))
		return;

	re->SetRedraw(FALSE);

	sprintf(m_buf,"Definition table contains %d entries:\r\n\r\n",g_DefArray.GetSize());
	re->ReplaceSel(m_buf);

	for (i = 0; i < g_DefArray.GetSize(); i++)
	{
		sprintf(m_buf,format1,"Opcode","Fields","Length","Valid");
		re->ReplaceSel(m_buf);

		pSymbol = &(g_DefArray.GetAt(i));
		sprintf(m_buf,format2,pSymbol->sOpcode,pSymbol->iFields,pSymbol->iLength,pSymbol->bValid);

		if (IsWindow(re->m_hWnd))
			re->ReplaceSel(m_buf);

		for (j = 0; j < pSymbol->iFields; j++)
		{
			pField = &(g_DefArray.GetAt(i).aFields.GetAt(j));
			sError.Format(" (default: 0x%X)",pField->lValue);
			sprintf(m_buf,"  Field %3d: %3d bit%s %10s field%s\r\n",j+1,pField->iBits,pField->iBits == 1 ? ", " : "s,",
				pField->bDCare ? "don't-care" : (pField->bConstant ? "constant" : "variable"),
				(pField->bDCare) ? "" : sError);

			if (IsWindow(re->m_hWnd))
				re->ReplaceSel(m_buf);
		}
		re->ReplaceSel("\r\n");
		if (!(i & 0xf))
		{
			sError.Format("Creating definition table listing:  Definition #%d",i);
			theApp.Warning(sError);
		}
	}
	re->SetSel(0,0);
	re->SetRedraw(TRUE);
	re->Invalidate();
	theApp.Warning("Ready.");
}

void CWinTim32View::OnViewAsassemblyfile() 
{
	m_FileType = AssemblyFile;
	CheckFileType();
	OnViewRefresh();
}

void CWinTim32View::OnViewAsmetafile() 
{
	m_FileType = MetaFile;	
	CheckFileType();
	OnViewRefresh();
}


void CWinTim32View::CheckFileType()
{
	if (m_FileType == AssemblyFile)
	{
		// Check the Assembly file menu item
		theApp.m_pMainWnd->GetMenu()->CheckMenuItem(ID_VIEW_ASASSEMBLYFILE,MF_CHECKED | MF_BYCOMMAND);
		// Uncheck the Meta file menu item
		theApp.m_pMainWnd->GetMenu()->CheckMenuItem(ID_VIEW_ASMETAFILE,MF_UNCHECKED | MF_BYCOMMAND);
		// Uncheck the Text file menu item
		theApp.m_pMainWnd->GetMenu()->CheckMenuItem(ID_VIEW_ASTEXT,MF_UNCHECKED | MF_BYCOMMAND);
	} else if (m_FileType == MetaFile)
	{
		// Check the Meta file menu item
		theApp.m_pMainWnd->GetMenu()->CheckMenuItem(ID_VIEW_ASMETAFILE,MF_CHECKED | MF_BYCOMMAND);
		// Uncheck the Assembly file menu item
		theApp.m_pMainWnd->GetMenu()->CheckMenuItem(ID_VIEW_ASASSEMBLYFILE,MF_UNCHECKED | MF_BYCOMMAND);
		// Uncheck the Text file menu item
		theApp.m_pMainWnd->GetMenu()->CheckMenuItem(ID_VIEW_ASTEXT,MF_UNCHECKED | MF_BYCOMMAND);
	} else
	{
		// Check the Text file menu item
		theApp.m_pMainWnd->GetMenu()->CheckMenuItem(ID_VIEW_ASTEXT,MF_CHECKED | MF_BYCOMMAND);
		// Uncheck the Meta file menu item
		theApp.m_pMainWnd->GetMenu()->CheckMenuItem(ID_VIEW_ASMETAFILE,MF_UNCHECKED | MF_BYCOMMAND);
		// Uncheck the Assembly file menu item
		theApp.m_pMainWnd->GetMenu()->CheckMenuItem(ID_VIEW_ASASSEMBLYFILE,MF_UNCHECKED | MF_BYCOMMAND);
	}
}

void CWinTim32View::SetSyntaxData()
{
	m_SyntaxData.FileType = m_FileType;
	m_SyntaxData.pDefArray = &g_DefArray;
}

void CWinTim32View::CreateObjectFile()
{
	// This parses the m_TokenArray for assembly, generating a 
	// symbol table and filling it with addresses, using a
	// second pass through the file if necessary.

	long index,lRecentString;
	CString sRecentSymbol;
	short iLength;
	CString sRecentString;
	CToken tok;
	CString sTok;
	long lArg;
	TokenArray *ta;
	ADDRESS NextAddress,NextSingleAddress;
	ADDRESS tempAddress, trueNextAddress;
	BOOL TerminateProcessing;
	BOOL bPossibleLabel;
	DWORD iFlags;
	int Pass;
	long nLine, iSecondPassIndex, iSecondPassLine;
	MacroType iMacroType;

	m_OrgArray.RemoveAll();
	m_ErrorArray.RemoveAll(); // Start without errors
	m_SymbolTable.RemoveAll(); // Local symbols initialized
	m_SymbolTable.InitHashTable(GetRichEditCtrl().GetLineCount());
	CopySymbolArray(&g_SymbolTable, &m_SymbolTable); // Copy of global symbols
	m_SecondPassLines.RemoveAll();
	m_CurrentMacroTokenArray.RemoveAll();
	m_Definitions.Initialize(FALSE);
	m_Origin = UNKNOWN_ADDRESS;
	m_BinaryData.RemoveAll();
	m_SourceRef.RemoveAll();
	Pass = 0;
	iSecondPassIndex = 0;
	iSecondPassLine = -1;

	// Guess WORDSIZE/8 / 2 bytes per assembly line initially
	// (Guessing about 50% comments)
	m_BinaryData.SetSize(GetRichEditCtrl().GetLineCount() * (g_iWordSize / 16));

	while ((Pass == 0) || (Pass == 1 && m_SecondPassLines.GetSize() > 0))
	{
		// Parse the entire token array once, then parse it again if we
		// need to fill in some labels that were not reconcilable at the time
		ta = &m_TokenArray;
		NextAddress = NextSingleAddress = 0;
		sRecentSymbol = "";
		lRecentString = -1;
		TerminateProcessing = FALSE;
		m_lCurrentMacro = -1;
		sRecentString = "";
		m_TokenStack.RemoveAll();
		nLine = 0;
		m_lLocalLine = 0;

		index = 0;
		while (ta != NULL)
		{
			if (TerminateProcessing)
				break;
			bPossibleLabel = TRUE;
			while (index < ta->GetSize())
			{
				if (TerminateProcessing)
					break;
				tok = ta->GetAt(index);
				if (m_bShouldAssemble == FALSE)
				{
					if (tok.token.tint == WTKW_ENDIF)
					{
						m_bShouldAssemble = TRUE;
						m_bIfConditional = FALSE;
						m_bInIF = FALSE;
					} else if (tok.token.tint == WTKW_ELSE)
					{
						m_bShouldAssemble = TRUE;
						m_bIfConditional = FALSE;
					}
					index++;
					if (index >= ta->GetSize())
					{
						AddError(WTERR_IFWITHOUTENDIF,nLine,index);
					}
					continue;
				}
				if (m_bIfConditional)
				{
					iFlags = 0;
					if (CanEvaluate(index, ta, &tempAddress, &g_SymbolTable, nLine, &index, &iLength, &iFlags, TRUE))
					{
						if (tempAddress != 0)
						{
							m_bShouldAssemble = TRUE;
						} else
						{
							m_bShouldAssemble = FALSE;
						}
						m_bInIF = TRUE;
					}
					else
					{
						AddError(WTERR_INVALIDIF,nLine,index);
					}
					m_bIfConditional = FALSE;
					index--;
				} else if (nLine != iSecondPassLine)
				{
					if ((Pass == 1) && (iSecondPassIndex < m_SecondPassLines.GetSize()))
					{
						// If this is the second pass, we only need to process
						// the lines in the m_SecondPassLines array
						iSecondPassLine = m_SecondPassLines.GetAt(iSecondPassIndex).iSourceLine;
						while (nLine != iSecondPassLine)
						{
							NewLineCheck(tok,nLine);
							index++;
							if (index > ta->GetUpperBound())
							{
								break; // This really shouldn't happen
							}
							tok = ta->GetAt(index);
						}
						iSecondPassIndex++;
						// continue parsing at the index token now
					} else if ((Pass == 1) && (nLine != iSecondPassLine))
					{
						// If the iSecondPassIndex is greater than the second pass array,
						// and we're no longer on the correct line,
						// then we're finished with the second pass
						TerminateProcessing = TRUE;
						break;
					}
				}
				if (index > ta->GetUpperBound())
				{
					break; // This really shouldn't happen
				}
				// Determine the next address
				if (theApp.m_AddressIndexMode == WT_INDEXBYONE)
				{
					if (m_OrgArray.GetSize() == 0)
						trueNextAddress = NextSingleAddress;
					else
						trueNextAddress = NextSingleAddress + 
						m_OrgArray.GetAt(m_OrgArray.GetUpperBound()).adrNew -
						m_OrgArray.GetAt(m_OrgArray.GetUpperBound()).adrCurrent;
				}
				else
				{
					if (m_OrgArray.GetSize() == 0)
						trueNextAddress = NextAddress;
					else
						trueNextAddress = NextAddress +
						m_OrgArray.GetAt(m_OrgArray.GetUpperBound()).adrNew -
						m_OrgArray.GetAt(m_OrgArray.GetUpperBound()).adrCurrent;
				}
				if (ProcessGenericToken(tok,ta,index,nLine,TerminateProcessing) == TRUE)
				{
					// None of the generic tokens can lead to a label
					bPossibleLabel = FALSE;
				} else switch(tok.token.tint)
				{
					// If the token wasn't generic, we need to check some specifics
					// - EQU, DEF, ORG, macro calls, and labels
					// - Strings, whitespace, and end-of-line tokens
					// WinTim32's keywords
					case WTKW_NULL:
						break;
					// WinTim32's pseudo-ops
					case WTPO_SET:
						// This should equate the rest of the line with the most recent symbol
						if (sRecentSymbol == "")
						{
							AddError(WTERR_NOSYMBOL,nLine,index," - SET needs a symbol");
						} else
						{
							index = EquateSymbol(index+1,sRecentSymbol,&m_SymbolTable,ta,nLine,trueNextAddress);
							// Note that index may be past the end of the file if there is no newline
							index--;  // We want to process the next token, not skip it
						}
						break;
					case WTPO_EQU:
						// This should equate the rest of the line with the most recent symbol
						if (sRecentSymbol == "")
						{
							AddError(WTERR_NOSYMBOL,nLine,index," - EQU needs a symbol");
						} else if (m_SymbolTable.Lookup(sRecentSymbol,m_Symbol))
						{
							if (m_Symbol.lToken != ADDRESS_ONLY)
							{
								// Duplicate symbol
								sError.Format(": \"%s\" is also defined on line %d",sRecentSymbol,m_Symbol.lLine + 1);
								AddError(WTERR_DUPLICATELABEL,nLine, index, sError);
								break;
							}
						}
 						index = EquateSymbol(index+1,sRecentSymbol,&m_SymbolTable,ta,nLine,trueNextAddress);
						// Note that index may be past the end of the file if there is no newline
						index--;  // We want to process the next token, not skip it
						break;
					case WTPO_DEF:
						// The DEF operator should not be encountered during assembly
						AddError(WTWARN_DEFINASM,nLine,index);
						break;
					case WTKW_ALIGN:
						// increase program count until aligned with integral multiple of X
						bPossibleLabel = FALSE;
						iFlags = 0;
						// Find out the offset (put it into tempAddress)
						if (CanEvaluate(index+1,ta,&tempAddress,&m_SymbolTable,nLine,&index,&iLength,&iFlags,TRUE,
							0,FALSE, trueNextAddress))
						{
							// Make the next address an integral multiple of tempAddress
							if (trueNextAddress % tempAddress != 0)
							{
								tempAddress = trueNextAddress + (tempAddress - (trueNextAddress % tempAddress));
							} else
							{
								// We didn't need to move the address at all
								tempAddress = trueNextAddress;
							}
							// Then process like ORG
							if (m_Origin == UNKNOWN_ADDRESS)
							{
								// If this is the first ORG statement, set the start
								// of the binary data to that address.
								m_Origin = tempAddress;
							} else
							{
								// Otherwise set the exact address, relative to the
								// "real" origin
								if (m_Origin > tempAddress)
								{
									// This is a fatal error; you cannot set a new
									// origin earlier than the first origin
									m_FatalError = TRUE;
									m_ErrorCode = WTERR_INVALIDNEWORIGIN;
									m_ErrorLine = nLine;
									m_FatalExtraText.Format("- Current address is %ld, attempted new origin is %ld",
										m_Origin,tempAddress);
									return;
								}
								// NextAddress = tempAddress - m_Origin;
								// NextSingleAddress = NextAddress;
							}
							// Add this origin to the origin array
							m_OrgArray.Add(COrigin(NextSingleAddress,tempAddress,nLine));
							index--;  // Process the newline
						} else
						{
							AddError(WTERR_UNDEFINEDALIGN,nLine,index);
						}
						break;
					case WTPO_RES:
						// Reserve a set of addresses; should behave exactly like
						// ORG $+X
						bPossibleLabel = FALSE;
						iFlags = 0;
						// Find out the offset (put it into tempAddress)
						if (CanEvaluate(index+1,ta,&tempAddress,&m_SymbolTable,nLine,&index,&iLength,&iFlags,TRUE,
							0,FALSE, trueNextAddress))
						{
							// Add it to the current address
							tempAddress += trueNextAddress;
							// Process the same as a standard ORG
							if (m_Origin == UNKNOWN_ADDRESS)
							{
								// If this is the first ORG statement, set the start
								// of the binary data to that address.
								m_Origin = tempAddress;
							} else
							{
								// Otherwise set the exact address, relative to the
								// "real" origin
								if (m_Origin > tempAddress)
								{
									// This is a fatal error; you cannot set a new
									// origin earlier than the first origin
									m_FatalError = TRUE;
									m_ErrorCode = WTERR_INVALIDNEWORIGIN;
									m_ErrorLine = nLine;
									m_FatalExtraText.Format("- Current address is %ld, attempted new origin is %ld",
										m_Origin,tempAddress);
									return;
								}
								// NextAddress = tempAddress - m_Origin;
								// NextSingleAddress = NextAddress;
							}
							// Add this origin to the origin array
							m_OrgArray.Add(COrigin(NextSingleAddress,tempAddress,nLine));
							index--;  // Process the newline
						} else
						{
							AddError(WTERR_UNDEFINEDORG,nLine,index);
						}
						break;
					case WTPO_ORG:
						// The rest of the line should be an expression representing the next
						// address a line of code should have.
						bPossibleLabel = FALSE;
						iFlags = 0;
						if (CanEvaluate(index+1,ta,&tempAddress,&m_SymbolTable,nLine,&index,&iLength,&iFlags,TRUE,
							0,FALSE, trueNextAddress))
						{
							if (m_Origin == UNKNOWN_ADDRESS)
							{
								// If this is the first ORG statement, set the start
								// of the binary data to that address.
								m_Origin = tempAddress;
							} else
							{
								// Otherwise set the exact address, relative to the
								// "real" origin
								if (m_Origin > tempAddress)
								{
									// This is a fatal error; you cannot set a new
									// origin earlier than the first origin
									m_FatalError = TRUE;
									m_ErrorCode = WTERR_INVALIDNEWORIGIN;
									m_ErrorLine = nLine;
									m_FatalExtraText.Format("- Current address is %ld, attempted new origin is %ld",
										m_Origin,tempAddress);
									return;
								}
								// NextAddress = tempAddress - m_Origin;
								// NextSingleAddress = NextAddress;
							}
							// Add this origin to the origin array
							m_OrgArray.Add(COrigin(NextSingleAddress,tempAddress,nLine));
//							afxDump << "Origin(" << NextSingleAddress << "," << 
//								tempAddress << "," << nLine << ")\n";
							index--;  // Process the newline
						} else
						{
							AddError(WTERR_UNDEFINEDORG,nLine,index);
						}
						break;
					case WTCH_LABEL:
						if (lRecentString == -1)
						{
							AddError(WTERR_NOLABEL,nLine,index);
						} else
						{
							if (bPossibleLabel)
							{
								// Make this label our "most recent symbol" for equating
								sTok = TokenString(ta, lRecentString);
								// Add this symbol along with its address to the symbol table
								sTok.MakeUpper();
								if (m_SymbolTable.Lookup(sTok,m_Symbol))
								{
									if (Pass == 1)
									{
										// Only on the second pass is the re-setting of a label appropriate
										sRecentSymbol = sTok;
										// Don't re-set the address, since NextAddress isn't valid
										// m_SymbolTable.SetAt(iTemp,CSymbol(sTok,nLine,NextAddress,ADDRESS_ONLY,m_Definitions.iWordSize,TRUE));
									} else
									{
										// Otherwise it's a duplicate label, but that might
										// be okay, depending on the opcode ("SET" works)
										// AddError(WTERR_DUPLICATELABEL,nLine,index);
										sRecentSymbol = sTok;
									}
								} else
								{
									// Add the label to the label map, offsetting it by the current
									// origin from m_OrgArray
									sRecentSymbol = sTok;
									m_SymbolTable.SetAt(sTok,
										CSymbol(sTok,nLine,trueNextAddress,ADDRESS_ONLY,m_Definitions.iWordSize,TRUE));
								}
							}
						}
						// If recent not at char zero, this isn't a proper label
						break;
					// Anything that isn't a token
					case WINTIM_STRING:
						lRecentString = index;
						sRecentString = TokenString(ta, index);
						index = SkipString(nLine, index, ta);
						break;
					// Miscellaneous pseudo-tokens
					case WINTIM_ENDSTRING:
						bPossibleLabel = FALSE;
						break;
					case WINTIM_WHITESPACE:
						break;
					case WINTIM_ENDPROGRAM:
						break;
					case WINTIM_MACRO:
						index++; // Skip the WINTIM_MACRO keyword
						tok = ta->GetAt(index);  // The index of the macro in m_MacroTable
						// Put the current token array and index of the next token after
						// the macro call onto the stack
						lArg = tok.token.tint;  // Hold on to the macro index
						index++; // Skip the macro number
						tok = ta->GetAt(index);
						// Skip all of the NULL keywords that the macro replaced
						while (tok.token.tint == WTKW_NULL)
						{
							index++;
							tok = ta->GetAt(index);
						}
						// Store this index on the stack
						if (PushTokenArray(ta,index,m_lCurrentMacro,m_lLocalLine) == -1)
						{
							m_FatalError = TRUE;
							m_ErrorCode = WTERR_STACKOVERFLOW;
							m_ErrorLine = nLine;
							return;
						}
						// Switch to the macro's token array
						m_lLocalLine = 0;
						m_lCurrentMacro = lArg;
						m_CurrentMacroTokenArray.Copy(m_MacroTable.GetAt(lArg).contents);
						ta = &m_CurrentMacroTokenArray;
						index = -1; // Start at the beginning of the macro
						break;
					case WINTIM_ENDLINE:
						if (ta == &m_TokenArray)
						{
							// Only increment the line count if we aren't inside a macro
							nLine++;
							if (!(nLine & 0xf))
							{
								sError.Format("Assembly:  Line %d",nLine);
								theApp.Warning(sError);
							}
						}
						m_lLocalLine++; // but always increment the local line number
						lRecentString = -1;
						bPossibleLabel = TRUE;
						break;
					case WINTIM_DCENDLINE:
						m_lLocalLine++; // always increment the local line number
						lRecentString = -1;
						bPossibleLabel = TRUE;
						break;
					default: // Something unrecognized
						bPossibleLabel = FALSE;
						// Is it a user-defined opcode?
						if ((tok.token.tint >= WINTIM_USEROP) &&
							(tok.token.tint < WINTIM_USEROP + g_DefArray.GetSize()))
						{
							// Yes, it is
							if (Pass == 0)
							{
								// Add an instruction using the next address
								NextAddress += AssembleInstruction(index,&m_SymbolTable,ta,&m_BinaryData,NextAddress,
									NextSingleAddress,&index,nLine,Pass);
							}
							else
							{
								// Add an instruction using the saved address
								NextAddress += AssembleInstruction(index,&m_SymbolTable,ta,&m_BinaryData,
									m_SecondPassLines.GetAt(iSecondPassIndex-1).dataAddress,
									m_SecondPassLines.GetAt(iSecondPassIndex-1).dataSingleAddress,
									&index,nLine,Pass);
							}
							// The next single-step address is always one greater
							NextSingleAddress++;
							index--;  // Process the end of line token
						} else
						{
							sError.Format("- %s",GetTokenName(tok));
							AddError(WTERR_UNRECOGNIZEDTOKEN,nLine,index,sError);
						}
				}
				index++;
				if (m_FatalError)
					return; // Bail!  Bail!
			}
			if (TerminateProcessing)
				break;
			if (m_lCurrentMacro >= 0)
				iMacroType = m_MacroTable.GetAt(m_lCurrentMacro).type;
			else
				iMacroType = Substitution;

			PullTokenArray(&ta,&index,&m_lCurrentMacro,&m_lLocalLine); // ta gets NULL if no more elements
			if (ta != &m_TokenArray)
			{
				if (ta == NULL)
					break; // This should stop the process
				// If we're inside another macro, set m_CurrentMacroTokenArray
				// to what it should be, and continue
				m_CurrentMacroTokenArray.RemoveAll();
				m_CurrentMacroTokenArray.Copy(m_MacroTable.GetAt(m_lCurrentMacro).contents);
				ta = &m_CurrentMacroTokenArray;
			} 
			// Skip the macro's arguments (if any)
			if ((iMacroType == Normal) && (index < ta->GetSize()))
			{
				tok = ta->GetAt(index);
				// There can only be arguments if it is a normal macro
				while ((tok.token.tint == WTCH_COMMA) || 
					   ((tok.token.tint > WINTIM_MACRO) &&
						(tok.token.tint < WINTIM_MACRO+255)))
				{
					index++;
					if (index > ta->GetUpperBound())
						break;
					tok = ta->GetAt(index);
				}
			}

		} // End of token-array loop
		Pass++;
	} // End of two-pass while loop
	DisplayErrors();

	// Clean up our memory mess
	m_CurrentMacroTokenArray.RemoveAll();
	m_SecondPassLines.RemoveAll();
	theApp.Warning("Ready.");
}

void CWinTim32View::RemoveInvalidEntries(SymbolArray *sa)
// Removes all entries from a symbol table that are marked as invalid
{
	POSITION pos;
	CString key;

	pos = sa->GetStartPosition();
	while (pos != NULL)
	{
		sa->GetNextAssoc(pos,key,m_Symbol);
		if (m_Symbol.bAddressValid == FALSE)
		{
			sa->RemoveKey(key);
			pos = sa->GetStartPosition();  // start over
		}
	}
}

ADDRESS CWinTim32View::AssembleInstruction(long index, SymbolArray *sa, TokenArray *ta, CByteArray *ba, ADDRESS aNext,
										   ADDRESS aNextSingle, long *newindex, long &nLine, int Pass)
// Takes a line of assembly code (with a user defined instruction
// in g_DefArray at the index) and converts it to a sequence of bytes
// (if possible) which are then stored in the byte array "ba"
// If the arguments cannot be evaluated, null data is substituted, which
// is to be replaced on the second pass.
// Return value:  the number of bytes this instruction occupies, and
// the index of the end of the line in *newindex
{
	CToken tok;
	CDefinition def;
	CDefinitionField dfield;
	short iOpcode;
	short iOpLen;
	short iNumFields;
	ADDRESS result,InstSize;
	int i,j;
	short iArgLength;
	DWORD iFlags;
	int iBit, iNumVarFields;
	CByteArray aBits; // One byte per bit in the bitfields (temporary)
	BYTE tempByte;
	int iUseDefault;  // How many times to use the default field
	long lStartLine;
	short iCurrentMacro;
	ADDRESS EquateAddress;

	tok = ta->GetAt(index);
	iOpcode = tok.token.tint - WINTIM_USEROP; // Get the user-defined opcode
	def = g_DefArray.GetAt(iOpcode);
	iOpLen = def.iLength; // bit-length of instruction
	iNumFields = def.iFields; // number of arguments
	aBits.RemoveAll();
	iCurrentMacro = 0;

	// The minimum number of bytes necessary to hold this
	// instruction (add one if iOpLen is not divisible by 8)
	InstSize = (iOpLen / 8) + (iOpLen & 0x7 != 0);

	i = 0;
	lStartLine = nLine;
	iBit = 0;
	iNumVarFields = 0;
	iUseDefault = 0;
	index++;
	while (i < iNumFields)
	{
		if (index < ta->GetUpperBound())
		{
			tok = ta->GetAt(index);
			while (NewLineCheck(ta->GetAt(index),nLine,FALSE) && (ta->GetAt(index+1).token.tint == WTCH_SLASH))
			{
				m_lLocalLine++;
				if (ta->GetAt(index).token.tint != WINTIM_DCENDLINE)
					nLine++;
				index += 2;
				if (index >= ta->GetUpperBound())
					break;
				tok = ta->GetAt(index);
			}
		}

		// Grab the first argument's field options
		dfield = def.aFields.GetAt(i);
		// Is this field a variable one?
		if (dfield.bConstant)
		{
			// Yes, so the value for this field is simply the constant in the field definition
			result = dfield.lValue;
			iArgLength = dfield.iBits;
		} else if (dfield.bDCare)
		{
			if (m_Definitions.iDCareBit == 0)
			{
				result = 0;
			} else
			{
				result = (1 << dfield.iBits) - 1;
			}
			iArgLength = dfield.iBits;
		} else if (iUseDefault > 0)
		{
			// A previous "[x]" is telling us to use the default value for this
			// field
			iUseDefault--;
			iNumVarFields++;
			result = dfield.lValue;
			iArgLength = dfield.iBits;  // defaults are always the correct length
		} else
		{
			iNumVarFields++;
			// Make sure there is a next argument
			if (NewLineCheck(ta->GetAt(index),nLine,FALSE) == FALSE)
			{
				// See if we can evaluate the next argument on the line
				// (Gripe about label errors if this is the second pass)
				iFlags = 0;
				if (theApp.m_AddressIndexMode == WT_INDEXBYONE)
				{
					EquateAddress = (aNextSingle);
				} else
				{
					EquateAddress = (aNext);
				}
//				afxDump << "EquateAddress = " << EquateAddress << "\n";
				if (CanEvaluate(index,ta,&result,sa,nLine,&index,&iArgLength,&iFlags,(Pass == 1),
					0,FALSE,EquateAddress))
				{
					// If the WT_MULTIDEFAULT flag is set, then the argument was
					// something of the form "[x]", which means to skip to argument x
					// and use the defaults for everything up to it.  Note that this
					// only skips variable fields, and result (x) must be greater than
					// the current argument number (plus one, since it's zero-based
					// internally).

					if (iFlags & WT_MULTIDEFAULT)
					{
						if ((signed) result <= i)
						{
							// We can't skip arguments that we've already processed
							sError.Format(" - an expression equating to [%d] was parsed, but the current field is already %d",
								result, i+1);
							AddError(WTWARN_CANNOTSKIP,nLine,index,sError);
						} else
						{
							// (minus an extra one because the current field
							// in variable "i" is zero-based
							iUseDefault = (result - i - 1);
							iNumVarFields--;
							if (ta->GetAt(index).token.tint == WTCH_COMMA)
								index++;  // Skip the comma
							continue;
						}
					}

					// If the WT_DEFAULT flag is set, then we look in the definition array
					// for the value to place into this argument (or zero if it doesn't
					// exist, but produce a warning in that case)
					if (iFlags & WT_DEFAULT)
					{
						result = dfield.lValue;
						iArgLength = dfield.iBits;  // defaults are always the correct length
					}

					// If the WT_RELATIVE flag is set, then we need to use the difference
					// between the current address and the result instead of the literal
					// value returned

					if (iFlags & WT_RELATIVE)
					{
						if (theApp.m_AddressIndexMode == WT_INDEXBYONE)
						{
							result = result - (aNextSingle + 1);
						} else
						{
							result = result - (aNext + InstSize);
						}
					}

					// Make sure the number of bits in the argument matches up with
					// the number we're expecting, otherwise raise a warning
					// (although we can still use the lower bits of the data)
					if (iArgLength < dfield.iBits)
					{
						if (!(iFlags & WT_JUSTIFY))
						{
							// If the user didn't auto-fit this field,
							// generate an actual warning
							sError.Format("- got %d bit%s (value: 0x%X) for variable field %d (generic field %d), but the field length was defined to be %d bit%s",
								iArgLength,iArgLength == 1 ? "" : "s", result, iNumVarFields, i+1,
								dfield.iBits,dfield.iBits == 1 ? "" : "s");
							AddError(WTWARN_FIELDLENGTHDISCREPANCY,nLine,index,sError);
						}
					} else if (iArgLength > dfield.iBits)
					{
						if (!(iFlags & WT_TRUNCATE))
						{
							// If the user didn't auto-fit this field,
							// generate an actual warning
							sError.Format("- got %d bit%s (value: 0x%X) for variable field %d (generic field %d), but the field length was defined to be %d bit%s",
								iArgLength,iArgLength == 1 ? "" : "s", result, iNumVarFields, i+1,
								dfield.iBits,dfield.iBits == 1 ? "" : "s");
							AddError(WTWARN_FIELDLENGTHDISCREPANCY,nLine,index,sError);
						}
					} // otherwise, it fit exactly
				} else
				{
					// If we couldn't evaluate the expression, just place dummy data
					// into the result variable and make iArgLength the right size
					result = UNKNOWN_ADDRESS;
					iArgLength = dfield.iBits;
					// Also add this line to the array of lines which must be
					// re-processed (if this is pass one) or produce an undefined
					// label error (on pass two)
					if (Pass == 0)
					{
						m_SecondPassLines.Add(CSecondPassData(lStartLine,aNext,aNextSingle));
					} else
					{
						// The error should already be taken care of by CanEvaluate()
						// AddError(WTERR_UNDEFINEDLABEL,nLine,index);
					}
				}
				if (ta->GetAt(index).token.tint == WTCH_COMMA)
					index++;  // Skip the comma
			} else
			{
				// We needed an argument, but there wasn't one on the line
				// so substitute the default value and raise a warning
				iArgLength = dfield.iBits;
				result = iNumVarFields - 1;
				j = i;
				while (j < iNumFields)
				{
					if ((def.aFields.GetAt(i).bConstant == FALSE) && (def.aFields.GetAt(i).bDCare == FALSE))
						iNumVarFields++;
					j++;
				}
				iNumVarFields--;
				if (Pass == 0)
				{
					sError.Format("- This instruction (%s) suggests %d argument%s, and %d %s supplied",
						def.sOpcode,iNumVarFields,iNumVarFields == 1 ? "" : "s",
						result, result == 1 ? "was" : "were");
					AddError(WTWARN_NOTENOUGHARGS,nLine,index,sError);
				}
				result = dfield.lValue;       // Use the default value for this field
				iUseDefault = iNumVarFields;  // Use for any remaining fields
				iArgLength = dfield.iBits;    // defaults are always the correct length
			}
			// Force result to be the appropriate number of bits
			if (dfield.iBits > 31)
			{
				result &= 0xffffffff;
			} else
			{
				result &= ((1 << dfield.iBits) - 1);
			}
		}
		// Now, pack the result into as many bytes as necessary
		iArgLength = dfield.iBits;  // Force to conform to field length
		while (iArgLength > 0)
		{
			aBits.Add((result & (1 << (iArgLength-1))) > 0 ? 1 : 0);
			iArgLength--;
		}
		i++;
	}

	if (index < ta->GetUpperBound())
	{
		if (NewLineCheck(ta->GetAt(index),nLine,FALSE) == FALSE)
		{
			// Too many arguments were specified for this opcode
			sError.Format("- This instruction (%s) only needs %d argument%s",
				def.sOpcode,iNumVarFields,iNumVarFields == 1 ? "" : "s");
			AddError(WTERR_TOOMANYARGS,nLine,index,sError);
			while (NewLineCheck(ta->GetAt(index),nLine,FALSE) == FALSE)
			{
				index++;
				if (index > ta->GetUpperBound())
					break;
			}
		}
	}

	if (Pass == 0)
	{
		// On the first pass, we will know what the lengths of all
		// of the instructions will be, if not the actual data
		// (This needs to be the actual instruction size, independent
		// of the address index setting)
		m_SourceRef.Add(CSourceRef((short) InstSize,nLine,(short) m_lCurrentMacro,m_lLocalLine));
	}

	// Now, take the bits stored in aBits and actually pack them into the
	// byte array "ba"

	j = 7;  // Start at bit 7
	tempByte = 0x00;
	for (i = 0; i < aBits.GetSize(); i++)
	{
		tempByte |= (aBits.GetAt(i) << j);
		j--;
		if (j == -1)
		{
			j = 7;
			ba->SetAtGrow(aNext,tempByte);
			aNext++;
			tempByte = 0x00;
		}
	}
	if ((j >= 0) && (j < 7))
	{
		// We didn't quite finish that last byte
		ba->SetAtGrow(aNext,tempByte);
		aNext++;
	}

	// Set the return index value to the end of the line
	*newindex = index;

	return InstSize;
}

void CWinTim32View::DisplayBitstring(CByteArray *aBits, long nLine)
{
#ifdef _DEBUG
	int i;

	for (i = 0; i < aBits->GetSize(); i++)
	{
		afxDump << (aBits->GetAt(i) == 0 ? "0" : "1");
	}
	afxDump << " ; " << GetEditLine(nLine, &(GetRichEditCtrl()));
#endif
}

CString CWinTim32View::GetEditLine(long nLine, CRichEditCtrl *re)
{
	int nLineLen;

	re->GetLine(nLine,m_cBuffer,MAX_RELINE); // Copy line to CBuffer

	// Hack to set current line length (GetLineLength() has a bug)
	nLineLen = re->LineIndex(nLine+1) - re->LineIndex(nLine);
	if (nLineLen < 0)
		nLineLen = re->GetTextLength() - re->LineIndex(nLine);
	m_cBuffer[nLineLen] = '\0';
	return CString(m_cBuffer);
}

void CWinTim32View::DumpByteArray(CByteArray *ba, CSourceRefArray *sra, long iStart, long iFinish, CRichEditCtrl *re, BOOL bMIF)
{
	long i,j,iByteIndex,iMIFIndex,iPage,iLocalLine,iSourceLine,iPageLines,iOrigin,iHeaderLen;
	long iAbsoluteMIFIndex, lNextOrgLine;
	CString sText, sTemp, sHeader;
	CString sObjFmt, sAdrFmt;
	ADDRESS aCurrent;
	DWORD dwList;
	int iOrgIndex;
	CString sObjectCode;   // This will get quite large if there is a lot of code
	BOOL bInMacroExpansion = FALSE;
	long iCurrentMacro;
	BOOL bPrintMacro;

	iOrgIndex = 0;
	iCurrentMacro = -1;
	bPrintMacro = FALSE;
	m_OrgArray.Add(COrigin(2^30,2^30,GetRichEditCtrl().GetLineCount()+1));  // Make sure there's a stopping point

	iByteIndex = 0;

	if (iFinish > sra->GetUpperBound())
		iFinish = sra->GetUpperBound();

	aCurrent = m_Origin;
	if (aCurrent == UNKNOWN_ADDRESS)
		aCurrent = 0;
	iOrigin = aCurrent;
	iMIFIndex = 0;
	iAbsoluteMIFIndex = 0;
	lNextOrgLine = m_OrgArray.GetAt(iOrgIndex).lLine;
	iPageLines = m_Definitions.iPageLines - 5;
	if (iPageLines < 10)
		iPageLines = 10;
	iLocalLine = iPageLines + 1;
	iSourceLine = 0;
	iPage = 0;
	dwList = m_Definitions.listOptions.dwFlags;
	sObjectCode = "";

	if (m_Definitions.sObjectCodeFormat == "")
	{
		for (i = 0; i < (m_Definitions.iWordSize / 4); i++)
		m_Definitions.sObjectCodeFormat += '4';
	}

	iHeaderLen = strlen(m_Definitions.sObjectCodeFormat);

	if (dwList & WTLO_OBJECTCODEATLEFT)
	{
		sObjFmt.Format("%%%dd ",12 + iHeaderLen);
		sAdrFmt.Format("%%.5X%%%dd ",7 + iHeaderLen);
		sText.Format(" Addr %%-%d.%ds  Line",iHeaderLen,iHeaderLen);
		sHeader.Format(sText,m_Definitions.sHeader);
	} else
	{
		sObjFmt = "%12d ";
		sAdrFmt = "%.5X%7d ";
		sHeader = " Addr   Line";
	}

	re->SetRedraw(FALSE);

	if (bMIF)
	{
		sText.Format("-- %s\r\n\
-- Altera Instruction Memory Initialization File\r\n\
Depth = 256;\r\n\
Width = %d;\r\n\
Address_radix = HEX;\r\n\
Data_radix = HEX;\r\n\
Content\r\n\
Begin\r\n\
-- Use NOPS for default instruction memory values\r\n\
    [00..FF]: 00000000; -- nop\r\n\
-- Place MIPS Instructions here\r\n\
-- Note: memory addresses are in words and not bytes\r\n\
-- i.e. next location is +1 and not +4\r\n\
",m_Definitions.sTitle,m_Definitions.iWordSize);
		re->ReplaceSel(sText);
	}

	for (i = iStart; i <= iFinish; i++)
	{
		iCurrentMacro = sra->GetAt(i).iMacro;

		if ((!bMIF) && (iLocalLine > iPageLines ))
		{
			iLocalLine = 1;
			iPage++;
			sText.Format("%cHALE Listing: %-24.24s %-27.27s Page%4d\r\n\r\n%s %s\r\n\r\n",
				12,GetDocument()->GetTitle(),CTime::GetCurrentTime().Format("%b %d %H:%M:%S %Y"),
				iPage,sHeader,m_Definitions.sTitle);
			re->ReplaceSel(sText);
		}

		if ((iCurrentMacro >= 0) && (sra->GetAt(i).lLocalLine == 0) && (sra->GetAt(i).iSourceLine == iSourceLine))
		{
			// When we start a macro, print the line containing the macro call
			bPrintMacro = TRUE;
		}

		while ( (sra->GetAt(i).iSourceLine != iSourceLine) || (bPrintMacro == TRUE))
		{
			if (iSourceLine > GetRichEditCtrl().GetLineCount())
				break;
			if (!bMIF)
			{
				if (iLocalLine > iPageLines)
				{
					iLocalLine = 1;
					iPage++;
					sText.Format("%cHALE Listing: %-24.24s %-27.27s Page%4d\r\n\r\n%s %s\r\n\r\n",
						12,GetDocument()->GetTitle(),CTime::GetCurrentTime().Format("%b %d %H:%M:%S %Y"),
						iPage,sHeader,m_Definitions.sTitle);
					re->ReplaceSel(sText);
				}
				if ((dwList & WTLO_ADDRESSEVERYLINE) || (lNextOrgLine <= iSourceLine))
				{
					if (lNextOrgLine <= iSourceLine)
					{
						lNextOrgLine = m_OrgArray.GetAt(iOrgIndex+1).lLine;
						aCurrent = m_OrgArray.GetAt(iOrgIndex).adrNew;
						iMIFIndex = aCurrent;
						iOrgIndex++;
					}
					if (theApp.m_AddressIndexMode == WT_INDEXBYSIZE)
						sText.Format(sAdrFmt,aCurrent,iSourceLine+1);
					else
						sText.Format(sAdrFmt,iMIFIndex,iSourceLine+1);
				} else
				{
					sText.Format(sObjFmt,iSourceLine+1);
				}
				sText += GetEditLine(iSourceLine, &(GetRichEditCtrl()));
				re->ReplaceSel(sText);
			}
			iLocalLine++;
			if (bPrintMacro == TRUE)
				break;
			iSourceLine++;
			if (!(iSourceLine & 0xf))
			{
				sError.Format("Creating output listing:  Line %d",iSourceLine);
				theApp.Warning(sError);
			}
			if ((iCurrentMacro >= 0) && (sra->GetAt(i).lLocalLine == 0) && (sra->GetAt(i).iSourceLine == iSourceLine))
			{
				// When we start a macro, print the line containing the macro call
				bPrintMacro = TRUE;
			}

		}

		bPrintMacro = FALSE;

		if (bMIF)
		{
			sText.Format("%6.2X: ",iMIFIndex);
		} else
		{
			if (theApp.m_AddressIndexMode == WT_INDEXBYSIZE)
				sText.Format("%.5X ",aCurrent);
			else
				sText.Format("%.5X ",iMIFIndex + iOrigin);
		}
		iMIFIndex++;
		iAbsoluteMIFIndex++;

		if ((dwList & WTLO_OBJECTCODEATLEFT) == 0)
			sTemp = sText;

		if (bMIF)
		{
			for (j = 0; j < sra->GetAt(i).iByteLength; j++)
			{
				if (iByteIndex > ba->GetUpperBound())
				{
					// Something went wrong
					break;
				}
				sprintf(m_buf,"%.2X",ba->GetAt(iByteIndex));
				iByteIndex++;
				sText += m_buf;
			}
		} else
		{
			sText += FormatBits(ba,iByteIndex,sra->GetAt(i).iByteLength + iByteIndex);
		}
		// Now we have the address/object code pair in sText;
		sObjectCode += sText + "\r\n";

		if (bMIF)
		{
			sText += ";   -- ";
		}
		else 
		{
			if ((dwList & WTLO_OBJECTCODEATLEFT) == 0)
				sText = sTemp;
			sprintf(m_buf,"%6d ",iSourceLine+1);
			sText += m_buf;
		}

		if (iCurrentMacro < 0)
		{
			// Don't add the macro text again
			sText += GetEditLine(sra->GetAt(i).iSourceLine, &(GetRichEditCtrl()));
		} else
		{
			sText += CString('+',1);
			sText += GetEditLine(m_MacroTable.GetAt(sra->GetAt(i).iMacro).lStartLine +
				                       sra->GetAt(i).lLocalLine + 1,&(GetRichEditCtrl()));
		}

		re->ReplaceSel(sText);
		aCurrent += sra->GetAt(i).iByteLength;

		iLocalLine++;

		// Don't increment the source line if the next line in the
		// source-reference array is the same as the current line
		
		if (i < sra->GetUpperBound())
		{
			if (sra->GetAt(i+1).iSourceLine != iSourceLine)
			{
				iSourceLine++;
			}
		} else
		{
			iSourceLine++;
		}

		if (!(iSourceLine & 0xf))
		{
			sError.Format("Creating output listing:  Line %d",iSourceLine);
			theApp.Warning(sError);
		}
	}

	if (bMIF)
	{
		re->ReplaceSel("End;");
	} else while (iSourceLine < GetRichEditCtrl().GetLineCount())
	{
		// Finish off the rest of the non-code lines in the source file
		if (iLocalLine > iPageLines)
		{
			iLocalLine = 1;
			iPage++;
			sText.Format("%cHALE Listing: %-24.24s %-27.27s Page%4d\r\n\r\n%s %s\r\n\r\n",
				12,GetDocument()->GetTitle(),CTime::GetCurrentTime().Format("%b %d %H:%M:%S %Y"),
				iPage,sHeader,m_Definitions.sTitle);
			re->ReplaceSel(sText);
		}

		sText.Format(sObjFmt,iSourceLine+1);
		sText += GetEditLine(iSourceLine, &(GetRichEditCtrl()));
		re->ReplaceSel(sText);

		iSourceLine++;
		iLocalLine++;
		if (!(iSourceLine & 0xf))
		{
			sError.Format("Creating output listing:  Line %d",iSourceLine);
			theApp.Warning(sError);
		}
	}

	re->ReplaceSel("\r\n");

	if (!bMIF)
	{
		// Process some LIST options
		if (dwList & WTLO_OBJECTCODE)
		{
			re->ReplaceSel("\r\n\f\r\nObject Code Block Listing\r\n\r\n\r\n");
			re->ReplaceSel(CString("      ") + m_Definitions.sHeader + "\r\n");
			re->ReplaceSel(sObjectCode);
		}
	}

	re->SetSel(0,0);
	re->SetRedraw(TRUE);
	re->Invalidate();
	theApp.Warning("Ready.");
}

CString CWinTim32View::GetErrorText(long code)
{
	CString sText;

	switch(code)
	{
		case WTERR_NOERROR:
			sText = "No error occurred";
			break;

		// disruptive errors (parsing cannot continue)
		case WTERR_NEWLINEINSTRING:
			sText = "A newline was found inside a quoted string";
			break;
		case WTERR_NOSTRINGHEADER:
			sText = "A string was found without a string header (internal error)";
			break;
		case WTERR_MACROWITHOUTENDM:
			sText = "A MACRO keyword has no corresponding ENDM";
			break;
		case WTERR_ILLEGALCHARACTER:
			sText = "An illegal character was encountered";
			break;
		case WTERR_ARGANDCOMMAONLY:
			sText = "Macros should have only arguments and commas";
			break;
		case WTERR_NOCOMMAAFTERARG:
			sText = "A macro argument was followed by a character other than a comma";
			break;
		case WTERR_UNTERMINATEDSTRING:
			sText = "A string constant was unterminated (internal error)";
			break;
		case WTERR_STACKOVERFLOW:
			sText = "The maximum stack size was reached";
			break;
		case WTERR_INVALIDNEWORIGIN:
			sText = "The specified origin has a lower address than a previous origin";
			break;
		case WTERR_MAXRECURSION:
			sText.Format("The maximum recursion depth of %d for expression evaluation has been reached",MAX_RECURSION_DEPTH);
			break;
		case WTERR_INCLUDEFAILED:
			sText = "Inclusion of a file failed, most likely because the file did not exist";
			break;
		case WTERR_ELSEWITHOUTIF:
			sText = "An ELSE statement was found with no corresponding IF statement";
			break;

		// nondisruptive errors (parsing can continue)
		case WTERR_UNEXPECTEDTOKEN:
			sText = "The token specified was unexpected";
			break;
		case WTERR_INVALIDNUMBER:
			sText = "A valid number was expected but not found";
			break;
		case WTERR_NOLABEL:
			sText = "A label character (:) was found with no preceding text";
			break;
		case WTERR_NOSYMBOL:
			sText = "An equating statement was found with no corresponding label";
			break;
		case WTERR_NOOPERATOR:
			sText = "Two or more expressions must be joined by a mathematical operator";
			break;
		case WTERR_EXPECTEDBASE:
			sText = "One of the B#, O#, Q#, H#, or D# base tokens was expected";
			break;
		case WTERR_INVALIDBASE:
			sText = "The base must be one of B#, O#, Q#, H#, or D#";
			break;
		case WTERR_BASEWITHOUTNUM:
			sText = "The base designator must be followed by a numeric string";
			break;
		case WTERR_INVALIDBINARY:
			sText = "Binary numbers must contain only 1 and 0 characters";
			break;
		case WTERR_INVALIDOCTAL:
			sText = "Octal numbers must contain only the digits 0-7";
			break;
		case WTERR_INVALIDDECIMAL:
			sText = "Decimal numbers must contain only the digits 0-9";
			break;
		case WTERR_INVALIDHEX:
			sText = "Hexaecimal numbers must contain only the digits 0-9 and a-f";
			break;
		case WTERR_ILLEGALTOKENINEXPR:
			sText = "An invalid token was found inside an expression";
			break;
		case WTERR_UNDEFINEDORG:
			sText = "The origin address could not be interpreted";
			break;
		case WTERR_UNDEFINEDALIGN:
			sText = "The address for alignment could not be interpreted";
			break;
		case WTERR_UNRECOGNIZEDTOKEN:
			sText = "A token was unrecognized or unexpected";
			break;
		case WTERR_NOTENOUGHARGS:
			sText = "The number of arguments in the macro call does not match the number in the definition";
			break;
		case WTERR_UNDEFINEDLABEL:
			sText = "A label was undefined";
			break;
		case WTERR_DUPLICATELABEL:
			sText = "A duplicate label was found";
			break;
		case WTERR_MULTIPLEVARS:
			sText = "Multiple variable/don't-care designators found";
			break;
		case WTERR_VARAFTERTWONUMS:
			sText = "The variable/don't-care designator must be after the first number in a field";
			break;
		case WTERR_INTERNALMACROINCONS:
			sText = "A macro argument was found in top-level code";
			break;
		case WTERR_PARENMISMATCH:
			sText = "The number of '(' characters on this line exceeds the number of matching ')' characters";
			break;
		case WTERR_MULTIPLEOPS:
			sText = "Two mathematical or logical operators are adjacent";
			break;
		case WTERR_OPATENDLINE:
			sText = "A mathematical or logical operator was found at the end of an expression";
			break;
		case WTERR_OPBEFOREEXPR:
			sText = "A mathematical of logical operator was found at the beginning of an expression";
			break;
		case WTERR_TOOMANYARGS:
			sText = "Too many arguments were specified for this instruction";
			break;
		case WTERR_LBRACKETNOTFIRST:
			sText = "A left-bracket ( [ ) can only be the first character of an expression";
			break;
		case WTERR_EXTRARBRACKET:
			sText = "A right-bracket ( ] ) was found with no left-bracket ( [ )";
			break;
		case WTERR_TRASHAFTERRBRACKET:
			sText = "Extra text was found after a right-bracket";
			break;
		case WTERR_INVALIDIF:
			sText = "The expression following an IF statement could not be evaluated";
			break;
		case WTERR_IFWITHOUTENDIF:
			sText = "An IF statement has no corresponding ENDIF statement";
			break;

		// warnings (does not prevent assembly)
		case WTWARN_NOWARN:
			sText = "No warning occurred";
			break;
		case WTWARN_ENDBEFOREEOF:
			sText = "An END statement was processed before the end of the file";
			break;
		case WTWARN_DEFINASM:
			sText = "A DEF statement was found while doing a non-meta assembly";
			break;
		case WTWARN_FIELDLENGTHDISCREPANCY:
			sText = "A field argument was not the same size as the definition";
			break;
		case WTWARN_MICROWORDLENGTH:
			sText = "The microcode definition specified does not match the declared word size";
			break;
		case WTWARN_COMMAATENDOFDEF:
			sText = "A lone comma was found at the end of this line and was ignored";
			break;
		case WTWARN_NOBITLENGTH:
			sText = "No bit length was specified; defaulting to 1";
			break;
		case WTWARN_FORMDISCREPANCY:
			sText = "The object code format does not match the specified word length";
			break;
		case WTWARN_INVALIDLISTOPTION:
			sText = "An invalid option to the LIST/NOLIST command was found";
			break;
		case WTWARN_CANNOTSKIP:
			sText = "A number of arguments to skip was less than the current field index";
			break;
		case WTWARN_NOTENOUGHARGS:
			sText = "The number of arguments in the opcode call does not match the number in the definition (defaults will be used)";
			break;
		default:
			sText = "(no text associated with this error!)";
			break;
	}
	return sText;
}

void CWinTim32View::OnOutputBinaryData() 
// Outputs the assembled data in a LIST format
{
	MView result;
	CRichEditCtrl *re;

	if (IsMasterView() == MVIEW_SLAVE)
	{
		m_MasterView->SendMessage(WM_COMMAND,ID_OUTPUT_BINARYDATA,0);
		return;
	}

	re = ViewOf(GetDocument()->GetTitle() + " - TIM Output Listing");
	if (re != NULL)
	{
		re->SetSel(0,-1);
		re->Clear();
		DumpByteArray(&m_BinaryData,&m_SourceRef,0,m_SourceRef.GetUpperBound(),re);
		re->SetModify(FALSE);
		re->GetParent()->SetWindowPos(&wndTop,0,0,0,0,SWP_NOSIZE | SWP_NOMOVE);
	} else
	{
		result = MasterView();
		if (result == MVIEW_MASTER)
		{
			theApp.m_pViewCaught->GetDocument()->SetTitle(GetDocument()->GetTitle() + " - TIM Output Listing");
			DumpByteArray(&m_BinaryData,&m_SourceRef,0,m_SourceRef.GetUpperBound(),theApp.m_pRichEditCaught);
			theApp.m_pRichEditCaught->SetModify(FALSE);
		}
	}
}

void CWinTim32View::OnViewAsText() 
{
	m_FileType = PlainText;
	CheckFileType();
	OnViewRefresh();
}

void CWinTim32View::OnOutputLocalSymbolTable() 
{
	// There is no longer any local symbol table

	/*
	MView result;
	CRichEditCtrl *re;

	if (IsMasterView() == MVIEW_SLAVE)
	{
		m_MasterView->SendMessage(WM_COMMAND,ID_OUTPUT_LOCALSYMBOLTABLE,0);
		return;
	}

	re = ViewOf(GetDocument()->GetTitle() + " - Local Symbol Table");
	if (re != NULL)
	{
		re->SetSel(0,-1);
		re->Clear();
		if (m_SymbolTable.IsEmpty())
			DumpSymbolTable(&g_SymbolTable,0,re);
		else
			DumpSymbolTable(&m_SymbolTable,g_SymbolTable.GetSize(),re);
		re->SetModify(FALSE);
		re->GetParent()->SetWindowPos(&wndTop,0,0,0,0,SWP_NOSIZE | SWP_NOMOVE);
	} else
	{
		result = MasterView();
		if (result == MVIEW_MASTER)
		{
			theApp.m_pRichEditCaught->ReplaceSel(CString("Local symbol table:  ") + GetDocument()->GetTitle() + "\r\n\r\n");
			theApp.m_pViewCaught->GetDocument()->SetTitle(GetDocument()->GetTitle() + " - Local Symbol Table");
			if (m_SymbolTable.IsEmpty())
				DumpSymbolTable(&g_SymbolTable,0,theApp.m_pRichEditCaught);
			else
				DumpSymbolTable(&m_SymbolTable,g_SymbolTable.GetSize(),theApp.m_pRichEditCaught);
			theApp.m_pRichEditCaught->SetModify(FALSE);
		}
	}
	*/
}

void CWinTim32View::OnOutputCompleteSymbolTable() 
{
	MView result;
	CRichEditCtrl *re;

	if (IsMasterView() == MVIEW_SLAVE)
	{
		m_MasterView->SendMessage(WM_COMMAND,ID_OUTPUT_COMPLETESYMBOLTABLE,0);
		return;
	}

	re = ViewOf(GetDocument()->GetTitle() + " - Global Symbol Table");
	if (re != NULL)
	{
		re->SetSel(0,-1);
		re->Clear();
		re->ReplaceSel(CString("Global symbol table:  ") + GetDocument()->GetTitle() + "\r\n\r\n");
		if (m_SymbolTable.IsEmpty())
			DumpSymbolTable(&g_SymbolTable,re);
		else
			DumpSymbolTable(&m_SymbolTable,re);
		re->SetModify(FALSE);
		re->GetParent()->SetWindowPos(&wndTop,0,0,0,0,SWP_NOSIZE | SWP_NOMOVE);
	} else
	{
		result = MasterView();
		if (result == MVIEW_MASTER)
		{
			theApp.m_pRichEditCaught->ReplaceSel(CString("Global symbol table:  ") + GetDocument()->GetTitle() + "\r\n\r\n");
			theApp.m_pViewCaught->GetDocument()->SetTitle(GetDocument()->GetTitle() + " - Global Symbol Table");
			if (m_SymbolTable.IsEmpty())
				DumpSymbolTable(&g_SymbolTable,theApp.m_pRichEditCaught);
			else
				DumpSymbolTable(&m_SymbolTable,theApp.m_pRichEditCaught);
			theApp.m_pRichEditCaught->SetModify(FALSE);
		}
	}
}

void CWinTim32View::OnOutputAsMIF() 
// Outputs the assembled data in a MIF-recognizable format
{
	MView result;
	CRichEditCtrl *re;

	if (IsMasterView() == MVIEW_SLAVE)
	{
		m_MasterView->SendMessage(WM_COMMAND,ID_OUTPUT_ASSEMBLEDBINARYDATAMIFFORMAT,0);
		return;
	}

	re = ViewOf(GetDocument()->GetTitle() + " - Machine Instruction Format");
	if (re != NULL)
	{
		re->SetSel(0,-1);
		re->Clear();
		DumpByteArray(&m_BinaryData,&m_SourceRef,0,m_SourceRef.GetUpperBound(),re,TRUE);
		re->SetModify(FALSE);
		re->GetParent()->SetWindowPos(&wndTop,0,0,0,0,SWP_NOSIZE | SWP_NOMOVE);
	} else
	{
		result = MasterView();
		if (result == MVIEW_MASTER)
		{
			theApp.m_pViewCaught->GetDocument()->SetTitle(GetDocument()->GetTitle() + " - Machine Instruction Format");
			DumpByteArray(&m_BinaryData,&m_SourceRef,0,m_SourceRef.GetUpperBound(),theApp.m_pRichEditCaught,TRUE);
			theApp.m_pRichEditCaught->SetModify(FALSE);
		}
	}
}

MView CWinTim32View::IsMasterView()
// Determines if we are a master or slave view
{
	if (m_MasterView != NULL)
	{
		if (!IsWindow(m_MasterView->GetSafeHwnd()))
		{
			// If the master doesn't exist any longer, that's a problem
			theApp.Warning("The master view for this output is no longer open");
			return MVIEW_ERROR;
		} else
		{
			// We are a slave view to an assembly file, so use that instead
			return MVIEW_SLAVE;
		}
	}

	return MVIEW_MASTER;
}

MView CWinTim32View::MasterView()
// Determines if we are a master or slave view, and opens a new slave window
// if we are the master view.
{
	if (m_MasterView != NULL)
	{
		if (!IsWindow(m_MasterView->GetSafeHwnd()))
		{
			// If the master doesn't exist any longer, that's a problem
			theApp.Warning("The master view for this output is no longer open");
			return MVIEW_ERROR;
		} else
		{
			// We are a slave view to an assembly file, so use that instead
			return MVIEW_SLAVE;
		}
	}

	// Open a new slave window to this view
	theApp.m_bCatchNextView = TRUE;
	theApp.m_MasterView = this;
	AfxGetMainWnd()->SendMessage(WM_COMMAND,ID_FILE_NEW,0);
	
	((CWinTim32View *) theApp.m_pViewCaught)->m_FileType = PlainText;
	theApp.m_pViewCaught->SendMessage(WM_COMMAND,ID_VIEW_ASTEXT,0);
	return MVIEW_MASTER;
}

void CWinTim32View::OnOutputDefinitionTable() 
// Outputs the definition file
{
	MView result;
	CRichEditCtrl *re;

	if (IsMasterView() == MVIEW_SLAVE)
	{
		m_MasterView->SendMessage(WM_COMMAND,ID_OUTPUT_DEFINITIONTABLE,0);
		return;
	}

	re = ViewOf(GetDocument()->GetTitle() + " - Definition Table");
	if (re != NULL)
	{
		re->SetSel(0,-1);
		re->Clear();
		DumpDefinitionTable(re);
		re->SetModify(FALSE);
		re->GetParent()->SetWindowPos(&wndTop,0,0,0,0,SWP_NOSIZE | SWP_NOMOVE);
	} else
	{
		result = MasterView();
		if (result == MVIEW_MASTER)
		{
			theApp.m_pViewCaught->GetDocument()->SetTitle(GetDocument()->GetTitle() + " - Definition Table");
			DumpDefinitionTable(theApp.m_pRichEditCaught);
			theApp.m_pRichEditCaught->SetModify(FALSE);
		}
	}
}

void CWinTim32View::OnMButtonDown(UINT nFlags, CPoint point) 
{
	HCURSOR hCursor;
	CScrollBar *pBar;
	int iHorizBar, iVertBar;
	CRect cWndRect;

	ClientToScreen(&point);
	m_OriginalPoint = point;

	if (!GetScrollInfo(SB_HORZ,&m_HScrollInfo)) return;
	if (!GetScrollInfo(SB_VERT,&m_VScrollInfo)) return;

	hCursor = theApp.LoadStandardCursor(IDC_SIZEALL);
	m_hOldCursor = SetCursor(hCursor);

	m_MMScroll = TRUE;

	pBar = GetScrollBarCtrl(SB_HORZ);
	if (pBar != NULL)
		pBar->GetWindowRect(&cWndRect);
	else
		GetWindowRect(&cWndRect);
	iHorizBar = cWndRect.right - cWndRect.left;

	pBar = GetScrollBarCtrl(SB_VERT);
	if (pBar != NULL)
		pBar->GetWindowRect(&cWndRect);
	else
		GetWindowRect(&cWndRect);
	iVertBar = cWndRect.bottom - cWndRect.top;

	m_iMoveX = m_OrigScrollHoriz = GetScrollPos(SB_HORZ);
	m_iMoveY = m_OrigScrollVert = GetScrollPos(SB_VERT);

	m_RatioX = (float) (m_HScrollInfo.nMax - m_HScrollInfo.nMin) / (float) iHorizBar;
	m_RatioY = (float) (m_VScrollInfo.nMax - m_VScrollInfo.nMin) / (float) iVertBar;

	SetCapture();

	CRichEditView::OnMButtonDown(nFlags, point);
}

void CWinTim32View::OnMButtonUp(UINT nFlags, CPoint point) 
{
	if (m_MMScroll)
	{
		SendMessage(WM_VSCROLL,SB_THUMBPOSITION | (m_iMoveY << 16),NULL);
		SendMessage(WM_HSCROLL,SB_THUMBPOSITION | (m_iMoveX << 16),NULL);
		SetCursor(m_hOldCursor);
		ReleaseCapture();
		m_MMScroll = FALSE;
	}
	CRichEditView::OnMButtonUp(nFlags, point);
}

void CWinTim32View::OnMouseMove(UINT nFlags, CPoint point) 
{
	if (!m_MMScroll)
	{
		CRichEditView::OnMouseMove(nFlags, point);
		return;
	}

	ClientToScreen(&point);
	// Moving a distance of X pixels should change the position
	// of the scroll box by X times the length of the scroll window
	// divided by the difference between the nMin and nMax for
	// the scrollbar control.

	m_iMoveX = (int) ((point.x - m_OriginalPoint.x) * m_RatioX);
	m_iMoveY = (int) ((point.y - m_OriginalPoint.y) * m_RatioY);

	if (m_OrigScrollHoriz + m_iMoveX < m_HScrollInfo.nMin)
		m_iMoveX = m_HScrollInfo.nMin;
	else if (m_OrigScrollHoriz + m_iMoveX > m_HScrollInfo.nMax)
		m_iMoveX = m_HScrollInfo.nMax;
	else
		m_iMoveX = m_OrigScrollHoriz + m_iMoveX;

	if (m_OrigScrollVert + m_iMoveY < m_VScrollInfo.nMin)
		m_iMoveY = m_VScrollInfo.nMin;
	else if (m_OrigScrollVert + m_iMoveY > m_VScrollInfo.nMax)
		m_iMoveY = m_VScrollInfo.nMax;
	else
		m_iMoveY = m_OrigScrollVert + m_iMoveY;

	SendMessage(WM_VSCROLL,SB_THUMBTRACK | (m_iMoveY << 16),NULL);
	SetScrollPos(SB_VERT,m_iMoveY,TRUE);
	SendMessage(WM_HSCROLL,SB_THUMBTRACK | (m_iMoveX << 16),NULL);
	SetScrollPos(SB_HORZ,m_iMoveX,TRUE);

	m_LastPoint = point;
}

void CWinTim32View::OnContextMenu(CWnd* pWnd, CPoint point) 
{
    CMenu menu;
    VERIFY(menu.LoadMenu(IDR_EDITCONTEXT));
    CMenu* pPopup = menu.GetSubMenu(0);
    ASSERT(pPopup != NULL);

    pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, this);
}

void CWinTim32View::OnRButtonUp(UINT nFlags, CPoint point) 
{
	ClientToScreen(&point);
	OnContextMenu(this,point);	
	CRichEditView::OnRButtonUp(nFlags, point);
}

void CWinTim32View::OnEditDelete() 
{
	GetRichEditCtrl().Clear();	
}

void CWinTim32View::OnUpdateEditDelete(CCmdUI* pCmdUI) 
{
	long start,end;
	GetRichEditCtrl().GetSel(start,end);
	pCmdUI->Enable(start != end);
}

void CWinTim32View::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CRichEditView::OnLButtonUp(nFlags, point);
}

void CWinTim32View::CheckIgnoreLF(CToken &tok, TokenArray *ta, long &nLine, long &index)
{
	CToken testtok;

	if (NewLineCheck(tok,nLine,FALSE))
	{
		if (index < ta->GetUpperBound() - 1)
		{
			testtok = ta->GetAt(index+1);
			if (testtok.token.tint == WINTIM_IGNORELF)
			{
				// Completely ignore the end-of-line, but do count it as
				// a line for numbering purposes
				m_lLocalLine++;
				if (tok.token.tint != WINTIM_DCENDLINE)
					nLine++;
				index += 2;
				tok = ta->GetAt(index);
			}
		}
	}
}

void CWinTim32View::OnViewOutputMessages() 
{
	GetMainFrame()->ShowOutput();
}

CMainFrame *CWinTim32View::GetMainFrame()
{
	return ((CMainFrame *) theApp.m_pMainWnd);
}

CString CWinTim32View::GetTokenName(CToken token)
// Returns a string description of the given token
{
	CString sToken;
	unsigned short iToken;

	iToken = token.token.tint;

	switch(iToken)
	{
		// Standard keywords
		case WTKW_NULL:   sToken = "null keyword"; break;
		case WTKW_TITLE:  sToken = "keyword TITLE"; break;
		case WTKW_WIDTH:  sToken = "keyword WIDTH"; break;
		case WTKW_WORD:   sToken = "keyword WORD"; break;
		case WTKW_LINES:  sToken = "keyword LINES"; break;
		case WTKW_END:    sToken = "keyword END"; break;
		case WTKW_FORM:   sToken = "keyword FORM"; break;
		case WTKW_LIST:   sToken = "keyword LIST"; break;
		case WTKW_EJECT:  sToken = "keyword EJECT"; break;
		case WTKW_ELSE:	  sToken = "keyword ELSE"; break;
		case WTKW_ENDIF:  sToken = "keyword ENDIF"; break;
		case WTKW_EXITM:  sToken = "keyword EXITM"; break;
		case WTKW_EXTRN:  sToken = "keyword EXTRN"; break;
		case WTKW_FF:	  sToken = "keyword FF"; break;
		case WTKW_FORMAT: sToken = "keyword FORMAT.INST"; break;
		case WTKW_HEAD:	  sToken = "keyword HEAD"; break;
		case WTKW_IF:	  sToken = "keyword IF"; break;
		case WTKW_IFC:	  sToken = "keyword IFC"; break;
		case WTKW_IFD:	  sToken = "keyword IFD"; break;
		case WTKW_IFNC:	  sToken = "keyword IFNC"; break;
		case WTKW_IFND:	  sToken = "keyword IFND"; break;
		case WTKW_INCLUDE: sToken = "keyword INCLUDE"; break;
		case WTKW_LOCAL:  sToken = "keyword LOCAL"; break;
		case WTKW_MAP:    sToken = "keyword MAP"; break;
		case WTKW_NOLIST: sToken = "keyword NOLIST"; break;
		case WTKW_PUBLIC: sToken = "keyword PUBLIC"; break;
		case WTKW_REL:    sToken = "keyword .REL"; break;
		case WTKW_SPACE:  sToken = "keyword SPACE"; break;
		case WTKW_TAB:    sToken = "keyword TAB"; break;
		case WTKW_TITLE2: sToken = "keyword TITLE2"; break;

		// WinTim32's pseuso-ops
		case WTPO_NULL:    sToken = "pseudo-op NULL"; break;
		case WTPO_EQU:     sToken = "pseudo-op EQU"; break;
		case WTPO_SUB:     sToken = "pseudo-op SUB"; break;
		case WTPO_DEF:     sToken = "pseudo-op DEF"; break;
		case WTPO_MACRO:   sToken = "pseudo-op MACRO"; break;
		case WTPO_ENDM:    sToken = "pseudo-op ENDM"; break;
		case WTPO_ORG:     sToken = "pseudo-op ORG"; break;
		case WTPO_SET:     sToken = "pseudo-op SET"; break;
		case WTPO_DATA:    sToken = "pseudo-op DATA"; break;
		case WTPO_DUP:     sToken = "pseudo-op DUP"; break;
		case WTPO_DCARE:   sToken = "pseudo-op DCARE"; break;
		case WTPO_AND:     sToken = "pseudo-op _AND_"; break;
		case WTPO_OR:      sToken = "pseudo-op _OR_"; break;
		case WTPO_XOR:     sToken = "pseudo-op _XOR_"; break;
		case WTPO_EQ:      sToken = "pseudo-op _EQ_"; break;
		case WTPO_NE:      sToken = "pseudo-op _NE_"; break;
		case WTPO_GT:      sToken = "pseudo-op _GT_"; break;
		case WTPO_GE:      sToken = "pseudo-op _GE_"; break;
		case WTPO_LT:      sToken = "pseudo-op _LT_"; break;
		case WTPO_LE:      sToken = "pseudo-op _LE_"; break;
		case WTPO_SHR:     sToken = "pseudo-op _SHR_"; break;
		case WTPO_SHL:     sToken = "pseudo-op _SHL_"; break;
		case WTPO_RES:     sToken = "pseudo-op RES"; break;

		// WinTim32's numeric codes
		case WTNM_NULL:    sToken = "numeric NULL"; break;
		case WTNM_BINARY:  sToken = "numeric B# (binary)"; break;
		case WTNM_OCTAL:   sToken = "numeric Q# (octal)"; break;
		case WTNM_DECIM:   sToken = "numeric D# (decimal)"; break;
		case WTNM_HEX:     sToken = "numeric H# (hexadecimal)"; break;
		case WTNM_VAR:     sToken = "variable designator (V)"; break;
		case WTNM_DCARE:   sToken = "don't-care designator (X)"; break;

		// Single-character "keywords"
		case WTCH_NULL:     sToken = "char NULL"; break;
		case WTCH_QUOTE:    sToken = "quote character ( ' )"; break;
		case WTCH_DQUOTE:   sToken = "double-quote character ( \" )"; break;
		case WTCH_LABEL:    sToken = "label character ( : )"; break;
		case WTCH_COMMA:    sToken = "comma character ( , )"; break;
		case WTCH_PLUS:     sToken = "plus character ( + )"; break;
		case WTCH_MINUS:    sToken = "minus character ( - )"; break;
		case WTCH_ASTERISK: sToken = "asterisk character ( * )"; break;
		case WTCH_SLASH:    sToken = "slash character ( / )"; break;
		case WTCH_LBRACKET: sToken = "left-bracket character ( [ )"; break;
		case WTCH_RBRACKET: sToken = "right-bracket character ( ] )"; break;
		case WTCH_PERCENT:  sToken = "percent character ( % )"; break;
		case WTCH_LPAREN:   sToken = "left-parenthesis character ( ( )"; break;
		case WTCH_RPAREN:   sToken = "right-parenthesis character ( ) )"; break;
		case WTCH_LESS:     sToken = "less-than character ( < )"; break;
		case WTCH_GREATER:  sToken = "greater-than character ( > )"; break;

		// Anything that isn't a token
		case WINTIM_STRING: sToken = "internal start-of-string token"; break;

		// Miscellaneous pseudo-tokens
		case WINTIM_ENDSTRING:  sToken = "internal end-of-string token"; break;
		case WINTIM_WHITESPACE: sToken = "whitespace"; break;
		case WINTIM_ENDPROGRAM: sToken = "end-of-program token"; break;
		case WINTIM_MACRO:      sToken = "internal macro designator"; break;
		case WINTIM_ENDLINE:    sToken = "end-of-line token"; break;
		case WINTIM_DCENDLINE:  sToken = "no-increment end-of-line token"; break;

		default:
			if ((iToken >= WINTIM_MACROARG1) && (iToken <= WINTIM_MACROARG1 + 254))
			{
				sToken.Format("macro argument %d",iToken - WINTIM_MACROARG1 + 1);
			} else if (iToken >= WINTIM_USEROP)
			{
				if (iToken - WINTIM_USEROP < g_DefArray.GetSize())
					sToken.Format("user-defined opcode %s",g_DefArray.GetAt(iToken - WINTIM_USEROP).sOpcode);
				else
					sToken.Format("illegal user-defined opcode index %d",iToken - WINTIM_USEROP);
			} else
			{
				sToken.Format("unknown token 0x%.4X [%c%c]",iToken,token.token.tchar[0],token.token.tchar[1]);
			}
	}
	return sToken;
}

CRichEditCtrl * CWinTim32View::ViewOf(CString sCaption)
// Returns the rich edit control of the corresponding view, if any
{
	CWnd *pWnd;
	CString sText;

	if (GetParent() == NULL)
		return NULL;

	pWnd = GetParent()->GetWindow(GW_HWNDFIRST);

	while (pWnd->GetNextWindow(GW_HWNDPREV) != NULL)
		pWnd = pWnd->GetNextWindow(GW_HWNDPREV);

	while (pWnd != NULL)
	{
		pWnd->GetWindowText(sText);
		if (sText == sCaption)
		{
			if (pWnd->GetWindow(GW_CHILD) != NULL)
				return (CRichEditCtrl *) (pWnd->GetWindow(GW_CHILD));
			else
				return NULL;
		}
		pWnd = pWnd->GetWindow(GW_HWNDNEXT); 
	}

	return NULL;
}

BOOL CWinTim32View::ProcessGenericToken(CToken tok, TokenArray *(&ta), long &index, long &nLine, BOOL &TerminateProcessing)
// Processes generic tokens such as TITLE, LIST, etc.
// Specifically not included are:
// - EQU, DEF, and labels
// - Strings, whitespace, and end-of-line tokens
// - User-defined opcodes
{
	long lArg;
	long iTemp;
	CString sTok;
	DWORD flags;

	switch(tok.token.tint)
	{
		// WinTim32's keywords
		case WTKW_NULL:
			break;
		case WTKW_IF:
			m_bIfConditional = TRUE;
			break;
		case WTKW_ENDIF:
			m_bShouldAssemble = TRUE;
			m_bIfConditional = FALSE;
			m_bInIF = FALSE;
			break;
		case WTKW_ELSE:
			if (m_bInIF)
				m_bShouldAssemble = !m_bShouldAssemble;
			else
			{
				// ELSE without IF
				AddError(WTERR_ELSEWITHOUTIF,nLine,index);
				TerminateProcessing = TRUE;
			}
			break;
		case WTKW_TITLE:
			// The next token after a title should be the entire title
			tok = ta->GetAt(index+1);
			if (NewLineCheck(tok,nLine,FALSE) == FALSE)
			{
				// Only add the title if it isn't null
				m_Definitions.sTitle = TokenString(ta,index+1);
				lArg = m_Definitions.sTitle.Find(',');
				if ((lArg != -1) && (strlen(m_Definitions.sTitle) > (unsigned) lArg+1))
				{
					// Use TIM's old TITLE,TITLE2 format
					m_Definitions.sTitle2 = m_Definitions.sTitle.Mid(lArg+1);
					m_Definitions.sTitle2.TrimLeft();
					m_Definitions.sTitle = m_Definitions.sTitle.Left(lArg);
				}
				index = SkipString(nLine,index+1,ta); // skip over the title itself
			}
			break;
		case WTKW_TITLE2:
			// The next token after a title should be the entire title2
			tok = ta->GetAt(index+1);
			if (NewLineCheck(tok,nLine,FALSE) == FALSE)
			{
				// Only add the title if it isn't null
				m_Definitions.sTitle2 = TokenString(ta,index+1);
				index = SkipString(nLine,index+1,ta); // skip over the title itself
			}
			break;
		case WTKW_HEAD:
			// The next token should be a string header
			tok = ta->GetAt(index+1);
			if (TokenIsStr(nLine,index+1,sTok,ta,FALSE))
			{
				m_Definitions.sHeader = sTok;
				index = SkipString(nLine,index+1,ta); // Skip the heading
			}
			break;
		case WTKW_WIDTH:
			// The next token should be the width of a printed page (in characters)
			// If the next token isn't a string value, there's an error
			if (TokenIsNum(nLine,index+1,lArg,ta))
			{
				m_Definitions.iPageWidth = lArg;
				index = SkipString(nLine,index+1,ta);
			}
			break;
		case WTKW_WORD:
			// The next token should be the width of one instruction (in bits)
			// If the next token isn't a string value, there's an error
			if (TokenIsNum(nLine,index+1,lArg,ta))
			{
				m_Definitions.iWordSize = lArg;
				index = SkipString(nLine,index+1,ta);
			}
			break;
		case WTKW_LINES:
			// The next token should be the length of a printed page (in lines)
			// If the next token isn't a string value, there's an error
			if (TokenIsNum(nLine,index+1,lArg,ta))
			{
				m_Definitions.iPageLines = lArg;
				index = SkipString(nLine,index+1,ta);
			}
			break;
		case WTKW_END:
			// This signifies termination of assembly.  Generates a warning if it
			// isn't the last significant token.
			iTemp = index;
			TerminateProcessing = TRUE;
			while (index + 1 < ta->GetUpperBound())
			{
				index++;
				tok = ta->GetAt(index+1);
				switch (tok.token.tint)
				{
					case WINTIM_ENDLINE:
					case WINTIM_DCENDLINE:
					case WINTIM_WHITESPACE:
						break;
					default:
						AddError(WTWARN_ENDBEFOREEOF,nLine,iTemp);
						TerminateProcessing = TRUE;
						index = ta->GetUpperBound();
				}
			}
			// TerminateProcessing will cause all processing to cease
			// Even if in the middle of a macro
			break;
		case WTKW_FORM:
			// The following string should be an object code format string
			// such as B4444B4444B4444B4444B4444B4444B4444B4444B
			tok = ta->GetAt(index+1);
			if (TokenIsStr(nLine,index+1,sTok,ta,FALSE))
			{
				m_Definitions.sObjectCodeFormat = sTok;
				index = SkipString(nLine,index+1, ta);
				// Check the length of the format string against the
				// defined value of WORD
				lArg = 0;
				for (iTemp = 0; (unsigned) iTemp < strlen(sTok); iTemp++)
				{
					if ((sTok.GetAt(iTemp) >= '1') && (sTok.GetAt(iTemp) <= '5'))
						lArg += (sTok.GetAt(iTemp) - '0');
				}
				if (lArg != m_Definitions.iWordSize)
				{
					sError.Format("- WORD is %d bits, and the string \"%s\" specifies a total of %d bits",
						m_Definitions.iWordSize,sTok,lArg);
					AddError(WTWARN_FORMDISCREPANCY,nLine,index,sError);
				}
			}
			break;
		case WTKW_LIST:
		case WTKW_NOLIST:
			// The LIST keyword takes a number of options such as F, W, and B after it
			// Or it can have no options at all
			// The NOLIST keyword turns off parameters the same way LIST turns them on

			flags = 0;
			iTemp = tok.token.tint;
			if (!(TokenIsStr(nLine,index+1,sTok,ta,FALSE)))
			{
				// LIST alone is equivalent to "LIST S"
				flags = WTLO_LISTSOURCE;
			}

			while (TokenIsStr(nLine,index+1,sTok,ta,FALSE))
			{
				if (sTok != "")
				{
					switch(toupper(sTok.GetAt(0)))
					{
						case 'A':
							flags |= WTLO_ADDRESSEVERYLINE;
							break;
						case 'B':
							flags |= WTLO_OBJECTCODE;
							break;
						case 'E':
							flags |= WTLO_ERRORSATCONSOLE;
							break;
						case 'F':
							flags |= WTLO_OBJECTCODEATLEFT;
							break;
						case 'I':
							flags |= WTLO_LISTALLCONDITIONAL;
							break;
						case 'M':
							flags |= WTLO_LISTMACROSTATEMENTS;
							break;
						case 'Q':
							flags |= WTLO_ADDRESSESINOCTAL;
							break;
						case 'R':
							flags |= WTLO_REFERENCEFILE;
							break;
						case 'S':
							flags |= WTLO_LISTSOURCE;
							break;
						case 'T':
							flags |= WTLO_LISTSYMBOLS;
							break;
						case 'W':
							flags |= WTLO_LINEWRAP;
							break;
						case 'X':
							flags |= WTLO_CROSSREFERENCE;
							break;
						default:
							sError.Format(": '%c' (valid options are A, B, E, F, I, M, Q, R, S, T, W, and X)",sTok.GetAt(0));
							AddError(WTWARN_INVALIDLISTOPTION,nLine,index,sError);
					}
				}
				index = SkipString(nLine,index+1, ta);
				index++;
				tok = ta->GetAt(index);
				if (tok.token.tint != WTCH_COMMA)
				{
					index--;
					break;
				}
			}
			if (iTemp == WTKW_LIST)
			{
				// Turn the options on
				m_Definitions.listOptions.dwFlags |= flags;
			} else
			{
				// Turn the options off
				m_Definitions.listOptions.dwFlags &= flags;
			}
			break;
		// WinTim32's pseudo-ops
		case WTPO_SUB:
			// SUB variables are already treated as macros in the macro array,
			// so ignore them here
			index = SkipRestOfLine(nLine, index, ta, FALSE);
			index--;  // Process the end-of-line token
			break;
		case WTPO_MACRO:
			// Since macros are already in the macro table, we simply skip them here.
			while (tok.token.tint != WTPO_ENDM)
			{
				index++;
				tok = ta->GetAt(index);
				if (NewLineCheck(tok,nLine,FALSE) && (ta == &m_TokenArray))
				{
					m_lLocalLine++;
					if (tok.token.tint != WINTIM_DCENDLINE)
						nLine++;
				}
			}
			break;
		case WTPO_ENDM:
			// Ignore ENDM
			break;
		// WinTim32's numeric codes (B#, H#, etc)
		case WTNM_BINARY:
			break;
		case WTNM_OCTAL:
			break;
		case WTNM_DECIM:
			break;
		case WTNM_HEX:
			break;
		// Single-character "keywords"
		case WTCH_QUOTE:
			break;
		case WTCH_DQUOTE:
			break;
		case WTCH_COMMA:
			break;
		case WTCH_PLUS:
			break;
		case WTCH_MINUS:
			break;
		case WTCH_ASTERISK:
			break;
		case WTCH_SLASH:
			break;
		case WTCH_LBRACKET:
			break;
		case WTCH_RBRACKET:
			break;
		case WTCH_PERCENT:
			break;
		// Miscellaneous pseudo-tokens
		default: // Not a generic token
			return FALSE; // Could not process
	}
	return TRUE;  // Processed a generic token
}

void CWinTim32View::OnEditGotoLine() 
// Jumps to a specific line in the rich edit control
{
	long lLine, result;
	CGotoDialog dlgGoto;
	CRichEditCtrl *re;

	re = &(GetRichEditCtrl());
	dlgGoto.m_iLineNum = re->LineFromChar(re->LineIndex(-1)) + 1;
	result = dlgGoto.DoModal();
	if (result == IDOK)
	{
		UpdateData(TRUE);
		lLine = dlgGoto.m_iLineNum;
		if (lLine < 1)
			lLine = 1;
		if (lLine > re->GetLineCount())
			lLine = re->GetLineCount();

		lLine--;

		re->SetSel(re->LineIndex(lLine),re->LineIndex(lLine));
	}
}

CString CWinTim32View::FormatBits(CByteArray *ba, long &iByteIndex, long iByteMax)
// Formats a string accoring to the m_Definitions.sObjectCodeFormat
// For example:  11B33B4444B133333 = 2-bit binary field, blank, two octal digits,
//                                   blank, four hex digits, blank, binary, 5 octal
{
	CString sText;
	int i, j, iBit;
	char c, cOut;
	SHORT sTwoBytes;

	sText = "";
	iBit = 0;

	for (i = 0; (unsigned) i < strlen(m_Definitions.sObjectCodeFormat); i++)
	{
		c = toupper(m_Definitions.sObjectCodeFormat.GetAt(i));
		if (c == 'B')
		{
			sText += ' ';
			continue;
		}
		// c should be in the range of '1' to '5'
		if ((c < '1') || (c > '5'))
		{
			// If it's not valid, just ignore it completely
			continue;
		}

		if (iByteIndex > ba->GetUpperBound())
		{
			// Something stupid happened
			break;
		}
		// Print c number of bits as one character
		// Get two bytes
		sTwoBytes = (ba->GetAt(iByteIndex) << 8);
		if (iByteIndex < ba->GetUpperBound())
			sTwoBytes += (ba->GetAt(iByteIndex+1));
		// Put each bit into an output character
		cOut = '\0';
		for (j = 0; j < (c - '0'); j++)
		{
			cOut |= (((sTwoBytes & (1 << (15 - iBit))) > 1) << ((c - '0') - j - 1));
			iBit++;
		}
		// Make that character (char 0-31) a readable one
		if (cOut < 10)
			cOut += '0';
		else
			cOut += ('A' - 10);

		// Add that character to our string
		sText += cOut;

		// Roll-over the bit sequence
		if (iBit > 7)
		{
			iBit -= 8;
			iByteIndex++;
		}

		if ((iByteIndex >= iByteMax) || (iByteIndex > ba->GetUpperBound()))
		{
			// The object format string is too large; pad with " " chars
			while ((unsigned) i < strlen(m_Definitions.sObjectCodeFormat) - 1)
			{
				sText += " ";
				i++;
			}
			break;
		}
	}
	return sText;
}

long CWinTim32View::GetMacroNum()
// Returns the index to the macro above the current
// one we are currently processing in the stack
{
	long lMacro;
	PeekTokenArray(lMacro, 1);
	return lMacro;
}

BOOL CWinTim32View::HasPrecedence(Op NextOp, long index, TokenArray *ta, long &nLine)
// Checks the token at ta[index] against the operator precedence
// definitions and returns TRUE if it is an operator and has
// greater precedence
{
	CToken tok;
	BOOL bFinished = FALSE;

	if (index > ta->GetUpperBound())
		return FALSE;

	if (NextOp == None)
		return FALSE;  // No operator has precedence over a direct operation

	tok = ta->GetAt(index);

	while (!bFinished)
	{
		switch(tok.token.tint)
		{
			// Operand modifiers (highest precedence)
			case WTNM_VAR:
			case WTNM_DCARE:
			case WTCH_LESS:
			case WTCH_PERCENT:
			case WTCH_LABEL:
				return TRUE;  // There are no actual "Op" type with any higher precedence
			// Multiplication
			case WTCH_ASTERISK:
				switch (NextOp)
				{
					case Multiply:
						return FALSE;  // Only another multiply is performed before multiply
					default:
						return TRUE;
				}
				break;
			// Division
			case WTCH_SLASH:
				switch (NextOp)
				{
					case Multiply:
					case Divide:
						return FALSE;
					default:
						return TRUE;
				}
				break;
			// Addition, Subtraction, Logical operations, and Shifts
			case WTCH_PLUS:
			case WTCH_MINUS:
			case WTPO_AND:
			case WTPO_OR:
			case WTPO_XOR:
			case WTPO_SHR:
			case WTPO_SHL:
				switch (NextOp)
				{
					case Multiply:
					case Divide:
					case Add:
					case Subtract:
					case Logical_And:
					case Logical_Or:
					case Logical_Xor:
					case Logical_Shift_Left:
					case Logical_Shift_Right:
						return FALSE;
					default:
						return TRUE;
				}
			// Relational Operators
			case WTPO_EQ:
			case WTPO_NE:
			case WTPO_GT:
			case WTPO_GE:
			case WTPO_LT:
			case WTPO_LE:
				return FALSE;  // Nothing has precedence over these;
			// Newline (and possible continuation)
			case WINTIM_ENDLINE:
			case WINTIM_DCENDLINE:
				if (index < ta->GetSize())
				{
					tok = ta->GetAt(index+1);
					if (ta->GetAt(index+1).token.tint == WTCH_SLASH)
					{
						// We should continue processing this line!
						// (don't increment nLine; we aren't actually "moving"
						// the index in this procedure, just checking)
						bFinished = FALSE;  // parse the switch() statement again
						break;
					} else
						return FALSE; // Newlines have no precedence
				}
				break;
			default: // Something else?  Better say "no"
				return FALSE;
		}
	}
	return FALSE; // Something went haywire if we got here
}

CString CWinTim32View::GetOpName(Op Operator)
// Returns a string describing this operation
{
	switch (Operator)
	{
		case None:
			return "(no operator)";
		case Add:
			return "addition";
		case Subtract:
			return "subtraction";
		case Multiply:
			return "multiplication";
		case Divide:
			return "division";
		case Logical_And:
			return "logical AND";
		case Logical_Or:
			return "logical OR";
		case Logical_Xor:
			return "logical XOR";
		case If_Equal:
			return "if equal";
		case If_Not_Equal:
			return "if not equal";
		case If_Greater_Than:
			return "if greater than";
		case If_Greater_Than_Or_Equal:
			return "if greater than or equal";
		case If_Less_Than:
			return "if less than";
		case If_Less_Than_Or_Equal:
			return "if less than or equal";
		case Logical_Shift_Right:
			return "logical shift right";
		case Logical_Shift_Left:
			return "logical shift left";
	}
	return "(unknown operand)";
}		  

void CWinTim32View::CopySymbolArray(SymbolArray *sa1, SymbolArray *sa2)
// Copies map "sa1" to map "sa2"
{
	POSITION pos;
	CString key;

	pos = sa1->GetStartPosition();
	while (pos != NULL)
	{
		sa1->GetNextAssoc(pos,key,m_Symbol);
		sa2->SetAt(key,m_Symbol);
	}
}

BOOL CWinTim32View::NewLineCheck(CToken tok, long &line, BOOL increment)
{
	if (tok.token.tint >> 1 == WINTIM_ENDLINE >> 1)
	{
		// if the token is  WINTIM_ENDLINE or WINTIM_DCENDLINE,
		// increment the local line cound
		if (increment)
		{
			m_lLocalLine++;
			if (tok.token.tint == WINTIM_ENDLINE)
			{
				// But only if it is a bona fide WINTIM_ENDLINE
				// do we increment the "real" line count
				line++;
			}
		}
		return TRUE;
	} else
	{
		return FALSE;
	}
}

void CWinTim32View::OnFileSaveAs() 
{
	CString sName;
	int iResponse;

	sName = GetSavingName();

	CFileDialog dlg(FALSE,NULL,sName);

	iResponse = dlg.DoModal();

	if (iResponse == IDOK)
	{
		sName.MakeUpper();
		sName = sName.Right(3);

		if (sName == "MIF" || sName == "LST" || sName == "SYM" || sName == "DEF")
			GetDocument()->DoSave(dlg.GetPathName(),FALSE);
		else
			GetDocument()->DoSave(dlg.GetPathName(),TRUE);
	}
}

void CWinTim32View::OnFileSave() 
{
	CString sName;

	sName = GetSavingName();

    DWORD dwAttrib = GetFileAttributes(sName);
    if (dwAttrib & FILE_ATTRIBUTE_READONLY)
    {
        // we do not have read-write access or the file does not (now) exist
		OnFileSaveAs();
    }
    else
    {
		GetDocument()->DoSave(sName,FALSE);
	}
}

CString CWinTim32View::GetSavingName()
{
	CString sWindowTitle;
	CString sExtension;
	CString sFileName;
	int i;

	sExtension = "";
	sWindowTitle = GetDocument()->GetTitle();

	if (sWindowTitle.Find("Machine Instruction Format") != -1)
		sExtension = "mif";
	else if (sWindowTitle.Find("TIM Output Listing") != -1)
		sExtension = "lst";
	else if (sWindowTitle.Find("Global Symbol Table") != -1)
		sExtension = "sym";
	else if (sWindowTitle.Find("Definition Table") != -1)
		sExtension = "def";
	else
		sExtension = "src";

	sFileName = sWindowTitle;
	
	i = sFileName.Find(" - ");
	if (i != -1)
	{
		sFileName = sFileName.Left(i);
	}

	i = sFileName.ReverseFind('.');
	if (i != -1)
	{
		sFileName = sFileName.Left(i);
	}

	sFileName = sFileName + CString(".") + sExtension;

	return sFileName;
}

void CWinTim32View::OnHelp() 
{
	AfxGetApp()->m_pMainWnd->SendMessage(WM_COMMAND,MYWM_GETHELP,0);
}
