// PPAsm.cpp : implementation file
//

#include "stdafx.h"
#include "WinTim32.h"
#include "PPAsm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPPAsm property page

IMPLEMENT_DYNCREATE(CPPAsm, CPropertyPage)

CPPAsm::CPPAsm() : CPropertyPage(CPPAsm::IDD)
{
	//{{AFX_DATA_INIT(CPPAsm)
	m_ErrorMax = 0;
	//}}AFX_DATA_INIT
}

CPPAsm::~CPPAsm()
{
}

void CPPAsm::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPPAsm)
	DDX_Control(pDX, IDC_INDEXISIZE, m_IndexISize);
	DDX_Control(pDX, IDC_INDEXONE, m_IndexOne);
	DDX_Text(pDX, IDC_ERRORMAX, m_ErrorMax);
	DDV_MinMaxUInt(pDX, m_ErrorMax, 10, 500);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPPAsm, CDialog)
	//{{AFX_MSG_MAP(CPPAsm)
	ON_BN_CLICKED(IDC_INDEXISIZE, OnIndexISize)
	ON_BN_CLICKED(IDC_INDEXONE, OnIndexOne)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPPAsm message handlers

void CPPAsm::OnIndexISize() 
{
	m_iAddressIndexMode = WT_INDEXBYSIZE;
}

void CPPAsm::OnIndexOne() 
{
	m_iAddressIndexMode = WT_INDEXBYONE;
}

BOOL CPPAsm::OnInitDialog() 
{
	CDialog::OnInitDialog();

	switch(m_iAddressIndexMode)
	{
		case WT_INDEXBYSIZE:
			m_IndexISize.SetCheck(1);
			m_IndexOne.SetCheck(0);
			break;
		case WT_INDEXBYONE:
			m_IndexISize.SetCheck(0);
			m_IndexOne.SetCheck(1);
			break;
		default: ;
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
