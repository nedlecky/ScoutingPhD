// WinTim32.cpp : Defines the class behaviors for the application.
//


#include "stdafx.h"
#include "WinTim32.h"
#include "PPEdit.h"
#include "PageMisc.h"
#include "PPColors.h"
#include "PPAsm.h"
#include "PPWarnings.h"

#include "MainFrm.h"
#include "ChildFrm.h"
#include "WinTim32Doc.h"
#include "WinTim32View.h"

// Some arbitrary default colors (similar to visual C++)
#define DEFAULT_BG 0xffffff
#define DEFAULT_NORM 0x000000
#define DEFAULT_LABEL 0x00ff0707 
#define DEFAULT_COMMENT 0x00077f07
#define DEFAULT_OPCODE 0x0007077f
#define DEFAULT_KEYWORD 0x00ff4747
#define DEFAULT_USERKEYWORD 0x0007077f
#define DEFAULT_STRING 0x000071e1
#define DEFAULT_FONT "System"
#define DEFAULT_FONTSIZE 100

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Definitions array for the meta assembler (only one per instance)
extern DefArray g_DefArray;

/////////////////////////////////////////////////////////////////////////////
// CWinTim32App

BEGIN_MESSAGE_MAP(CWinTim32App, CWinApp)
	//{{AFX_MSG_MAP(CWinTim32App)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWinTim32App construction

CWinTim32App::CWinTim32App()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CWinTim32App object

CWinTim32App theApp;
int activeThreadCount;
int activeViewCount;
//CRITICAL_SECTION global_CS;   // Semaphore for update thread

/////////////////////////////////////////////////////////////////////////////
// CWinTim32App initialization

BOOL CWinTim32App::InitInstance()
{
	activeThreadCount = 0;
	activeViewCount = 0;
	g_DefArray.RemoveAll();
	m_bCatchNextView = FALSE;
	m_Column = m_Line = 0;
//	InitializeCriticalSection(&global_CS);
	// Initialize OLE libraries

	if (!AfxOleInit())
	{
		AfxMessageBox(IDP_OLE_INIT_FAILED);
		return FALSE;
	}

	AfxEnableControlContainer();

    // Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("EDV Software"));

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)
	LoadRegistry();  // Load application-specific registry settings

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CMultiDocTemplate* pDocTemplate;
	pDocTemplate = new CMultiDocTemplate(
		IDR_WINTIMTYPE,
		RUNTIME_CLASS(CWinTim32Doc),
		RUNTIME_CLASS(CChildFrame), // custom MDI child frame
		RUNTIME_CLASS(CWinTim32View));
	pDocTemplate->SetContainerInfo(IDR_WINTIMTYPE_CNTR_IP);
	AddDocTemplate(pDocTemplate);

	// create main MDI Frame window
	CMainFrame* pMainFrame = new CMainFrame;
	if (!pMainFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	m_pMainWnd = pMainFrame;

	// Enable drag/drop open
	m_pMainWnd->DragAcceptFiles();

	// Enable DDE Execute open
	EnableShellOpen();
	RegisterShellFileTypes(TRUE);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
//	if (!ProcessShellCommand(cmdInfo))
//		return FALSE;

	if (m_VisibleLabelTable)
		m_LabelTableDlg.m_Dead = FALSE;
	else
		m_LabelTableDlg.m_Dead = TRUE;
	m_LabelTableDlg.Create(IDD_LABELTABLE);

	m_ThreadWaitDlg.Create(IDD_ACTIVETHREAD);
	m_ThreadWaitDlg.ShowWindow(SW_HIDE);
	// m_ThreadWaitDlg.ShowWindow(SW_SHOW);

	LoadWindowRegistry();  // Load window sizes from registry

	if (m_SaveWindowPositions)
	{
		m_LabelTableDlg.MoveWindow(m_WindowStates.pos.label.x,
		                        m_WindowStates.pos.label.y,
		                        m_WindowStates.size.label.x,
		                        m_WindowStates.size.label.y, TRUE);
		pMainFrame->MoveWindow(m_WindowStates.pos.main.x,
							   m_WindowStates.pos.main.y,
							   m_WindowStates.size.main.x,
							   m_WindowStates.size.main.y, TRUE);
	}

	// The main window has been initialized, so show and update it.
	pMainFrame->ShowWindow(m_nCmdShow);
	pMainFrame->UpdateWindow();

	pMainFrame->PrintError("WinTim32 initialized.");

	m_Syntax.InitializeHashTable();

	return TRUE;
}


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
		// No message handlers
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CWinTim32App::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CWinTim32App message handlers


void CWinTim32App::WriteRegistry()
{
	WriteProfileInt("Options","IgnoreWarnings",m_dwWarnings);
	WriteProfileInt("Options","SelectEntireWord",m_bWordSel);
	WriteProfileInt("Options","DragAndDropEdit",m_bDragDrop);
	WriteProfileInt("Options","AutoIndent",m_bAutoIndent);
	WriteProfileInt("Colors","Background",m_ViewBGColor);
	WriteProfileInt("Colors","Normal",m_ViewNormalColor);
	WriteProfileInt("Colors","Label",m_ViewLabelColor);
	WriteProfileInt("Colors","Comment",m_ViewCommentColor);
	WriteProfileInt("Colors","Opcode",m_ViewOpcodeColor);
	WriteProfileInt("Colors","Keyword",m_ViewKeywordColor);
	WriteProfileInt("Colors","UserKeyword",m_ViewUserKeywordColor);
	WriteProfileInt("Colors","String",m_ViewStringColor);
	WriteProfileString("Options","FontName",m_FontName);
	WriteProfileInt("Options","FontSize",m_FontSize);
	WriteProfileInt("Options","DynamicTabs",m_DynamicTabs);
	WriteProfileInt("Options","MinimumWhitespace",m_MinWhite);
	WriteProfileInt("Options","MaximumWhitespace",m_MaxWhite);
	WriteProfileInt("Options","SaveWindowPositions",m_SaveWindowPositions);
	WriteProfileInt("Windows","VisibleLabelTable",m_VisibleLabelTable);
	WriteProfileInt("Assembler","IndexMode",m_AddressIndexMode);
	WriteProfileInt("Assembler","ErrorMax",m_ErrorMax);
	WriteProfileInt("Windows","OutputFixed",m_OutputFixed);
	WriteProfileInt("Windows","OutputPercent",m_OutputPercent);
	WriteProfileInt("Windows","OutputType",m_OutputType); 

	if (m_SaveWindowPositions)
	{
		WriteProfileInt("Windows","MainWindowPosX",m_WindowStates.pos.main.x);
		WriteProfileInt("Windows","MainWindowPosY",m_WindowStates.pos.main.y);
		WriteProfileInt("Windows","MainWindowSizeX",m_WindowStates.size.main.x);
		WriteProfileInt("Windows","MainWindowSizeY",m_WindowStates.size.main.y);

		WriteProfileInt("Windows","LabelTablePosX",m_WindowStates.pos.label.x);
		WriteProfileInt("Windows","LabelTablePosY",m_WindowStates.pos.label.y);
		WriteProfileInt("Windows","LabelTableSizeX",m_WindowStates.size.label.x);
		WriteProfileInt("Windows","LabelTableSizeY",m_WindowStates.size.label.y);
	}
}

void CWinTim32App::LoadRegistry()
{
	m_OutputFixed = GetProfileInt("Windows","OutputFixed",50);
	m_OutputPercent = GetProfileInt("Windows","OutputPercent",20);
	m_OutputType = GetProfileInt("Windows","OutputType",1); 
	m_ErrorMax = GetProfileInt("Assembler","ErrorMax",100);
	m_bWordSel = GetProfileInt("Options","SelectEntireWord",FALSE);
	m_bDragDrop = GetProfileInt("Options","DragAndDropEdit",FALSE);
	m_bAutoIndent = GetProfileInt("Options","AutoIndent",TRUE);
	m_ViewBGColor = GetProfileInt("Colors","Background",DEFAULT_BG);
	m_ViewNormalColor = GetProfileInt("Colors","Normal",DEFAULT_NORM);
	m_ViewLabelColor = GetProfileInt("Colors","Label",DEFAULT_LABEL);
	m_ViewCommentColor = GetProfileInt("Colors","Comment",DEFAULT_COMMENT);
	m_ViewOpcodeColor = GetProfileInt("Colors","Opcode",DEFAULT_OPCODE);
	m_ViewKeywordColor = GetProfileInt("Colors","Keyword",DEFAULT_KEYWORD);
	m_ViewUserKeywordColor = GetProfileInt("Colors","UserKeyword",DEFAULT_USERKEYWORD);
	m_ViewStringColor = GetProfileInt("Colors","String",DEFAULT_STRING);
	m_FontName = GetProfileString("Options","FontName",DEFAULT_FONT);
	m_FontSize = GetProfileInt("Options","FontSize",DEFAULT_FONTSIZE);
	m_DynamicTabs = GetProfileInt("Options","DynamicTabs",TRUE);
	m_MinWhite = GetProfileInt("Options","MinimumWhitespace",10);
	m_MaxWhite = GetProfileInt("Options","MaximumWhitespace",40);
	m_SaveWindowPositions = GetProfileInt("Options","SaveWindowPositions",TRUE);
	m_VisibleLabelTable = GetProfileInt("Windows","VisibleLabelTable",TRUE);
	m_AddressIndexMode = GetProfileInt("Assembler","IndexMode",WT_INDEXBYONE);
	m_dwWarnings = GetProfileInt("Options","IgnoreWarnings",0x0040);
}

int CWinTim32App::DoOptions()
{
	CPropertySheet optionsSheet;
	CPPEdit pageEdit;
	CPPColors pageColors;
	CPageMisc pageMisc;
	CPPAsm pageAsm;
	CPPWarnings pageWarnings;
	int nResponse;

	COLORREF saveColors[8];
	CString  saveFont;
	int saveFontSize;

	optionsSheet.AddPage(&pageEdit);
	optionsSheet.AddPage(&pageColors);
	optionsSheet.AddPage(&pageMisc);
	optionsSheet.AddPage(&pageAsm);
	optionsSheet.AddPage(&pageWarnings);

	// Save the original values
	m_ColorChange = FALSE;
	m_FontChange = FALSE;
	saveColors[0] = m_ViewCommentColor;
	saveColors[1] = m_ViewKeywordColor;
	saveColors[2] = m_ViewLabelColor;
	saveColors[3] = m_ViewNormalColor;
	saveColors[4] = m_ViewOpcodeColor;
	saveColors[5] = m_ViewStringColor;
	saveColors[6] = m_ViewBGColor;
	saveColors[7] = m_ViewUserKeywordColor;
	saveFont = m_FontName;
	saveFontSize = m_FontSize;

	// Ensure that the properties dialog displays current data

	pageAsm.m_ErrorMax = m_ErrorMax;
	pageEdit.m_EditEntireWord = m_bWordSel;
	pageEdit.m_EditDragDrop = m_bDragDrop;
	pageEdit.m_AutoIndent = m_bAutoIndent;
	pageEdit.m_DynamicTabs = m_DynamicTabs;
	pageEdit.m_MinWhite = m_MinWhite;
	pageEdit.m_MaxWhite = m_MaxWhite;
	pageMisc.m_SaveWin = m_SaveWindowPositions;
	pageAsm.m_iAddressIndexMode = m_AddressIndexMode;
	pageWarnings.m_EndBeforeEOF = (m_dwWarnings & 0x0001) > 0;
	pageWarnings.m_DEFInAsm = (m_dwWarnings & 0x0002) > 0;
	pageWarnings.m_OpcodeLengthIncons = (m_dwWarnings & 0x0004) > 0;
	pageWarnings.m_OpcodeWordIncons = (m_dwWarnings & 0x0008) > 0;
	pageWarnings.m_FORMIncons = (m_dwWarnings & 0x0010) > 0;
	pageWarnings.m_InvalidListOp = (m_dwWarnings & 0x0020) > 0;
	pageWarnings.m_InsufficientArgs = (m_dwWarnings & 0x0040) > 0;
	pageMisc.m_Fixed = m_OutputFixed;
	pageMisc.m_Percent = m_OutputPercent;
	pageMisc.m_OutputHeightType = m_OutputType;

	// Display the properties dialog and allow the user to make changes

	optionsSheet.m_psh.pszCaption = "WinTim32 Options";
	nResponse = (optionsSheet.DoModal());
	if (nResponse == IDCANCEL)
	{
		// Restore the original settings
		m_ViewCommentColor = saveColors[0];
		m_ViewKeywordColor = saveColors[1];
		m_ViewLabelColor = saveColors[2];
		m_ViewNormalColor = saveColors[3];
		m_ViewOpcodeColor = saveColors[4];
		m_ViewStringColor = saveColors[5];
		m_ViewBGColor = saveColors[6];
		m_FontName = saveFont;
		m_FontSize = saveFontSize;
	} else
	{
		// Update the application options from the property pages
		m_dwWarnings = 0;
		m_dwWarnings |= (pageWarnings.m_EndBeforeEOF > 0) << 0;
		m_dwWarnings |= (pageWarnings.m_DEFInAsm > 0) << 1;
		m_dwWarnings |= (pageWarnings.m_OpcodeLengthIncons > 0) << 2;
		m_dwWarnings |= (pageWarnings.m_OpcodeWordIncons > 0) << 3;
		m_dwWarnings |= (pageWarnings.m_FORMIncons > 0) << 4;
		m_dwWarnings |= (pageWarnings.m_InvalidListOp > 0) << 5;
		m_dwWarnings |= (pageWarnings.m_InsufficientArgs > 0) << 6;
		m_bWordSel = pageEdit.m_EditEntireWord;
		m_bDragDrop = pageEdit.m_EditDragDrop;
		m_bAutoIndent = pageEdit.m_AutoIndent;
		m_DynamicTabs = pageEdit.m_DynamicTabs;
		m_MinWhite = pageEdit.m_MinWhite;
		m_MaxWhite = pageEdit.m_MaxWhite;
		m_SaveWindowPositions = pageMisc.m_SaveWin;
		m_AddressIndexMode = pageAsm.m_iAddressIndexMode;
		m_ErrorMax = pageAsm.m_ErrorMax;
		m_OutputFixed = pageMisc.m_Fixed;
		m_OutputPercent = pageMisc.m_Percent;
		m_OutputType = pageMisc.m_OutputHeightType;

		// Update the options in the system registry
		WriteRegistry();

		// Set the m_ColorChange variable if the color changed
		if (m_ViewCommentColor != saveColors[0]) m_ColorChange = TRUE;
		if (m_ViewKeywordColor != saveColors[1]) m_ColorChange = TRUE;
		if (m_ViewLabelColor != saveColors[2]) m_ColorChange = TRUE;
		if (m_ViewNormalColor != saveColors[3]) m_ColorChange = TRUE;
		if (m_ViewOpcodeColor != saveColors[4]) m_ColorChange = TRUE;
		if (m_ViewStringColor != saveColors[5]) m_ColorChange = TRUE;
		if (m_ViewBGColor != saveColors[6]) m_ColorChange = TRUE;
		if (m_ViewUserKeywordColor != saveColors[7]) m_ColorChange = TRUE;

		// Set the m_FontChange variable if the font changed
		if (m_FontName != saveFont) m_FontChange = TRUE;
	}

	return nResponse;
}

void CWinTim32App::Warning(CString text)
{
	m_StatusBar->SetWindowText(text);
}

int CWinTim32App::ExitInstance() 
{
	WriteRegistry();	
//	DeleteCriticalSection(&global_CS);
	return CWinApp::ExitInstance();
}

void CWinTim32App::LoadWindowRegistry()
{
	if (m_SaveWindowPositions)
	{
		m_WindowStates.pos.main.x = GetProfileInt("Windows","MainWindowPosX",34);
		m_WindowStates.pos.main.y = GetProfileInt("Windows","MainWindowPosY",42);
		m_WindowStates.size.main.x = GetProfileInt("Windows","MainWindowSizeX",613);
		m_WindowStates.size.main.y = GetProfileInt("Windows","MainWindowSizeY",403 );

		m_WindowStates.pos.label.x = GetProfileInt("Windows","LabelTablePosX",305);
		m_WindowStates.pos.label.y = GetProfileInt("Windows","LabelTablePosY",72);
		m_WindowStates.size.label.x = GetProfileInt("Windows","LabelTableSizeX",318);
		m_WindowStates.size.label.y = GetProfileInt("Windows","LabelTableSizeY",351);
	}
}

void CWinTim32App::UpdateStatusBar(CRichEditCtrl *re)
// Updates the status bar with the current line and column
// of the rich edit control that requested the update
{
	long start,end;
	CString sText;

	re->GetSel(start,end);
	m_Line = re->LineFromChar(start);
	m_Column = start - re->LineIndex(m_Line);
	sText.Format("Ln %d, Col %d",m_Line+1,m_Column+1);
	m_StatusBar->SetPaneText(1,sText,TRUE);
	m_StatusBar->SetPaneInfo(1,1,SBPS_NORMAL,80);
}
