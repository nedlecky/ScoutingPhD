// PPEdit.cpp : implementation file
//

#include "stdafx.h"
#include "WinTim32.h"
#include "PPEdit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPPEdit property page

IMPLEMENT_DYNCREATE(CPPEdit, CPropertyPage)

CPPEdit::CPPEdit() : CPropertyPage(CPPEdit::IDD)
{
	//{{AFX_DATA_INIT(CPPEdit)
	m_EditEntireWord = FALSE;
	m_EditDragDrop = FALSE;
	m_DynamicTabs = FALSE;
	m_MinWhite = 0;
	m_MaxWhite = 0;
	m_AutoIndent = FALSE;
	//}}AFX_DATA_INIT
}

CPPEdit::~CPPEdit()
{
}

void CPPEdit::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPPEdit)
	DDX_Check(pDX, IDC_EDITENTIREWORD, m_EditEntireWord);
	DDX_Check(pDX, IDC_EDITDRAGDROP, m_EditDragDrop);
	DDX_Check(pDX, IDC_DYNATABS, m_DynamicTabs);
	DDX_Text(pDX, IDC_MINWHITE, m_MinWhite);
	DDV_MinMaxLong(pDX, m_MinWhite, 0, 32767);
	DDX_Text(pDX, IDC_MAXWHITE, m_MaxWhite);
	DDV_MinMaxLong(pDX, m_MaxWhite, 0, 32767);
	DDX_Check(pDX, IDC_AUTOINDENT, m_AutoIndent);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPPEdit, CPropertyPage)
	//{{AFX_MSG_MAP(CPPEdit)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPPEdit message handlers
