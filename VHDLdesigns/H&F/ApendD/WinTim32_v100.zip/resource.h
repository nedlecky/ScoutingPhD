//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WinTim32.rc
//
#define IDR_WINTIMTYPE_CNTR_IP          6
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDP_FAILED_TO_CREATE            102
#define IDR_MAINFRAME                   128
#define IDR_WINTIMTYPE                  129
#define IDS_SAMPLETEXT                  130
#define IDD_PPEDIT                      132
#define IDD_PPMISC                      135
#define IDD_PPCOLOR                     136
#define IDD_LABELTABLE                  137
#define IDD_ACTIVETHREAD                138
#define IDR_EDITCONTEXT                 139
#define IDD_PPASM                       139
#define IDD_OUTPUT                      140
#define IDD_GOTO                        141
#define IDD_PPWARNINGS                  142
#define IDC_EDITENTIREWORD              1006
#define IDC_EDITDRAGDROP                1007
#define IDC_CHANGEBG                    1008
#define IDC_DYNATABS                    1008
#define IDC_SAMPLETEXT                  1009
#define IDC_CHANGENORM                  1010
#define IDC_CHANGELABEL                 1011
#define IDC_CHANGECOMMENT               1012
#define IDC_BGC                         1013
#define IDC_NTC                         1014
#define IDC_LBC                         1015
#define IDC_CMC                         1016
#define IDC_CHANGEOPCODE                1017
#define IDC_OPC                         1018
#define IDC_CHANGEKEYWORD               1019
#define IDC_KWC                         1020
#define IDC_FONT                        1021
#define IDC_CHANGEFONT                  1022
#define IDC_MINWHITE                    1023
#define IDC_CHANGESTRING                1023
#define IDC_MAXWHITE                    1024
#define IDC_STC                         1024
#define IDC_LABELLIST                   1025
#define IDC_CHANGEUSER                  1025
#define IDC_UPDATE                      1026
#define IDC_UKC                         1026
#define IDC_SAVEWIN                     1027
#define IDC_AUTOINDENT                  1028
#define IDC_INDEXONE                    1031
#define IDC_INDEXISIZE                  1032
#define IDC_OUTPUTEDIT                  1034
#define IDC_LINENUM                     1037
#define IDC_CHECK1                      1038
#define IDC_CHECK2                      1039
#define IDC_CHECK3                      1040
#define IDC_CHECK4                      1041
#define IDC_CHECK6                      1043
#define IDC_CHECK7                      1044
#define IDC_CHECK5                      1045
#define IDC_ERRORMAX                    1046
#define IDC_OD_PERCENT                  1048
#define IDC_OD_FIXED                    1050
#define IDC_OD_EDITPERCENT              1051
#define IDC_OD_EDITFIXED                1052
#define ID_CANCEL_EDIT_CNTR             32768
#define ID_VIEW_OPTIONS                 32771
#define ID_VIEW_REFRESH                 32772
#define ID_VIEW_LABELTABLE              32773
#define ID_ASSEMBLY_METAASSEMBLY        32774
#define ID_ASSEMBLY_ASSEMBLE            32775
#define ID_VIEW_ASSEMBLERMACROS         32776
#define MYWM_UPDATEFORMAT               32777
#define ID_VIEW_ASMETAFILE              32778
#define ID_VIEW_ASASSEMBLYFILE          32779
#define ID_OUTPUT_BINARYDATA            32780
#define ID_VIEW_ASTEXT                  32781
#define ID_OUTPUT_LOCALSYMBOLTABLE      32782
#define ID_OUTPUT_COMPLETESYMBOLTABLE   32783
#define ID_OUTPUT_ASSEMBLEDBINARYDATAMIFFORMAT 32784
#define ID_OUTPUT_DEFINITIONTABLE       32785
#define ID_EDIT_DELETE                  32790
#define ID_VIEW_OUTPUTMESSAGES          32794
#define ID_EDIT_GOTOLINE                32795
#define ID_INDICATOR_LINE               59142

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        144
#define _APS_NEXT_COMMAND_VALUE         32796
#define _APS_NEXT_CONTROL_VALUE         1052
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
