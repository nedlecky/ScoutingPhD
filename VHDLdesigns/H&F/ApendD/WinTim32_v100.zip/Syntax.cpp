// Syntax.cpp: implementation of the CSyntax class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "WinTim32.h"
#include "Syntax.h"
#include "ThreadWaitDlg.h"
#include "tokens.h"

extern CWinTim32App theApp;

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

char *WinTimKeywords[] = { "TITLE", "TITLE2", "WORD", "WIDTH", "LINES", "END", "FORM", "LIST", 
						   "EJECT", "ELSE", "ENDIF", "EXITM", "EXTRN", "FF", "FORMAT.INST",
						   "HEAD", "IF", "IFC", "IFD", "IFNC", "IFND", "INCLUDE", "LOCAL",
						   "MAP", "NOLIST", "PUBLIC", ".REL", "SPACE", "TAB", "ALIGN", "\0" };

short WinTimKeywordsIndex[] = {
	WTKW_TITLE,
	WTKW_TITLE2,
	WTKW_WORD,
	WTKW_WIDTH,
	WTKW_LINES,
	WTKW_END,
	WTKW_FORM,
	WTKW_LIST,
	WTKW_EJECT,
	WTKW_ELSE,
	WTKW_ENDIF,
	WTKW_EXITM,
	WTKW_EXTRN,
	WTKW_FF,
	WTKW_FORMAT,
	WTKW_HEAD,
	WTKW_IF,
	WTKW_IFC,
	WTKW_IFD,
	WTKW_IFNC,
	WTKW_IFND,
	WTKW_INCLUDE,
	WTKW_LOCAL,
	WTKW_MAP,
	WTKW_NOLIST,
	WTKW_PUBLIC,
	WTKW_REL,
	WTKW_SPACE,
	WTKW_TAB,
	WTKW_ALIGN,
	WTKW_NULL
};

char *WinTimPseudoOps[] = { "EQU", "SUB", "DEF", "MACRO", "ENDM", "ORG", "SET", "DATA", "DUP", "DCARE",
							"_AND_", "_OR_", "_XOR_", "_EQ_", "_NE_", "_GT_", "_GE_", "_LT_", "_LE_",
							"_SHR_", "_SHL_", "RES", "\0" };
short WinTimPseudoOpsIndex[] = {
	WTPO_EQU,
	WTPO_SUB,
	WTPO_DEF,
	WTPO_MACRO,
	WTPO_ENDM,
	WTPO_ORG,
	WTPO_SET,
	WTPO_DATA,
	WTPO_DUP,
	WTPO_DCARE,
	WTPO_AND,
	WTPO_OR,
	WTPO_XOR,
	WTPO_EQ,
	WTPO_NE,
	WTPO_GT,
	WTPO_GE,
	WTPO_LT,
	WTPO_LE,
	WTPO_SHR,
	WTPO_SHL,
	WTPO_RES,
	WTPO_NULL
};

char *WinTimNumerics[] = { "B#", "O#", "D#", "H#", "Q#", "\0" };
short WinTimNumericsIndex[] = {
	WTNM_BINARY,
	WTNM_OCTAL,
	WTNM_DECIM,
	WTNM_HEX,
	WTNM_OCTAL,
	WTNM_NULL
};

extern int activeThreadCount;
extern int activeViewCount;

BOOL g_bFromComplete;

// The CLabel Class construction and deconstruction functions

CLabel::CLabel()
{
	name = "";
	address = -1;
	line = -1;
}

CLabel::CLabel(CString cName, long lAddress, long lLineNumber)
{
	name = cName;
	address = lAddress;
	line = lLineNumber;
}

CLabel::~CLabel()
{
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSyntax::CSyntax()
{
	g_bFromComplete = FALSE;
}

CSyntax::~CSyntax()
{
}

BOOL CSyntax::SyntaxHighlightOneLine(long index, CRichEditCtrl *re, BOOL StopUpdate, CSyntaxData *pSyntaxData)
{
	long i, j, nLineLen, lineIndex, wordlen, iLineStart;
//	long e1,e2;
	char c;
	BOOL NeedUpdate = FALSE;
	BOOL bSaveModify;
	long lStart, lEnd;
	CRect rThisLine;
	CPoint pt;

	bSaveModify = re->GetModify();

	re->GetLine(index,cBuffer,MAX_RELINE);
	re->GetSel(lStart,lEnd);

	lineIndex = re->LineIndex(index);

	re->GetClientRect(&rThisLine);
	pt = re->GetCharPos(lineIndex);
//	rThisLine.left = pt.x;
	rThisLine.top = pt.y;
	if (re->LineIndex(index+1) != -1)
	{
		pt = re->GetCharPos(re->LineIndex(index+1));
		rThisLine.bottom = pt.y;
	}

	nLineLen = re->LineIndex(index+1) - lineIndex;
	if (nLineLen < 0)
		nLineLen = re->GetTextLength() - re->LineIndex(index);
	cBuffer[nLineLen] = '\0';

	if (nLineLen == 0)
		return 0;

	if (StopUpdate)
	{
		HideCaret(NULL);
		re->SetRedraw(FALSE);
	}

	// This isn't necessary if we came from SyntaxHighlightComplete
	if (!g_bFromComplete)
	{
		re->SetSel(lineIndex,lineIndex + nLineLen);
		re->SetWordCharFormat(m_charDefault);
		re->SetSel(lStart,lEnd);
	}

	if (pSyntaxData != NULL)
	{
		if (pSyntaxData->FileType == PlainText)
		{
			re->SetRedraw(TRUE);
			re->InvalidateRect(rThisLine,FALSE);
			re->SetModify(bSaveModify);
			return NeedUpdate;
		}
	}

	// Completely ignore whitespace at the beginning of a line
	i = 0;
	while (iswhitespace(cBuffer[i]))
	{
		// The 0x00 character will break us out of this eventually
		i++;
	}
	iLineStart = i;
	if (iLineStart >= nLineLen)
	{
		if (StopUpdate)
		{
			re->SetRedraw(TRUE);
			ShowCaret(NULL);
			re->InvalidateRect(rThisLine,FALSE);
		}

		re->SetModify(bSaveModify);
		return NeedUpdate;
	}

	// First check for a comment (anything following a semicolon)
	i = iLineStart;
	while (cBuffer[i] != COMMENTCHAR)
	{
		i++;
		if (i >= nLineLen)
			break;
	}
	if (i < nLineLen)
	{
		re->SetSel(lineIndex + i, lineIndex + nLineLen);
		re->SetWordCharFormat(m_charComment);
		cBuffer[i] = '\0'; // Anything in a comment is excluded from the following checks
		nLineLen = i;
	}
	// Continue parsing the line, checking for a label, ^[A-za-z0-9_]*:
	i = iLineStart;
	while (cBuffer[i] != LABELCHAR)
	{
		if (i == nLineLen)
			break;
		if (!islabelchar(cBuffer[i]))
		{
			i = nLineLen;
			break;
		}
		i++;
	}
	if (i != nLineLen)
	{
		re->SetSel(lineIndex,lineIndex + i);
		re->SetWordCharFormat(m_charLabel);
	} else
		i = iLineStart; // If there was no label, restart from beginning of line

	// Next, check for keywords from the keyword table and opcodes
	// as well as string values in quotation marks
	while (i < nLineLen)
	{
		// If the current character is a backslash, ignore the next character
		// and continue checking
		if (cBuffer[i] == '\\')
		{
			i += 2;
			continue;
		}
		// Check for double-quoted string
		if (cBuffer[i] == '\"')
		{
			j = i+1;
			while (j < nLineLen)
			{
				if (cBuffer[j] == '\\')
				{
					j += 2;
					continue;
				}
				if (cBuffer[j] == '\"')
					break;
				j++;
			}
			re->SetSel(lineIndex + i,lineIndex + j + (j < nLineLen));
			re->SetWordCharFormat(m_charString);
			i = j;
			if (i >= nLineLen)
				break;
		}
		// Check for single-quoted string
		else if (cBuffer[i] == '\'')
		{
			j = i+1;
			while (j < nLineLen)
			{
				if (cBuffer[j] == '\\')
				{
					j += 2;
					continue;
				}
				if (cBuffer[j] == '\'')
					break;
				j++;
			}
			re->SetSel(lineIndex + i,lineIndex + j + (j < nLineLen));
			re->SetWordCharFormat(m_charString);
			i = j;
			if (i >= nLineLen)
				break;
		}
		// Check for keywords after string, if any

		if (i > iLineStart)
		{
			if (((iskwchar(cBuffer[i-1])) || (cBuffer[i-1] == '#')) && (cBuffer[i] != '_'))
			{
				// Don't bother trying to match if this isn't the
				// beginning of a word
				i++;
				continue;
			}
		}
		// Check the hash table, if there is one, for these values
		if (m_bHashTableValid)
		{
			wordlen = i;
			if (cBuffer[i] == '_')
			{
				wordlen++;
				while (iskwchar(cBuffer[wordlen]))
				{
					wordlen++;
					if (cBuffer[wordlen] == '_')
					{
						wordlen++;
						break;
					}
				}
			} else
			{
				while (iskwchar(cBuffer[wordlen]))
				{
					wordlen++;
				}
			}
			c = cBuffer[wordlen];
			cBuffer[wordlen] = 0x00;
			wordlen -= i;
			// If the current word is in the hash table, highlight it
			// with that element's character formatting
			sTemp = (&(cBuffer[i]));
			sTemp.MakeUpper();
			if (m_CharMapTable.Lookup(sTemp,(void *&)(m_pCharMap)))
			{
				// We found a match!
				if (pSyntaxData != NULL)
				{
					if ((pSyntaxData->FileType != AssemblyFile) && (m_pCharMap == &m_charUserKeyword))
					{
						// We don't want to highlight user keywords in this particular file
						break;
					}
				}
				re->SetSel(lineIndex + i, lineIndex + i + wordlen);
				re->SetWordCharFormat(*m_pCharMap);
			}
			cBuffer[wordlen+i] = c;
		}
		else
		{
#ifdef _DEBUG
			afxDump << "Warning: Hash table invalid\n";
#endif
			// This is old code; the m_bHashTableValid should always be true
			j = 0;
			while (WinTimKeywords[j][0] != '\0')
			{
				wordlen = strlen(WinTimKeywords[j]);
				if (strnicmp(&(cBuffer[i]),WinTimKeywords[j],wordlen) == 0)
				{
					// Make sure this match is a "word"
					if (iskwchar(cBuffer[i+wordlen]))
					{
						j++;
						continue;
					}
					// It's a bona fide keyword
					re->SetSel(lineIndex + i,lineIndex + i + wordlen);
					re->SetWordCharFormat(m_charKeyword);
					i += wordlen;
					// If the keyword is "TITLE" or TITLE2 then nothing is to be checked after it
					if ((j == 0) || (j == 1)) // index zero is "TITLE", 1 is "TITLE2"
						i = nLineLen;
					continue;
				}
				j++;
			}
			j = 0;
			while (WinTimPseudoOps[j][0] != '\0')
			{
				wordlen = strlen(WinTimPseudoOps[j]);
				if (strnicmp(&(cBuffer[i]),WinTimPseudoOps[j],wordlen) == 0)
				{
					// Make sure this match is a "word"
					if (iskwchar(cBuffer[i+wordlen]) && (cBuffer[i] != '_'))
					{
						j++;
						continue;
					}
					// It's a bona fide pseudoop
					re->SetSel(lineIndex + i,lineIndex + i + wordlen);
					re->SetWordCharFormat(m_charPseudoOp);
					i += wordlen;
					continue;
				}
				j++;
			}
			// If this is an assembler file, check the Defintions array for
			// additional user-defined keywords.
			if (pSyntaxData != NULL)
			{
				if (pSyntaxData->FileType == AssemblyFile)
				{
					for (j = 0; j < pSyntaxData->pDefArray->GetSize(); j++)
					{
						wordlen = strlen(pSyntaxData->pDefArray->GetAt(j).sOpcode);
						if (strnicmp(&(cBuffer[i]),pSyntaxData->pDefArray->GetAt(j).sOpcode,wordlen) == 0)
						{
							// Make sure this match is a "word"
							if (iskwchar(cBuffer[i+wordlen]))
							{
								j++;
								continue;
							}
							// It's a bona fide pseudoop
							re->SetSel(lineIndex + i,lineIndex + i + wordlen);
							re->SetWordCharFormat(m_charUserKeyword);
							i += wordlen;
							continue;
						}
					}
				}
			}
		}
		i++;
	}
	re->SetSel(nLineLen + lineIndex,nLineLen + lineIndex);
	re->SetWordCharFormat(m_charDefault); // Use the default text color for the next user-typed character

	if (StopUpdate)
	{
		re->SetRedraw(TRUE);
		ShowCaret(NULL);
		// re->InvalidateRect(rThisLine,FALSE);
		re->RedrawWindow(rThisLine);
	}

	re->SetModify(bSaveModify);
	return NeedUpdate;
}

void CSyntax::SyntaxHighlightComplete(CRichEditCtrl *re, CSyntaxData *pSyntaxData)
{
	long i,firstLine,lastLine;
	long selStart,selEnd;
	BOOL NeedUpdate = FALSE;
	BOOL bSkipHighlight = FALSE;
	char buf[10];
	BOOL bSaveModify;  // Don't update the modify flag because of syntax highlighting
	MSG msg;

	bSaveModify = re->GetModify();

	SetCharFormats();

	UpdateHashTable(pSyntaxData);

	// Start the highlight process
	HideCaret(NULL);
	re->SetRedraw(FALSE);

	re->GetSel(selStart,selEnd);
	re->SetDefaultCharFormat(m_charDefault);
	re->SetSel(0,-1);
	re->SetWordCharFormat(m_charDefault);


	if (pSyntaxData != NULL)
	{
		if (pSyntaxData->FileType == PlainText)
		{
			bSkipHighlight = TRUE;
		}
	}

	if (bSkipHighlight == FALSE)
	{
		lastLine = re->GetLineCount();
		firstLine = 0;

		g_bFromComplete = TRUE;
		for (i = firstLine; i < lastLine; i++)
		{
			if (SyntaxHighlightOneLine(i,re,FALSE,pSyntaxData))
				NeedUpdate = TRUE;
			if (!(i & 0xf))
			{
				theApp.Warning(CString("Processing line ") + CString(ltoa(i,buf,10)) + " (press ESC to abort)");
				// If the user hits escape, cancel the processing!
				if (PeekMessage(&msg,AfxGetApp()->GetMainWnd()->GetSafeHwnd(),WM_KEYFIRST,WM_KEYLAST,PM_REMOVE))
				{
					if (msg.wParam == VK_ESCAPE)
						break;
					// Otherwise, we remove the message from the list, but that
					// shouldn't matter (it just ignores the keystroke)
				}
			}

			
		}
		g_bFromComplete = FALSE;
	}

	re->SetBackgroundColor(FALSE, theApp.m_ViewBGColor);
	re->SetSel(selStart,selEnd);

	re->SetRedraw(TRUE);
	ShowCaret(NULL);
	theApp.Warning("Ready");
	if (NeedUpdate)
		re->Invalidate();

	re->SetModify(bSaveModify);
}


void CSyntax::UpdateHashTable(CSyntaxData *pSyntaxData)
// Updates the hash table to include the new user opcodes
{
	int i;
	if (pSyntaxData != NULL)
	{
		for (i = 0; i < pSyntaxData->pDefArray->GetSize(); i++)
		{
			sTemp = pSyntaxData->pDefArray->GetAt(i).sOpcode;
			sTemp.MakeUpper();
			m_CharMapTable.SetAt(sTemp,(void *)(&m_charUserKeyword));
		}
	}
	m_bHashTableValid = TRUE;
}

void CSyntax::SetCharFormats()
// Sets up the character formatting colors
{
	m_charDefault.dwMask = CFM_COLOR | CFM_FACE | CFM_SIZE | CFM_BOLD;
	m_charDefault.dwEffects = 0;
	m_charDefault.crTextColor = theApp.m_ViewNormalColor;
	m_charDefault.yHeight = theApp.m_FontSize * 2;
	strncpy(m_charDefault.szFaceName,theApp.m_FontName,sizeof(m_charDefault.szFaceName));

	m_charLabel.dwMask = CFM_COLOR;
	m_charLabel.dwEffects = 0;
	m_charLabel.crTextColor = theApp.m_ViewLabelColor;

	m_charKeyword.dwMask = CFM_COLOR;
	m_charKeyword.dwEffects = 0;
	m_charKeyword.crTextColor = theApp.m_ViewKeywordColor;

	m_charUserKeyword.dwMask = CFM_COLOR;
	m_charUserKeyword.dwEffects = 0;
	m_charUserKeyword.crTextColor = theApp.m_ViewUserKeywordColor;

	m_charPseudoOp.dwMask = CFM_COLOR;
	m_charPseudoOp.dwEffects = 0;
	m_charPseudoOp.crTextColor = theApp.m_ViewOpcodeColor;

	m_charComment.dwMask = CFM_COLOR;
	m_charComment.dwEffects = 0;
	m_charComment.crTextColor = theApp.m_ViewCommentColor;

	m_charString.dwMask = CFM_COLOR;
	m_charString.dwEffects = 0;
	m_charString.crTextColor = theApp.m_ViewStringColor;
}

void CSyntax::InitializeHashTable()
// Sets the hash table to its initial values
{
	int i;
	SetCharFormats();

	// Store the keywords in the m_CharMapTable
	m_CharMapTable.RemoveAll();
	i = 0;
	while (WinTimKeywords[i][0] != '\0')
	{
		sTemp = WinTimKeywords[i];
		sTemp.MakeUpper();
		m_CharMapTable.SetAt(sTemp,(void *)(&m_charKeyword));
		i++;
	}
	i = 0;
	while (WinTimPseudoOps[i][0] != '\0')
	{
		sTemp = WinTimPseudoOps[i];
		sTemp.MakeUpper();
		m_CharMapTable.SetAt(sTemp,(void *)(&m_charPseudoOp));
		i++;
	}
	m_bHashTableValid = TRUE;
}
