class COutputBar :
   public CDialogBar
{
   DECLARE_DYNAMIC( COutputBar )

public:
	int m_cx;
	int m_cy;
   BOOL Create( CWnd* pParent, UINT nStyle, UINT nID );

protected:
   CSize CalcFixedLayout( BOOL tStretch, BOOL tHorz );

protected:
	DECLARE_MESSAGE_MAP()
};
