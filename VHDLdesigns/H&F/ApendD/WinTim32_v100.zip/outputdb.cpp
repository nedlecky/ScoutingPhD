#include "StdAfx.H"
#include "Resource.h"
#include "outputdb.h"
#include "WinTim32.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CWinTim32App theApp;

IMPLEMENT_DYNAMIC( COutputBar, CDialogBar )

BEGIN_MESSAGE_MAP( COutputBar, CDialogBar )
   ON_WM_CREATE()
END_MESSAGE_MAP()

CSize COutputBar::CalcFixedLayout( BOOL tStretch, BOOL tHorz )
{
	CSize size;
	CRect rect;

	size = CDialogBar::CalcFixedLayout( tStretch, tHorz );

	size.cx = m_cx;
	if (theApp.m_OutputType == 1)
		size.cy = (int) (m_cy * ((float) theApp.m_OutputPercent/100.0));
	else
		size.cy = theApp.m_OutputFixed;

	rect.left = 10;
	rect.top = 4;
	rect.right = size.cx;
	rect.bottom = size.cy;

	size.cx += 4;
	size.cy += 4;

	if (IsWindow(GetDlgItem(IDC_OUTPUTEDIT)->GetSafeHwnd()))
		GetDlgItem(IDC_OUTPUTEDIT)->MoveWindow(rect);

	// GetDockingFrame()->ModifyStyle(WS_BORDER | WS_DLGFRAME | WS_EX_DLGMODALFRAME,WS_THICKFRAME);

	return( size );
}

BOOL COutputBar::Create( CWnd* pParent, UINT nStyle, UINT nID )
{
//   HWND hControl;

   if( !CDialogBar::Create( pParent, IDD_OUTPUT, nStyle, nID ) )
   {
	  return( FALSE );
   }

/*
   hControl = NULL;
   GetDlgItem( IDC_OUTPUTEDIT, &hControl );
   ASSERT( hControl != NULL );
   if( !m_cboxMacroName.SubclassWindow( hControl ) )
   {
	  ASSERT( FALSE );
   }
*/
   return( TRUE );
}
