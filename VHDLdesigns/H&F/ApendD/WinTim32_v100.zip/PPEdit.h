#if !defined(AFX_PPEDIT_H__44ED1E4E_5CA7_11D3_B4AB_004005A3D75D__INCLUDED_)
#define AFX_PPEDIT_H__44ED1E4E_5CA7_11D3_B4AB_004005A3D75D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PPEdit.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPPEdit dialog

class CPPEdit : public CPropertyPage
{
	DECLARE_DYNCREATE(CPPEdit)

// Construction
public:
	CPPEdit();
	~CPPEdit();

// Dialog Data
	//{{AFX_DATA(CPPEdit)
	enum { IDD = IDD_PPEDIT };
	BOOL	m_EditEntireWord;
	BOOL	m_EditDragDrop;
	BOOL	m_DynamicTabs;
	long	m_MinWhite;
	long	m_MaxWhite;
	BOOL	m_AutoIndent;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPPEdit)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPPEdit)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PPEDIT_H__44ED1E4E_5CA7_11D3_B4AB_004005A3D75D__INCLUDED_)
