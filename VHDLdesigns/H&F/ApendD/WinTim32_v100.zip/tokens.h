// This file describes the tokens available in WinTim32

// Allocate TOKEN_GROW more tokens when we run out
#define TOKEN_GROW 2048

// WinTim32's keywords
#define WINTIM_KEYWORDS	0x0100

#define WTKW_NULL   (WINTIM_KEYWORDS + 0)
#define WTKW_TITLE	(WINTIM_KEYWORDS + 1)
#define WTKW_WIDTH	(WINTIM_KEYWORDS + 2)
#define WTKW_WORD	(WINTIM_KEYWORDS + 3)
#define WTKW_LINES	(WINTIM_KEYWORDS + 4)
#define WTKW_END	(WINTIM_KEYWORDS + 5)
#define WTKW_FORM	(WINTIM_KEYWORDS + 6)
#define WTKW_LIST	(WINTIM_KEYWORDS + 7)
#define WTKW_EJECT	(WINTIM_KEYWORDS + 8)
#define WTKW_ELSE	(WINTIM_KEYWORDS + 9)
#define WTKW_ENDIF	(WINTIM_KEYWORDS + 10)
#define WTKW_EXITM	(WINTIM_KEYWORDS + 11)
#define WTKW_EXTRN	(WINTIM_KEYWORDS + 12)
#define WTKW_FF		(WINTIM_KEYWORDS + 13)
#define WTKW_FORMAT	(WINTIM_KEYWORDS + 14)
#define WTKW_HEAD	(WINTIM_KEYWORDS + 15)
#define WTKW_IF		(WINTIM_KEYWORDS + 16)
#define WTKW_IFC	(WINTIM_KEYWORDS + 17)
#define WTKW_IFD	(WINTIM_KEYWORDS + 18)
#define WTKW_IFNC	(WINTIM_KEYWORDS + 19)
#define WTKW_IFND	(WINTIM_KEYWORDS + 20)
#define WTKW_INCLUDE	(WINTIM_KEYWORDS + 21)
#define WTKW_LOCAL	(WINTIM_KEYWORDS + 22)
#define WTKW_MAP	(WINTIM_KEYWORDS + 23)
#define WTKW_NOLIST	(WINTIM_KEYWORDS + 24)
#define WTKW_PUBLIC	(WINTIM_KEYWORDS + 25)
#define WTKW_REL	(WINTIM_KEYWORDS + 26)
#define WTKW_SPACE	(WINTIM_KEYWORDS + 28)
#define WTKW_TAB	(WINTIM_KEYWORDS + 29)
#define WTKW_TITLE2	(WINTIM_KEYWORDS + 30)
#define WTKW_ALIGN	(WINTIM_KEYWORDS + 31)

// WinTim32's pseuso-ops
#define WINTIM_PSEUDOOPS 0x0200

#define WTPO_NULL	(WINTIM_PSEUDOOPS + 0)
#define WTPO_EQU	(WINTIM_PSEUDOOPS + 1)
#define WTPO_SUB	(WINTIM_PSEUDOOPS + 2)
#define WTPO_DEF	(WINTIM_PSEUDOOPS + 3)
#define WTPO_MACRO	(WINTIM_PSEUDOOPS + 4)
#define WTPO_ENDM	(WINTIM_PSEUDOOPS + 5)
#define WTPO_ORG	(WINTIM_PSEUDOOPS + 6)
#define WTPO_SET	(WINTIM_PSEUDOOPS + 7)
#define WTPO_DATA	(WINTIM_PSEUDOOPS + 8)
#define WTPO_DUP	(WINTIM_PSEUDOOPS + 9)
#define WTPO_DCARE	(WINTIM_PSEUDOOPS + 10)
#define WTPO_AND	(WINTIM_PSEUDOOPS + 11)
#define WTPO_OR		(WINTIM_PSEUDOOPS + 12)
#define WTPO_XOR	(WINTIM_PSEUDOOPS + 13)
#define WTPO_EQ		(WINTIM_PSEUDOOPS + 14)
#define WTPO_NE		(WINTIM_PSEUDOOPS + 15)
#define WTPO_GT		(WINTIM_PSEUDOOPS + 16)
#define WTPO_GE		(WINTIM_PSEUDOOPS + 17)
#define WTPO_LT		(WINTIM_PSEUDOOPS + 18)
#define WTPO_LE		(WINTIM_PSEUDOOPS + 19)
#define WTPO_SHR	(WINTIM_PSEUDOOPS + 20)
#define WTPO_SHL	(WINTIM_PSEUDOOPS + 21)
#define WTPO_RES	(WINTIM_PSEUDOOPS + 22)

// WinTim32's numeric codes (B#, H#, etc)
#define WINTIM_NUMERIC	0x0300

#define WTNM_NULL   (WINTIM_NUMERIC + 0)
#define WTNM_BINARY (WINTIM_NUMERIC + 1)
#define WTNM_OCTAL  (WINTIM_NUMERIC + 2)
#define WTNM_DECIM	(WINTIM_NUMERIC + 3)
#define WTNM_HEX    (WINTIM_NUMERIC + 4)
#define WTNM_VAR    (WINTIM_NUMERIC + 5)
#define WTNM_DCARE  (WINTIM_NUMERIC + 6)

// Single-character "keywords"
#define WINTIM_CHAR		0x0400

#define WTCH_NULL		(WINTIM_CHAR + 0)
#define WTCH_QUOTE		(WINTIM_CHAR + 1)
#define WTCH_DQUOTE		(WINTIM_CHAR + 2)
#define WTCH_LABEL		(WINTIM_CHAR + 3)
#define WTCH_COMMA		(WINTIM_CHAR + 4)
#define WTCH_PLUS		(WINTIM_CHAR + 5)
#define WTCH_MINUS		(WINTIM_CHAR + 6)
#define WTCH_ASTERISK	(WINTIM_CHAR + 7)
#define WTCH_SLASH		(WINTIM_CHAR + 8)
#define WTCH_LBRACKET	(WINTIM_CHAR + 9)
#define WTCH_RBRACKET	(WINTIM_CHAR + 10)
#define WTCH_PERCENT	(WINTIM_CHAR + 11)
#define WTCH_LPAREN     (WINTIM_CHAR + 12)
#define WTCH_RPAREN     (WINTIM_CHAR + 13)
#define WTCH_LESS		(WINTIM_CHAR + 14)
#define WTCH_GREATER	(WINTIM_CHAR + 15)
#define WTCH_DOLLAR		(WINTIM_CHAR + 16)

// Anything that isn't a token
#define WINTIM_STRING 0x0500

// Miscellaneous pseudo-tokens
#define WINTIM_ENDSTRING	0x0000
#define WINTIM_WHITESPACE	0x0600
#define WINTIM_ENDPROGRAM   0x0700
#define WINTIM_MACRO		0x0800
#define WINTIM_MACROARG1	0x0801
// Macro arguments should be referenced as (WINTIM_MACROARG1 + x)
#define WINTIM_IGNORELF		WTCH_SLASH
#define WINTIM_ENDLINE		0x0a00
#define WINTIM_DCENDLINE	0x0a01

// User-defined opcodes go here (max of 32k)
#define WINTIM_USEROP	0x8000

// WinTim32 assembly flags

#define WT_JUSTIFY			0x0001
#define WT_RELATIVE			0x0002
#define WT_VARARG			0x0004
#define WT_TRUNCATE			0x0008
#define WT_DCARE 			0x0010
#define WT_DEFAULT			0x0020
#define WT_MULTIDEFAULT		0x0040

// WinTim32 "LIST" options

#define WTLO_ADDRESSEVERYLINE		0x0001
#define WTLO_OBJECTCODE				0x0002
#define WTLO_ERRORSATCONSOLE		0x0004
#define WTLO_OBJECTCODEATLEFT		0x0008
#define WTLO_LISTALLCONDITIONAL		0x0010
#define WTLO_LISTMACROSTATEMENTS	0x0020
#define WTLO_ADDRESSESINOCTAL		0x0040
#define WTLO_REFERENCEFILE			0x0080
#define WTLO_LISTSOURCE				0x0100
#define WTLO_LISTSYMBOLS			0x0200
#define WTLO_LINEWRAP				0x0400
#define WTLO_CROSSREFERENCE			0x0800

#define WTLO_DEFAULT  (WTLO_LISTMACROSTATEMENTS | WTLO_LISTSOURCE | WTLO_LISTSYMBOLS)

/*
LIST parameters:
A - list addresses on every line instead of only where there is object code (default OFF)
B - List formatted object code in block following end of source code listing if S is on (default OFF)
E - List source lines with errors at user's console as well as in output listing (default OFF for meta-asm, ON for asm)
F - list formatted object code to left of source code if S is on (default OFF)
I - list instructions not assembled because of conditional assembly decisions (default OFF)
M - in MACRO expansions, list all statements (except those not listed because I is off) (default ON)
    (when M is off, only MACRO expansions that produce code are listed)
(note: make sure macros work in listing)
Q - list addresses in octal instead of hex (default OFF)
R - create reference file to support later editing of symbolic code from list file (default OFF)
S - list text (default ON)
T - list symbol table (default ON)
W - wrap-around to next line when line exceeds width (otherwise truncate lines) (default OFF)
X - list cross-reference tables (overrides T) (default OFF)
*/