// PageMisc.cpp : implementation file
//

#include "stdafx.h"
#include "WinTim32.h"
#include "PageMisc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPageMisc property page

IMPLEMENT_DYNCREATE(CPageMisc, CPropertyPage)

CPageMisc::CPageMisc() : CPropertyPage(CPageMisc::IDD)
{
	//{{AFX_DATA_INIT(CPageMisc)
	m_SaveWin = FALSE;
	m_Percent = 0;
	m_Fixed = 0;
	//}}AFX_DATA_INIT
}

CPageMisc::~CPageMisc()
{
}

void CPageMisc::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPageMisc)
	DDX_Control(pDX, IDC_OD_PERCENT, m_PercentCtrl);
	DDX_Control(pDX, IDC_OD_FIXED, m_FixedCtrl);
	DDX_Check(pDX, IDC_SAVEWIN, m_SaveWin);
	DDX_Text(pDX, IDC_OD_EDITPERCENT, m_Percent);
	DDV_MinMaxInt(pDX, m_Percent, 5, 60);
	DDX_Text(pDX, IDC_OD_EDITFIXED, m_Fixed);
	DDV_MinMaxUInt(pDX, m_Fixed, 20, 1200);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPageMisc, CPropertyPage)
	//{{AFX_MSG_MAP(CPageMisc)
	ON_BN_CLICKED(IDC_OD_PERCENT, OnOdPercent)
	ON_BN_CLICKED(IDC_OD_FIXED, OnOdFixed)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPageMisc message handlers


void CPageMisc::OnOdPercent() 
{
	m_OutputHeightType = 1;
}

void CPageMisc::OnOdFixed() 
{
	m_OutputHeightType = 2;
}

BOOL CPageMisc::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	if (m_OutputHeightType == 1)
		m_PercentCtrl.SetCheck(1);
	else
		m_FixedCtrl.SetCheck(2);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
