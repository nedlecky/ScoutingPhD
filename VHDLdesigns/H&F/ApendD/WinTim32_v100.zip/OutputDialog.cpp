// OutputDialog.cpp : implementation file
//

#include "stdafx.h"
#include "WinTim32.h"
#include "OutputDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COutputDialog dialog


COutputDialog::COutputDialog(CWnd* pParent /*=NULL*/)
	: CDialog(COutputDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(COutputDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void COutputDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COutputDialog)
	DDX_Control(pDX, IDC_OUTPUTEDIT, m_OutputCtrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COutputDialog, CDialog)
	//{{AFX_MSG_MAP(COutputDialog)
	ON_WM_LBUTTONDBLCLK()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COutputDialog message handlers

BOOL COutputDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void COutputDialog::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	
	CDialog::OnLButtonDblClk(nFlags, point);
}
