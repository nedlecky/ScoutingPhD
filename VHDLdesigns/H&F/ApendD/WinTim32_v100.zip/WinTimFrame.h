#if !defined(AFX_WINTIMFRAME_H__E42D99F8_9552_11D3_B52F_004005A3D75D__INCLUDED_)
#define AFX_WINTIMFRAME_H__E42D99F8_9552_11D3_B52F_004005A3D75D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WinTimFrame.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CWinTimFrame frame

class CWinTimFrame : public CFrameWnd
{
	DECLARE_DYNCREATE(CWinTimFrame)
protected:
	CWinTimFrame();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWinTimFrame)
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CWinTimFrame();

	// Generated message map functions
	//{{AFX_MSG(CWinTimFrame)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WINTIMFRAME_H__E42D99F8_9552_11D3_B52F_004005A3D75D__INCLUDED_)
