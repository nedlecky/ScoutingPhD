// CntrItem.cpp : implementation of the CWinTim32CntrItem class
//

#include "stdafx.h"
#include "WinTim32.h"

#include "WinTim32Doc.h"
#include "WinTim32View.h"
#include "CntrItem.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWinTim32CntrItem implementation

IMPLEMENT_SERIAL(CWinTim32CntrItem, CRichEditCntrItem, 0)

CWinTim32CntrItem::CWinTim32CntrItem(REOBJECT* preo, CWinTim32Doc* pContainer)
	: CRichEditCntrItem(preo, pContainer)
{
	// TODO: add one-time construction code here
	
}

CWinTim32CntrItem::~CWinTim32CntrItem()
{
	// TODO: add cleanup code here
	
}

/////////////////////////////////////////////////////////////////////////////
// CWinTim32CntrItem diagnostics

#ifdef _DEBUG
void CWinTim32CntrItem::AssertValid() const
{
	CRichEditCntrItem::AssertValid();
}

void CWinTim32CntrItem::Dump(CDumpContext& dc) const
{
	CRichEditCntrItem::Dump(dc);
}
#endif

/////////////////////////////////////////////////////////////////////////////
