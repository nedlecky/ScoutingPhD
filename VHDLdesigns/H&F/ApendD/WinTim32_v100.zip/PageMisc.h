#if !defined(AFX_PAGEMISC_H__44ED1E56_5CA7_11D3_B4AB_004005A3D75D__INCLUDED_)
#define AFX_PAGEMISC_H__44ED1E56_5CA7_11D3_B4AB_004005A3D75D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PageMisc.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPageMisc dialog

class CPageMisc : public CPropertyPage
{
	DECLARE_DYNCREATE(CPageMisc)

// Construction
public:
	int m_OutputHeightType;
	CPageMisc();
	~CPageMisc();

// Dialog Data
	//{{AFX_DATA(CPageMisc)
	enum { IDD = IDD_PPMISC };
	BOOL	m_SaveWin;
	int		m_Percent;
	UINT	m_Fixed;
	CButton m_FixedCtrl;
	CButton m_PercentCtrl;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPageMisc)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPageMisc)
	afx_msg void OnOdPercent();
	afx_msg void OnOdFixed();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PAGEMISC_H__44ED1E56_5CA7_11D3_B4AB_004005A3D75D__INCLUDED_)
