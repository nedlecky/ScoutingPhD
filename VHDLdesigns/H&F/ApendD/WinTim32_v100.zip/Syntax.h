// Syntax.h: interface for the CSyntax class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SYNTAX_H__FF572028_5D63_11D3_B4AD_004005A3D75D__INCLUDED_)
#define AFX_SYNTAX_H__FF572028_5D63_11D3_B4AD_004005A3D75D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DefClasses.h"
#include <afxtempl.h>

class CLabel
{
public:
	CString name;
	long address;
	long line;
	virtual ~CLabel();
	CLabel();
	CLabel(CString cName, long lAddress, long lLineNumber);
};

typedef CArray<CLabel, CLabel> LabelArray;

class CSyntax  
{
public:
	void InitializeHashTable();
	void SetCharFormats();
	void UpdateHashTable(CSyntaxData *pSyntaxData);
	CMapStringToPtr m_CharMapTable;
	CString sTemp;
	BOOL m_bHashTableValid;
	char cBuffer[MAX_RELINE];
	void SyntaxHighlightComplete(CRichEditCtrl *re, CSyntaxData *pSyntaxData = NULL);
	CSyntax();
	virtual ~CSyntax();
	BOOL SyntaxHighlightOneLine(long index, CRichEditCtrl *re, BOOL StopUpdate = TRUE, CSyntaxData *pSyntaxData = NULL);
	CHARFORMAT m_charDefault, m_charLabel, m_charComment, m_charKeyword, 
		       m_charPseudoOp, m_charString, m_charUserKeyword;
	CHARFORMAT m_charMap;
	CHARFORMAT *m_pCharMap;
};

#endif // !defined(AFX_SYNTAX_H__FF572028_5D63_11D3_B4AD_004005A3D75D__INCLUDED_)
